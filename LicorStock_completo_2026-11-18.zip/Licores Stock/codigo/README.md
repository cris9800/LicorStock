# LicorStock

Sistema web para la gestión de inventario, ventas y domicilios de una licorera.
Python + Flask + Oracle (python-oracledb / JDBC) + Bootstrap 5 + Chart.js.

**¿Primera vez conectando con Oracle?** Lee `GUIA_CONEXION_ORACLE.md` y usa `PROBAR_CONEXION.cmd`.

## Estado actual (fase 3)

Usa la base de datos `database/LicorStock_Oracle_revisado.sql` (esquema TIENDA_VIRTUAL).

| Módulo | Estado |
|---|---|
| Base de datos (12 tablas, secuencias, triggers, vistas, datos migrados) | Listo |
| Login, roles (ADMINISTRADOR, VENDEDOR, REPARTIDOR), CSRF | Listo |
| Panel principal con gráfico de ventas | Listo |
| Productos y categorías | Listo |
| Ventas con pago y domicilio | Listo |
| Alertas de bajo stock e historial de movimientos | Listo |
| Clientes (crear, editar, buscar, activar/desactivar) | Listo |
| Proveedores (crear, editar, buscar, activar/desactivar) | Listo |
| Compras a proveedores (suman stock automáticamente) | Listo |
| Domicilios: asignar repartidor, en camino, entregado, cancelar | Listo |
| Anulación de ventas (devuelve el stock) | Listo |
| Caja diaria por método de pago y vendedor | Listo |
| Reportes con gráficos y descarga CSV para Excel | Listo |
| Gestión de usuarios y roles | Listo |
| Interfaz nueva: menú lateral, paleta vino/ámbar, catálogo con fotos, punto de venta | Listo |
| Fotos de productos (subir/arrastrar en Editar producto) | Listo |
| Prueba de conexión con mensajes de ayuda (`probar_conexion.py`) | Listo |

## Permisos por rol

- **ADMINISTRADOR:** todo, incluidas compras, proveedores, reportes, usuarios y anular ventas.
- **VENDEDOR:** ventas, clientes (crear y editar), domicilios, caja, consulta de productos, alertas y movimientos.
- **REPARTIDOR:** panel, sus domicilios (tomar, salir a entregar, marcar entregado) y consulta de inventario.

## Reglas de negocio en la base de datos

- `trg_detalle_venta_ai`: valida stock y mayoría de edad, descuenta el stock y registra la SALIDA.
- `trg_detalle_compra_ai`: suma al stock y registra la ENTRADA.
- `trg_venta_anulada_au`: al anular una venta devuelve las unidades al inventario.
- `trg_domicilio_bu`: guarda la fecha de entrega cuando el domicilio pasa a ENTREGADO.
- Pago contra entrega: queda PENDIENTE y pasa a PAGADO cuando el repartidor entrega; cuenta en la caja de ese día.
- Al anular una venta o cancelar su domicilio, los pagos quedan RECHAZADO y no suman en caja.
- Verificación de edad (RF19): si el cliente tiene fecha de nacimiento, la aplicación calcula la edad; si no, el vendedor confirma que revisó el documento. Sin verificación no se venden productos con `es_alcoholico = 'S'`.
- El precio de venta se toma siempre de la base de datos, nunca del formulario.

## Instalación

1. En Oracle (10g XE, 11g, 21c o 23ai), conectado como `TIENDA_VIRTUAL`, ejecuta
   `database/LicorStock_Oracle_revisado.sql` con F5 en SQL Developer.
2. Prepara Python:
   ```bash
   python -m venv venv
   venv\Scripts\activate          # Windows  (Linux/Mac: source venv/bin/activate)
   pip install -r requirements.txt
   copy .env.example .env         # y completa la contraseña y el DSN de Oracle
   ```
   En Oracle XE 21c el DSN suele ser `localhost:1521/XEPDB1`; en 10g/11g XE es `localhost:1521/XE`.
   **Si tu Oracle es 10g u 11g:** python-oracledb necesita el modo Thick. Descarga Oracle Instant Client
   y pon su carpeta en `ORACLE_CLIENT_LIB` dentro de `.env`. Ten en cuenta que los Instant Client
   actuales ya no se conectan a 10g; para 10g usa Instant Client 11.2. Con 12c o superior no hace falta nada.
3. Los usuarios migrados (karen, Ciro, juan...) entran con sus contraseñas de siempre.
   Si necesitas otro administrador: `flask --app run crear-admin`
4. Arranca: `flask --app run run --debug` y abre http://127.0.0.1:5000

## Estructura

```
config.py            configuración leída de .env
run.py               punto de entrada
database/            scripts SQL de Oracle
app/__init__.py      fábrica de la app, CSRF, comando crear-admin
app/db.py            pool de conexiones y consultas parametrizadas
app/auth/            login, logout y decoradores de rol
app/main/            panel principal
app/productos/       productos y categorías
app/ventas/          registro y consulta de ventas
app/inventario/      alertas y movimientos
app/clientes/        clientes
app/proveedores/     proveedores
app/compras/         compras a proveedores
app/domicilios/      seguimiento de domicilios
app/caja/            caja diaria
app/reportes/        reportes y exportación CSV
app/usuarios/        gestión de usuarios
app/templates/       vistas HTML (Bootstrap 5)
app/static/css/      estilos.css (colores y diseño)
app/static/img/      fotos de productos y de categorías
app/static/vendor/   Bootstrap, iconos, Chart.js y fuentes (funciona sin internet)
database/datos_demo.sql   productos y ventas de ejemplo (opcional)
probar_conexion.py   revisa la conexión con Oracle paso a paso
```
