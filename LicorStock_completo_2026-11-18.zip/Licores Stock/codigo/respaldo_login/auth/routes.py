from flask import Blueprint, flash, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash

from .. import db

bp = Blueprint("auth", __name__)


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        usuario = request.form.get("usuario", "").strip()
        password = request.form.get("password", "")
        fila = db.query(
            "SELECT id_usuario, username, password_hash, rol FROM usuario "
            "WHERE username = :usuario AND activo = 'S'",
            {"usuario": usuario}, one=True,
        )
        if fila and check_password_hash(fila["password_hash"], password):
            session.clear()
            session["id_usuario"] = fila["id_usuario"]
            session["nombre"] = fila["username"]
            session["rol"] = fila["rol"]
            return redirect(url_for("main.panel"))
        flash("Usuario o contraseña incorrectos.", "danger")
    return render_template("auth/login.html")


@bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("auth.login"))
