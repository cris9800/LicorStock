-- =====================================================================
-- LicorStock - DATOS DE DEMOSTRACIÓN (opcional)
-- Agrega 11 productos de licorera con su foto y algunas ventas de los
-- últimos 7 días para que el panel, los gráficos y los reportes se vean llenos.
--
-- Ejecutar en SQL Developer con F5, conectado con el MISMO usuario de la app
-- (el que pusiste en ORACLE_USER del archivo .env), DESPUÉS de
-- LicorStock_Oracle_revisado.sql.
--
-- Se puede ejecutar varias veces: no duplica productos y solo crea ventas
-- de ejemplo si la tabla VENTA está vacía. Compatible con 10g, 11g, 21c y 23ai.
-- =====================================================================
SET DEFINE OFF;

-- 1. Productos (las fotos ya vienen en app/static/img/productos/)
DECLARE
  PROCEDURE prod(p_cat NUMBER, p_prov NUMBER, p_nombre VARCHAR2, p_desc VARCHAR2,
                 p_alc CHAR, p_grado NUMBER, p_precio NUMBER, p_stock NUMBER,
                 p_min NUMBER, p_img VARCHAR2) IS
    v_n NUMBER;
  BEGIN
    SELECT COUNT(*) INTO v_n FROM producto WHERE UPPER(nombre) = UPPER(p_nombre);
    IF v_n = 0 THEN
      INSERT INTO producto (id_categoria, id_proveedor, nombre, descripcion, es_alcoholico,
                            grado_alcohol, precio_venta, stock_actual, stock_minimo, imagen)
      VALUES (p_cat, p_prov, p_nombre, p_desc, p_alc, p_grado, p_precio, p_stock, p_min, p_img);
    END IF;
  END;
BEGIN
  prod(3, 6, 'Aguardiente Antioqueño Tapa Roja 750ml', 'Aguardiente tradicional anisado.', 'S', 29, 55000, 36, 10, 'aguardiente.png');
  prod(3, 6, 'Aguardiente Amarillo de Manzanares 750ml', 'Aguardiente añejado, sabor suave.', 'S', 29, 58000, 4, 6, 'aguardiente-amarillo.png');
  prod(1, 6, 'Cerveza Club Colombia Dorada 330ml', 'Cerveza tipo lager premium en botella.', 'S', 4.2, 4500, 140, 48, 'cerveza-botella.png');
  prod(1, 6, 'Cerveza Poker Lata 330ml', 'Cerveza lager refrescante en lata.', 'S', 4.0, 3800, 220, 48, 'cerveza-lata-roja.png');
  prod(2, 6, 'Ron Medellín Añejo 3 Años 750ml', 'Ron añejo antioqueño.', 'S', 35, 58000, 22, 8, 'ron-3-anos.png');
  prod(4, 6, 'Whisky Old Parr 12 Años 750ml', 'Whisky escocés blended de 12 años.', 'S', 40, 165000, 9, 4, 'whisky.png');
  prod(5, 6, 'Vino Tinto Gato Negro Cabernet 750ml', 'Vino tinto chileno Cabernet Sauvignon.', 'S', 13, 38000, 18, 6, 'vino-tinto.png');
  prod(5, 6, 'Vino Blanco Santa Rita 120 Sauvignon 750ml', 'Vino blanco fresco y frutal.', 'S', 12.5, 42000, 3, 5, 'vino-blanco.png');
  prod(6, 6, 'Vodka Smirnoff 700ml', 'Vodka triple destilado.', 'S', 37.5, 62000, 14, 5, 'vodka.png');
  prod(6, 6, 'Tequila José Cuervo Especial Reposado 750ml', 'Tequila reposado mexicano.', 'S', 38, 98000, 7, 4, 'tequila.png');
  prod(8, 3, 'Papas Fritas Sabor Limón 110g', 'Papas fritas crocantes para acompañar.', 'N', NULL, 5500, 60, 15, 'papas-limon.png');
  COMMIT;
END;
/

-- 2. Ventas de ejemplo de los últimos 7 días (solo si aún no hay ventas)
DECLARE
  v_hay    NUMBER;
  v_venta  NUMBER;
  v_total  NUMBER;
  v_usr    NUMBER;
  v_metodo VARCHAR2(20);
  TYPE t_lista IS TABLE OF VARCHAR2(100);
  v_prods  t_lista := t_lista('Cerveza Club Colombia Dorada 330ml', 'Cerveza Poker Lata 330ml',
                              'Aguardiente Antioqueño Tapa Roja 750ml', 'Ron Medellín Añejo 3 Años 750ml',
                              'Gaseosa Coca Cola 2.5 Litros', 'Maní Tostado Salado 100g',
                              'Vino Tinto Gato Negro Cabernet 750ml', 'Whisky Old Parr 12 Años 750ml',
                              'Papas Fritas Sabor Limón 110g', 'Cerveza Águila Lata (unidad)');
  FUNCTION id_de(p_nombre VARCHAR2) RETURN NUMBER IS
    v_id NUMBER;
  BEGIN
    SELECT id_producto INTO v_id FROM producto WHERE nombre = p_nombre AND ROWNUM = 1;
    RETURN v_id;
  EXCEPTION WHEN NO_DATA_FOUND THEN RETURN NULL;
  END;
BEGIN
  SELECT COUNT(*) INTO v_hay FROM venta;
  IF v_hay > 0 THEN
    RETURN;
  END IF;
  SELECT MIN(id_usuario) INTO v_usr FROM usuario WHERE rol = 'ADMINISTRADOR' AND activo = 'S';

  FOR dia IN 0 .. 6 LOOP
    FOR n IN 1 .. 2 + MOD(dia * 3, 4) LOOP
      INSERT INTO venta (id_usuario, fecha, tipo_venta, edad_verificada)
      VALUES (v_usr, TRUNC(SYSDATE) - dia + (10 + n * 2) / 24, 'MOSTRADOR', 'S')
      RETURNING id_venta INTO v_venta;

      -- 2 o 3 productos distintos por venta
      FOR k IN 0 .. 1 + MOD(n, 2) LOOP
        DECLARE
          v_id NUMBER := id_de(v_prods(MOD(dia + n * 3 + k * 4, v_prods.COUNT) + 1));
          v_cant NUMBER := 1 + MOD(dia + n + k, 3) * 2;
        BEGIN
          IF v_id IS NOT NULL THEN
            INSERT INTO detalle_venta (id_venta, id_producto, cantidad, precio_unitario)
            SELECT v_venta, id_producto, v_cant, precio_venta FROM producto
             WHERE id_producto = v_id
               AND stock_actual >= v_cant
               AND NOT EXISTS (SELECT 1 FROM detalle_venta d
                                WHERE d.id_venta = v_venta AND d.id_producto = v_id);
          END IF;
        END;
      END LOOP;

      SELECT NVL(SUM(cantidad * precio_unitario), 0) INTO v_total
        FROM detalle_venta WHERE id_venta = v_venta;
      UPDATE venta SET total = v_total WHERE id_venta = v_venta;

      v_metodo := CASE MOD(dia + n, 4) WHEN 0 THEN 'EFECTIVO' WHEN 1 THEN 'NEQUI'
                                       WHEN 2 THEN 'TARJETA' ELSE 'EFECTIVO' END;
      INSERT INTO pago (id_venta, fecha, metodo, valor, estado)
      VALUES (v_venta, TRUNC(SYSDATE) - dia + (10 + n * 2) / 24, v_metodo, v_total, 'PAGADO');
    END LOOP;
  END LOOP;
  COMMIT;
END;
/

SELECT 'productos' AS que, COUNT(*) AS cuantos FROM producto
UNION ALL SELECT 'ventas', COUNT(*) FROM venta;
