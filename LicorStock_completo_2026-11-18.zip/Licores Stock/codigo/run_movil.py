"""Inicia LicorStock para abrirlo desde celulares conectados al mismo Wi-Fi.

Uso:  py run_movil.py      (o doble clic en iniciar_celulares.bat)

- Escucha en todas las interfaces (0.0.0.0) en el puerto 5000.
- Muestra la dirección para los celulares y genera el código QR en ..\\entregas\\qr_licorstock.png
- El modo debug va APAGADO: con debug encendido cualquiera en la red podría ejecutar
  código en esta PC desde la página de error de Flask.
"""
import socket
from pathlib import Path

from app import create_app

PUERTO = 5000
CARPETA_QR = Path(__file__).resolve().parent.parent / "entregas"


def ip_local():
    """IP de esta PC en la red Wi-Fi/LAN (la que usan los celulares para llegar aquí)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))  # no envía nada; solo elige la interfaz de salida
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def generar_qr(url):
    try:
        import segno
    except ImportError:
        print("  (Para el QR instala:  venv\\Scripts\\python -m pip install segno)")
        return None
    CARPETA_QR.mkdir(parents=True, exist_ok=True)
    destino = CARPETA_QR / "qr_licorstock.png"
    segno.make(url, error="m").save(destino, scale=12, border=3, dark="#241a1e")
    return destino


app = create_app()

if __name__ == "__main__":
    url = f"http://{ip_local()}:{PUERTO}/login?cliente=1"
    qr = generar_qr(url)
    print("\n" + "=" * 60)
    print("  LicorStock listo para celulares")
    print(f"  Dirección:  {url}")
    if qr:
        print(f"  Código QR:  {qr}")
    print("  Los celulares deben estar en el MISMO Wi-Fi que esta PC.")
    print("  Deja esta ventana abierta; ciérrala para apagar la app.")
    print("=" * 60 + "\n")
    app.run(host="0.0.0.0", port=PUERTO, debug=False, threaded=True)
