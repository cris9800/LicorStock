from datetime import date

import oracledb
from flask import (Blueprint, current_app, flash, redirect, render_template,
                   request, session, url_for)

from .. import db
from ..auth.decorators import rol_requerido

bp = Blueprint("ventas", __name__)

METODOS_PAGO = ("EFECTIVO", "TARJETA", "TRANSFERENCIA", "NEQUI", "DAVIPLATA")


def calcular_edad(nacimiento, hoy=None):
    hoy = hoy or date.today()
    return hoy.year - nacimiento.year - ((hoy.month, hoy.day) < (nacimiento.month, nacimiento.day))


def leer_items(form):
    """Agrupa las líneas del formulario (producto[] / cantidad[]) en {id_producto: cantidad}.

    detalle_venta tiene llave (id_venta, id_producto): un producto repetido se suma en una línea.
    """
    items = {}
    for id_prod, cant in zip(form.getlist("producto"), form.getlist("cantidad")):
        if not id_prod:
            continue
        try:
            cantidad = int(cant)
        except ValueError:
            raise ValueError("Las cantidades deben ser números enteros.") from None
        if cantidad <= 0:
            raise ValueError("Las cantidades deben ser mayores que cero.")
        items[int(id_prod)] = items.get(int(id_prod), 0) + cantidad
    if not items:
        raise ValueError("Agrega al menos un producto.")
    return items


def edad_verificada(cliente, edad_confirmada, edad_minima):
    """RF19: devuelve 'S' o 'N' para venta.edad_verificada.

    Si el cliente tiene fecha de nacimiento, la edad se calcula; si no, vale la
    confirmación del vendedor. El trigger trg_detalle_venta_ai rechaza los productos
    alcohólicos cuando la venta queda con 'N'.
    """
    if cliente and cliente["fecha_nacimiento"]:
        if calcular_edad(cliente["fecha_nacimiento"].date()) < edad_minima:
            raise ValueError(f"El cliente es menor de {edad_minima} años. No se puede vender.")
        return "S"
    return "S" if edad_confirmada else "N"


@bp.route("/")
@rol_requerido("VENDEDOR")
def lista():
    # ROWNUM en lugar de FETCH FIRST para que funcione también en Oracle 10g/11g
    ventas = db.query(
        "SELECT * FROM (SELECT v.id_venta, v.fecha, v.total, v.estado, "
        "TRIM(c.nombre || ' ' || c.apellido) AS cliente, "
        "u.username AS vendedor, d.estado AS estado_domicilio "
        "FROM venta v JOIN usuario u ON u.id_usuario = v.id_usuario "
        "LEFT JOIN cliente c ON c.id_cliente = v.id_cliente "
        "LEFT JOIN domicilio d ON d.id_venta = v.id_venta "
        "ORDER BY v.fecha DESC, v.id_venta DESC) WHERE ROWNUM <= 100"
    )
    return render_template("ventas/lista.html", ventas=ventas)


@bp.route("/nueva", methods=["GET", "POST"])
@rol_requerido("VENDEDOR")
def nueva():
    if request.method == "POST":
        try:
            id_venta = _registrar_venta(request.form)
            flash(f"Venta #{id_venta} registrada.", "success")
            return redirect(url_for("ventas.detalle", id_venta=id_venta))
        except ValueError as exc:
            flash(str(exc), "danger")
        except oracledb.DatabaseError as exc:
            flash(db.error_oracle(exc), "danger")

    productos = db.query(
        "SELECT p.id_producto, p.nombre, p.es_alcoholico, p.precio_venta, p.stock_actual, "
        "p.imagen, c.nombre AS categoria FROM producto p "
        "JOIN categoria c ON c.id_categoria = p.id_categoria "
        "WHERE p.activo = 'S' AND p.stock_actual > 0 ORDER BY c.nombre, p.nombre"
    )
    clientes = db.query(
        "SELECT id_cliente, tipo_documento, numero_documento, nombre, apellido, "
        "direccion, telefono, fecha_nacimiento FROM cliente "
        "WHERE activo = 'S' ORDER BY nombre"
    )
    return render_template("ventas/nueva.html", productos=productos, clientes=clientes,
                           metodos=METODOS_PAGO)


def _registrar_venta(form):
    """Registra venta, detalle, pago y domicilio en UNA transacción (RNF02)."""
    items = leer_items(form)
    metodo = form.get("metodo_pago")
    if metodo not in METODOS_PAGO:
        raise ValueError("Selecciona un método de pago válido.")

    id_cliente = form.get("id_cliente") or None
    cliente = None
    if id_cliente:
        cliente = db.query("SELECT * FROM cliente WHERE id_cliente = :id",
                           {"id": int(id_cliente)}, one=True)
    edad = edad_verificada(cliente, form.get("edad_verificada") == "S",
                           current_app.config["EDAD_MINIMA"])

    con_domicilio = form.get("con_domicilio") == "S"
    if con_domicilio and not form.get("dom_direccion"):
        raise ValueError("Para el domicilio se requiere la dirección de entrega.")

    conn = db.get_conn()
    try:
        with conn.cursor() as cur:
            id_venta = db.insert_returning_id(
                cur,
                "INSERT INTO venta (id_cliente, id_usuario, tipo_venta, edad_verificada) "
                "VALUES (:cli, :usr, :tipo, :edad)",
                {"cli": cliente["id_cliente"] if cliente else None,
                 "usr": session["id_usuario"],
                 "tipo": "DOMICILIO" if con_domicilio else "MOSTRADOR",
                 "edad": edad},
                "id_venta",
            )
            # El precio se toma de la base de datos, nunca del formulario.
            # El trigger trg_detalle_venta_ai valida stock y edad, y descuenta el inventario.
            for id_producto, cantidad in items.items():
                cur.execute(
                    "INSERT INTO detalle_venta (id_venta, id_producto, cantidad, precio_unitario) "
                    "SELECT :v, id_producto, :c, precio_venta FROM producto "
                    "WHERE id_producto = :p AND activo = 'S'",
                    {"v": id_venta, "c": cantidad, "p": id_producto},
                )
                if cur.rowcount == 0:
                    raise ValueError("Uno de los productos no existe o está inactivo.")

            total = cur.var(oracledb.NUMBER)
            cur.execute(
                "UPDATE venta SET total = (SELECT SUM(cantidad * precio_unitario) "
                "FROM detalle_venta WHERE id_venta = :v) "
                "WHERE id_venta = :v RETURNING total INTO :total",
                {"v": id_venta, "total": total},
            )
            cur.execute(
                "INSERT INTO pago (id_venta, metodo, valor, estado) VALUES (:v, :m, :valor, :e)",
                {"v": id_venta, "m": metodo, "valor": total.getvalue()[0],
                 "e": "PENDIENTE" if con_domicilio and metodo == "EFECTIVO" else "PAGADO"},
            )
            if con_domicilio:
                cur.execute(
                    "INSERT INTO domicilio (id_venta, direccion_entrega, telefono_contacto, "
                    "observaciones) VALUES (:v, :dir, :tel, :obs)",
                    {"v": id_venta, "dir": form["dom_direccion"],
                     "tel": form.get("dom_telefono") or None,
                     "obs": form.get("dom_observaciones") or None},
                )
        conn.commit()
        return id_venta
    except Exception:
        conn.rollback()
        raise


@bp.route("/<int:id_venta>")
@rol_requerido("VENDEDOR")
def detalle(id_venta):
    venta = db.query(
        "SELECT v.*, TRIM(c.nombre || ' ' || c.apellido) AS cliente, "
        "TRIM(c.tipo_documento || ' ' || c.numero_documento) AS documento, u.username AS vendedor "
        "FROM venta v JOIN usuario u ON u.id_usuario = v.id_usuario "
        "LEFT JOIN cliente c ON c.id_cliente = v.id_cliente WHERE v.id_venta = :id",
        {"id": id_venta}, one=True,
    )
    if not venta:
        flash("Venta no encontrada.", "warning")
        return redirect(url_for("ventas.lista"))
    lineas = db.query(
        "SELECT d.*, d.cantidad * d.precio_unitario AS subtotal, p.nombre, p.imagen, "
        "c.nombre AS categoria FROM detalle_venta d "
        "JOIN producto p ON p.id_producto = d.id_producto "
        "JOIN categoria c ON c.id_categoria = p.id_categoria WHERE d.id_venta = :id",
        {"id": id_venta},
    )
    pagos = db.query("SELECT * FROM pago WHERE id_venta = :id", {"id": id_venta})
    domicilio = db.query(
        "SELECT d.*, u.username AS repartidor FROM domicilio d "
        "LEFT JOIN usuario u ON u.id_usuario = d.id_repartidor WHERE d.id_venta = :id",
        {"id": id_venta}, one=True,
    )
    return render_template("ventas/detalle.html", venta=venta, lineas=lineas,
                           pagos=pagos, domicilio=domicilio)


def anular_venta(id_venta):
    """Anula la venta en UNA transacción.

    trg_venta_anulada_au devuelve el stock; los pagos quedan RECHAZADO (no cuentan en caja)
    y el domicilio activo pasa a CANCELADO.
    """
    conn = db.get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute("UPDATE venta SET estado = 'ANULADA' "
                        "WHERE id_venta = :v AND estado = 'COMPLETADA'", {"v": id_venta})
            if cur.rowcount == 0:
                raise ValueError("La venta ya estaba anulada.")
            cur.execute("UPDATE pago SET estado = 'RECHAZADO' WHERE id_venta = :v", {"v": id_venta})
            cur.execute("UPDATE domicilio SET estado = 'CANCELADO' WHERE id_venta = :v "
                        "AND estado IN ('PENDIENTE','EN_CAMINO')", {"v": id_venta})
        conn.commit()
    except Exception:
        conn.rollback()
        raise


@bp.route("/<int:id_venta>/anular", methods=["POST"])
@rol_requerido()
def anular(id_venta):
    try:
        anular_venta(id_venta)
        flash(f"Venta #{id_venta} anulada. Las unidades volvieron al inventario.", "info")
    except ValueError as exc:
        flash(str(exc), "warning")
    except oracledb.DatabaseError as exc:
        flash(db.error_oracle(exc), "danger")
    return redirect(url_for("ventas.detalle", id_venta=id_venta))
