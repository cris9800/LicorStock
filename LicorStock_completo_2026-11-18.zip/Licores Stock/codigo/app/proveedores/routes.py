import oracledb
from flask import Blueprint, flash, redirect, render_template, request, url_for

from .. import db
from ..auth.decorators import rol_requerido

bp = Blueprint("proveedores", __name__)

CAMPOS = ("nit", "nombre", "telefono", "direccion")


def _leer_formulario():
    datos = {c: (request.form.get(c) or "").strip() or None for c in CAMPOS}
    errores = []
    if not datos["nit"]:
        errores.append("El NIT es obligatorio.")
    if not datos["nombre"]:
        errores.append("El nombre es obligatorio.")
    return datos, errores


@bp.route("/")
@rol_requerido()
def lista():
    buscar = request.args.get("q", "").strip()
    proveedores = db.query(
        "SELECT pr.*, "
        "(SELECT COUNT(*) FROM producto p WHERE p.id_proveedor = pr.id_proveedor) AS num_productos, "
        "(SELECT COUNT(*) FROM compra c WHERE c.id_proveedor = pr.id_proveedor) AS num_compras "
        "FROM proveedor pr "
        "WHERE (:q IS NULL OR UPPER(pr.nombre) LIKE '%' || UPPER(:q) || '%' "
        "OR pr.nit LIKE '%' || :q || '%') "
        "ORDER BY pr.activo DESC, pr.nombre",
        {"q": buscar or None},
    )
    return render_template("proveedores/lista.html", proveedores=proveedores, buscar=buscar)


@bp.route("/nuevo", methods=["GET", "POST"])
@rol_requerido()
def nuevo():
    datos = {}
    if request.method == "POST":
        datos, errores = _leer_formulario()
        if not errores:
            try:
                db.execute(
                    "INSERT INTO proveedor (nit, nombre, telefono, direccion) "
                    "VALUES (:nit, :nombre, :telefono, :direccion)",
                    datos,
                )
                flash("Proveedor registrado.", "success")
                return redirect(url_for("proveedores.lista"))
            except oracledb.DatabaseError as exc:
                errores.append(db.error_oracle(exc))
        for e in errores:
            flash(e, "danger")
    return render_template("proveedores/form.html", proveedor=datos)


@bp.route("/<int:id_proveedor>/editar", methods=["GET", "POST"])
@rol_requerido()
def editar(id_proveedor):
    proveedor = db.query("SELECT * FROM proveedor WHERE id_proveedor = :id",
                         {"id": id_proveedor}, one=True)
    if not proveedor:
        flash("Proveedor no encontrado.", "warning")
        return redirect(url_for("proveedores.lista"))
    if request.method == "POST":
        datos, errores = _leer_formulario()
        if not errores:
            try:
                db.execute(
                    "UPDATE proveedor SET nit = :nit, nombre = :nombre, telefono = :telefono, "
                    "direccion = :direccion WHERE id_proveedor = :id_proveedor",
                    {**datos, "id_proveedor": id_proveedor},
                )
                flash("Proveedor actualizado.", "success")
                return redirect(url_for("proveedores.lista"))
            except oracledb.DatabaseError as exc:
                errores.append(db.error_oracle(exc))
        for e in errores:
            flash(e, "danger")
        proveedor = {**proveedor, **datos}
    return render_template("proveedores/form.html", proveedor=proveedor)


@bp.route("/<int:id_proveedor>/estado", methods=["POST"])
@rol_requerido()
def cambiar_estado(id_proveedor):
    db.execute(
        "UPDATE proveedor SET activo = CASE activo WHEN 'S' THEN 'N' ELSE 'S' END "
        "WHERE id_proveedor = :id", {"id": id_proveedor},
    )
    flash("Estado del proveedor actualizado.", "info")
    return redirect(url_for("proveedores.lista"))
