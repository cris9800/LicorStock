@echo off
cd /d "%~dp0"
echo Creando los administradores admin1 y admin2 (contrasena 1234)...
venv\Scripts\python crear_admins.py
pause
