"""Conexión a Oracle con python-oracledb.

Con Oracle 12c o superior usa el modo Thin (no requiere instalar nada más).
Con Oracle 10g/11g hay que instalar Oracle Instant Client y poner su ruta en
ORACLE_CLIENT_LIB (archivo .env) para activar el modo Thick.
"""
import oracledb
from flask import current_app, g

_pool = None


def init_pool(app):
    global _pool
    if app.config.get("ORACLE_JDBC_JAR"):
        # Oracle 10g sin Instant Client: se usa JDBC (ver app/jdbc_oracle.py)
        from . import jdbc_oracle
        _pool = jdbc_oracle.create_pool(
            user=app.config["ORACLE_USER"],
            password=app.config["ORACLE_PASSWORD"],
            dsn=app.config["ORACLE_DSN"],
            jar=app.config["ORACLE_JDBC_JAR"],
            jvm_dll=app.config.get("JAVA_JVM_DLL"),
        )
        return
    if app.config.get("ORACLE_CLIENT_LIB"):
        oracledb.init_oracle_client(lib_dir=app.config["ORACLE_CLIENT_LIB"])
    _pool = oracledb.create_pool(
        user=app.config["ORACLE_USER"],
        password=app.config["ORACLE_PASSWORD"],
        dsn=app.config["ORACLE_DSN"],
        min=1, max=5, increment=1,
    )


def get_conn():
    if "db" not in g:
        g.db = _pool.acquire()
    return g.db


def close_conn(_exc=None):
    conn = g.pop("db", None)
    if conn is not None:
        _pool.release(conn)


def _dict_rows(cursor):
    cols = [c[0].lower() for c in cursor.description]
    cursor.rowfactory = lambda *row: dict(zip(cols, row))


def query(sql, params=None, one=False):
    """SELECT parametrizado. Devuelve lista de dicts (o un dict con one=True)."""
    with get_conn().cursor() as cur:
        cur.execute(sql, params or {})
        _dict_rows(cur)
        return cur.fetchone() if one else cur.fetchall()


# Misma consulta que la vista v_productos_bajo_stock, escrita aquí para que la
# aplicación funcione también en bases donde la vista no se creó.
SQL_BAJO_STOCK = (
    "SELECT p.id_producto, p.nombre, c.nombre AS categoria, p.stock_actual, p.stock_minimo, p.imagen "
    "FROM producto p JOIN categoria c ON c.id_categoria = p.id_categoria "
    "WHERE p.activo = 'S' AND p.stock_actual <= p.stock_minimo"
)


def execute(sql, params=None, commit=True):
    """INSERT/UPDATE/DELETE parametrizado."""
    conn = get_conn()
    with conn.cursor() as cur:
        cur.execute(sql, params or {})
    if commit:
        conn.commit()


def insert_returning_id(cur, sql, params, id_col):
    """Inserta y devuelve el id generado (columna IDENTITY)."""
    out = cur.var(oracledb.NUMBER)
    cur.execute(f"{sql} RETURNING {id_col} INTO :new_id", {**params, "new_id": out})
    return int(out.getvalue()[0])


def error_oracle(exc):
    """Mensaje legible para errores lanzados con RAISE_APPLICATION_ERROR o restricciones."""
    err, = exc.args
    if 20000 <= err.code <= 20999:
        return err.message.split("\n")[0].split(": ", 1)[-1]
    if err.code == 1:
        return "Ya existe un registro con ese valor único."
    if err.code == 2290:
        return "Un valor no cumple las reglas del sistema (ej. cantidad negativa)."
    current_app.logger.exception(exc)
    return "Error en la base de datos."
