import oracledb
from flask import Blueprint, abort, flash, redirect, render_template, request, session, url_for

from .. import db
from ..auth.decorators import rol_requerido

bp = Blueprint("domicilios", __name__)

ESTADOS = ("PENDIENTE", "EN_CAMINO", "ENTREGADO", "CANCELADO")
# Avance permitido para el repartidor: PENDIENTE -> EN_CAMINO -> ENTREGADO
SIGUIENTE = {"PENDIENTE": "EN_CAMINO", "EN_CAMINO": "ENTREGADO"}


def _domicilio(id_domicilio):
    dom = db.query("SELECT * FROM domicilio WHERE id_domicilio = :id",
                   {"id": id_domicilio}, one=True)
    if not dom:
        abort(404)
    return dom


@bp.route("/")
@rol_requerido("VENDEDOR", "REPARTIDOR")
def lista():
    estado = request.args.get("estado") or None
    if estado not in ESTADOS:
        estado = None
    # Sin filtro se muestran los domicilios activos (pendientes y en camino)
    activos = None if estado else "S"
    # El repartidor ve los que tiene asignados y los pendientes sin asignar
    repartidor = session["id_usuario"] if session["rol"] == "REPARTIDOR" else None
    domicilios = db.query(
        "SELECT * FROM (SELECT d.*, v.total, v.fecha AS fecha_venta, "
        "TRIM(c.nombre || ' ' || c.apellido) AS cliente, u.username AS repartidor, "
        "(SELECT MIN(p.metodo) FROM pago p WHERE p.id_venta = d.id_venta) AS metodo_pago, "
        "(SELECT COUNT(*) FROM pago p WHERE p.id_venta = d.id_venta AND p.estado = 'PENDIENTE') "
        "AS pagos_pendientes "
        "FROM domicilio d JOIN venta v ON v.id_venta = d.id_venta "
        "LEFT JOIN cliente c ON c.id_cliente = v.id_cliente "
        "LEFT JOIN usuario u ON u.id_usuario = d.id_repartidor "
        "WHERE (:estado IS NULL OR d.estado = :estado) "
        "AND (:activos IS NULL OR d.estado IN ('PENDIENTE','EN_CAMINO')) "
        "AND (:rep IS NULL OR d.id_repartidor = :rep OR "
        "(d.id_repartidor IS NULL AND d.estado = 'PENDIENTE')) "
        "ORDER BY CASE d.estado WHEN 'EN_CAMINO' THEN 1 WHEN 'PENDIENTE' THEN 2 ELSE 3 END, "
        "d.fecha_pedido DESC) WHERE ROWNUM <= 200",
        {"estado": estado, "activos": activos, "rep": repartidor},
    )
    repartidores = db.query(
        "SELECT id_usuario, username FROM usuario WHERE rol = 'REPARTIDOR' AND activo = 'S' "
        "ORDER BY username")
    return render_template("domicilios/lista.html", domicilios=domicilios, estado=estado,
                           estados=ESTADOS, repartidores=repartidores)


@bp.route("/<int:id_domicilio>/asignar", methods=["POST"])
@rol_requerido("VENDEDOR", "REPARTIDOR")
def asignar(id_domicilio):
    dom = _domicilio(id_domicilio)
    if dom["estado"] not in ("PENDIENTE", "EN_CAMINO"):
        flash("Ese domicilio ya está cerrado.", "warning")
        return redirect(url_for("domicilios.lista"))
    if session["rol"] == "REPARTIDOR":
        # El repartidor solo puede tomar domicilios libres para sí mismo
        if dom["id_repartidor"] and dom["id_repartidor"] != session["id_usuario"]:
            abort(403)
        id_repartidor = session["id_usuario"]
    else:
        id_repartidor = request.form.get("id_repartidor", type=int)
        ok = id_repartidor and db.query(
            "SELECT 1 AS ok FROM usuario WHERE id_usuario = :u AND rol = 'REPARTIDOR' "
            "AND activo = 'S'", {"u": id_repartidor}, one=True)
        if not ok:
            flash("Selecciona un repartidor válido.", "danger")
            return redirect(url_for("domicilios.lista"))
    db.execute("UPDATE domicilio SET id_repartidor = :r WHERE id_domicilio = :id",
               {"r": id_repartidor, "id": id_domicilio})
    flash(f"Domicilio #{id_domicilio} asignado.", "success")
    return redirect(url_for("domicilios.lista"))


@bp.route("/<int:id_domicilio>/avanzar", methods=["POST"])
@rol_requerido("VENDEDOR", "REPARTIDOR")
def avanzar(id_domicilio):
    """PENDIENTE -> EN_CAMINO -> ENTREGADO. Al entregar, el pago contra entrega queda PAGADO."""
    dom = _domicilio(id_domicilio)
    if session["rol"] == "REPARTIDOR" and dom["id_repartidor"] != session["id_usuario"]:
        abort(403)
    nuevo = SIGUIENTE.get(dom["estado"])
    if not nuevo:
        flash("Ese domicilio ya está cerrado.", "warning")
        return redirect(url_for("domicilios.lista"))
    if not dom["id_repartidor"]:
        flash("Primero asigna un repartidor.", "warning")
        return redirect(url_for("domicilios.lista"))
    conn = db.get_conn()
    try:
        with conn.cursor() as cur:
            # trg_domicilio_bu guarda fecha_entrega al pasar a ENTREGADO
            cur.execute("UPDATE domicilio SET estado = :e WHERE id_domicilio = :id AND estado = :ant",
                        {"e": nuevo, "id": id_domicilio, "ant": dom["estado"]})
            if nuevo == "ENTREGADO":
                cur.execute("UPDATE pago SET estado = 'PAGADO', fecha = SYSDATE "
                            "WHERE id_venta = :v AND estado = 'PENDIENTE'", {"v": dom["id_venta"]})
        conn.commit()
    except oracledb.DatabaseError as exc:
        conn.rollback()
        flash(db.error_oracle(exc), "danger")
        return redirect(url_for("domicilios.lista"))
    flash(f"Domicilio #{id_domicilio}: {nuevo.replace('_', ' ').lower()}.", "success")
    return redirect(url_for("domicilios.lista"))


@bp.route("/<int:id_domicilio>/cancelar", methods=["POST"])
@rol_requerido("VENDEDOR")
def cancelar(id_domicilio):
    """Cancela el domicilio y anula la venta: el trigger trg_venta_anulada_au devuelve el stock."""
    dom = _domicilio(id_domicilio)
    if dom["estado"] not in ("PENDIENTE", "EN_CAMINO"):
        flash("Solo se pueden cancelar domicilios pendientes o en camino.", "warning")
        return redirect(url_for("domicilios.lista"))
    from ..ventas.routes import anular_venta
    try:
        anular_venta(dom["id_venta"])
    except oracledb.DatabaseError as exc:
        flash(db.error_oracle(exc), "danger")
        return redirect(url_for("domicilios.lista"))
    flash(f"Domicilio #{id_domicilio} cancelado. La venta quedó anulada y el stock se devolvió.", "info")
    return redirect(url_for("domicilios.lista"))
