"""Compara la base conectada (.env) con database/LicorStock_Oracle_revisado.sql
y lista las tablas, columnas, secuencias y triggers que faltan. Solo lee."""
import re
from pathlib import Path

from app import create_app, db

SQL = (Path(__file__).parent / "database" / "LicorStock_Oracle_revisado.sql").read_text(encoding="utf-8", errors="ignore")


def esperado():
    tablas = {}
    for m in re.finditer(r"CREATE TABLE (\w+)\s*\((.*?)\n\);", SQL, re.S | re.I):
        cols = []
        for linea in m.group(2).splitlines():
            linea = linea.strip()
            p = re.match(r"(\w+)\s+(NUMBER|VARCHAR2|CHAR|DATE|CLOB|TIMESTAMP)", linea, re.I)
            if p:
                cols.append(p.group(1).upper())
        tablas[m.group(1).upper()] = cols
    seqs = {s.upper() for s in re.findall(r"CREATE SEQUENCE (\w+)", SQL, re.I)}
    trgs = {t.upper() for t in re.findall(r"CREATE OR REPLACE TRIGGER (\w+)", SQL, re.I)}
    return tablas, seqs, trgs


app = create_app()
with app.app_context():
    tablas, seqs, trgs = esperado()
    hay_cols = {}
    for r in db.query("SELECT table_name, column_name FROM user_tab_columns"):
        hay_cols.setdefault(r["table_name"], set()).add(r["column_name"])
    hay_seq = {r["sequence_name"] for r in db.query("SELECT sequence_name FROM user_sequences")}
    hay_trg = {r["trigger_name"]: r["status"] for r in db.query("SELECT trigger_name, status FROM user_triggers")}

    problemas = 0
    for t, cols in tablas.items():
        if t not in hay_cols:
            print(f"FALTA TABLA: {t}")
            problemas += 1
            continue
        for c in cols:
            if c not in hay_cols[t]:
                print(f"FALTA COLUMNA: {t}.{c}")
                problemas += 1
    for s in sorted(seqs - hay_seq):
        print(f"FALTA SECUENCIA: {s}")
        problemas += 1
    for t in sorted(trgs):
        if t not in hay_trg:
            print(f"FALTA TRIGGER: {t}")
            problemas += 1
        elif hay_trg[t] != "ENABLED":
            print(f"TRIGGER DESACTIVADO: {t}")
            problemas += 1
    for t in tablas:
        if t in hay_cols:
            n = db.query(f"SELECT COUNT(*) AS n FROM {t}", one=True)["n"]
            print(f"  {t}: {n} filas")
    print()
    print("TODO BIEN: la base tiene todo lo que necesita la app." if problemas == 0
          else f"Se encontraron {problemas} diferencias. Manda una foto de esta ventana a Claude.")
