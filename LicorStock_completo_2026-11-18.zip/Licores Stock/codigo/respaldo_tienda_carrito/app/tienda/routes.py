from functools import wraps

from flask import Blueprint, flash, redirect, render_template, request, session, url_for

from .. import db

bp = Blueprint("tienda", __name__)


def cliente_requerido(vista):
    """Solo clientes que confirmaron su mayoría de edad en el login."""
    @wraps(vista)
    def envoltura(*args, **kwargs):
        if not session.get("cliente"):
            flash("Confirma que eres mayor de edad para ver el catálogo.", "warning")
            return redirect(url_for("auth.login"))
        return vista(*args, **kwargs)
    return envoltura


@bp.route("/")
@cliente_requerido
def catalogo():
    buscar = request.args.get("q", "").strip()
    productos = db.query(
        "SELECT p.id_producto, p.nombre, p.descripcion, p.precio_venta, p.stock_actual, "
        "p.es_alcoholico, p.grado_alcohol, p.imagen, c.nombre AS categoria "
        "FROM producto p JOIN categoria c ON c.id_categoria = p.id_categoria "
        "WHERE p.activo = 'S' AND (:q IS NULL OR UPPER(p.nombre) LIKE '%' || UPPER(:q) || '%') "
        "ORDER BY c.nombre, p.nombre",
        {"q": buscar or None},
    )
    return render_template("tienda/catalogo.html", productos=productos, buscar=buscar)


@bp.route("/salir")
def salir():
    session.clear()
    return redirect(url_for("auth.login"))
