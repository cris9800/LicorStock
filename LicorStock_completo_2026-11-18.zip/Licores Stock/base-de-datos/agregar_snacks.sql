-- =====================================================================
-- LicorStock - Agrega 25 snacks (con foto)
-- Esquema: LICOLERIA (Oracle 10g XE). En SQL Developer: F5.
-- Las fotos van en codigo\app\static\img\productos\ (archivos sn-*.jpg,
-- copia en fotos_snacks.zip).
-- Usa la categoria "Snacks y picadas" (o "Snacks"); si no existe, crea "Snacks".
-- Solo INSERTA. No borra nada. Se puede correr varias veces:
-- si un producto con el mismo nombre ya existe, solo le pone la foto y lo activa.
-- =====================================================================
SET SERVEROUTPUT ON
SET DEFINE OFF

DECLARE
  v_ins NUMBER := 0; v_act NUMBER := 0; v_cat NUMBER; v_prov NUMBER;

  PROCEDURE a(p_nombre VARCHAR2, p_precio NUMBER, p_imagen VARCHAR2) IS
    v_id NUMBER; v_n NUMBER; v_stock NUMBER;
  BEGIN
    SELECT MIN(id_producto) INTO v_id FROM producto WHERE UPPER(nombre) = UPPER(p_nombre);
    IF v_id IS NOT NULL THEN
      UPDATE producto SET imagen = p_imagen, activo = 'S' WHERE id_producto = v_id;
      v_act := v_act + 1; RETURN;
    END IF;
    v_stock := CASE WHEN p_precio >= 20000 THEN 24 WHEN p_precio >= 7000 THEN 48 ELSE 96 END;
    LOOP
      SELECT seq_producto.NEXTVAL INTO v_id FROM dual;
      SELECT COUNT(*) INTO v_n FROM producto WHERE id_producto = v_id;
      EXIT WHEN v_n = 0;
    END LOOP;
    INSERT INTO producto (id_producto, id_categoria, id_proveedor, nombre, descripcion, es_alcoholico,
                          grado_alcohol, precio_venta, stock_actual, stock_minimo, imagen, activo)
    VALUES (v_id, v_cat, v_prov, p_nombre, 'Snack para acompañar tus bebidas.', 'N',
            0, p_precio, v_stock, TRUNC(v_stock/5), p_imagen, 'S');
    v_ins := v_ins + 1;
  END;

BEGIN
  SELECT MIN(id_categoria) INTO v_cat FROM categoria
   WHERE UPPER(nombre) IN ('SNACKS Y PICADAS', 'SNACKS');
  IF v_cat IS NULL THEN
    SELECT seq_categoria.NEXTVAL INTO v_cat FROM dual;
    INSERT INTO categoria (id_categoria, nombre, descripcion)
    VALUES (v_cat, 'Snacks', 'Pasabocas, frutos secos, dulces y charcuteria.');
  END IF;
  SELECT MIN(id_proveedor) INTO v_prov FROM proveedor WHERE nit = '860999000';

  a('Almendra Francesa x 80gr', 5200, 'sn-almendra-francesa-x-80gr.jpg');
  a('Almendra Tostada de 100gr', 14900, 'sn-almendra-tostada-de-100gr.jpg');
  a('Dulces Cavendish & Harvey x 200gs Sabores Surtidos', 14900, 'sn-dulces-cavendish-harvey-x-200gs.jpg');
  a('Galleta Almendra Kurabie Greco 120gr', 12900, 'sn-galleta-almendra-kurabie-greco-120gr.jpg');
  a('Galletas de Almendra Kurabie Greco 50 gr', 7900, 'sn-galletas-de-almendra-kurabie-greco-50gr.jpg');
  a('Naranja Deshidratada 50gr', 15900, 'sn-naranja-deshidratada-50gr.jpg');
  a('Piña Deshidratada 50gr', 15900, 'sn-pina-deshidratada-50gr.jpg');
  a('Queso Campo Real Paipa 250gr', 24900, 'sn-queso-campo-real-paipa-250gr.jpg');
  a('Cábano Especial 125g', 19800, 'sn-cabano-especial-125g.jpg');
  a('Cábano Especial 50g', 8600, 'sn-cabano-especial-50g.jpg');
  a('Mix de Madurados x 125g', 31900, 'sn-mix-de-madurados-x-125g.jpg');
  a('Pringles Sabor Original x 124g', 16990, 'sn-pringles-sabor-original-x-124g.jpg');
  a('Galleta de almendra Kurabie Greco x 80gr', 9600, 'sn-galleta-de-almendra-kurabie-greco-x-80gr.jpg');
  a('Maní Hatsu Sal de Himalaya x 40gr', 1990, 'sn-mani-hatsu-sal-de-himalaya-x-40gr.jpg');
  a('Pirulin x 300g', 26900, 'sn-pirulin-x-300g.jpg');
  a('De Todito Natural pequeño x 45g', 3400, 'sn-de-todito-natural-pequeno-x-45g.jpg');
  a('De Todito Natural Familiar x 140g', 11000, 'sn-de-todito-natural-familiar-x-140g.jpg');
  a('De Todito BBQ x 45g', 3400, 'sn-de-todito-bbq-x-45g.jpg');
  a('ACT II con Extra Mantequilla 91g Crispetas para Microondas', 6000, 'sn-act-ii-extra-mantequilla-91g.jpg');
  a('Maní salado Manitoba x 200g', 4000, 'sn-mani-salado-manitoba-x-200g.jpg');
  a('Pate de Champagne x 78gr', 14250, 'sn-pate-de-champagne-x-78gr.jpg');
  a('Torta de Turrón x 150g', 22900, 'sn-torta-de-turron-x-150g.jpg');
  a('Jamón Serrano Reserva x 100g', 26900, 'sn-jamon-serrano-reserva-x-100g.jpg');
  a('Tocineta Ahumada Tajada x 500g', 24900, 'sn-tocineta-ahumada-tajada-x-500g.jpg');
  a('Chiclets Trident Menta x 6und', 3000, 'sn-chiclets-trident-menta-x-6und.jpg');

  COMMIT;
  DBMS_OUTPUT.PUT_LINE('Snacks insertados: ' || v_ins || ' | ya existian (foto actualizada): ' || v_act);
END;
/

SELECT c.nombre AS categoria, COUNT(p.id_producto) AS activos
  FROM categoria c LEFT JOIN producto p ON p.id_categoria = c.id_categoria AND p.activo = 'S'
 GROUP BY c.nombre ORDER BY c.nombre;
