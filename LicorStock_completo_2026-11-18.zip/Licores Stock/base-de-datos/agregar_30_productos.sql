-- =====================================================================
-- LicorStock - Agrega 30 productos nuevos (licores) al inventario
-- Esquema: LICOLERIA  (Oracle 10g XE)
--
-- * NO borra ni modifica nada: solo inserta.
-- * Se puede correr varias veces: si un producto con el mismo nombre
--   ya existe, lo salta.
-- * El id sale de la secuencia seq_producto.
-- * La foto (columna IMAGEN) queda vacia: la app muestra la imagen de
--   la categoria. Luego puedes subir la foto real desde "Editar producto".
--
-- Como correrlo en SQL Developer: abre este archivo en la conexion
-- de LICOLERIA y presiona F5 (Ejecutar script).
-- =====================================================================
SET SERVEROUTPUT ON

DECLARE
  v_insertados NUMBER := 0;
  v_saltados   NUMBER := 0;

  PROCEDURE agregar(p_categoria VARCHAR2, p_nit_prov VARCHAR2, p_nombre VARCHAR2,
                    p_descripcion VARCHAR2, p_grado NUMBER, p_precio NUMBER,
                    p_stock NUMBER, p_minimo NUMBER) IS
    v_cat  NUMBER;
    v_prov NUMBER;
    v_id   NUMBER;
    v_n    NUMBER;
  BEGIN
    SELECT COUNT(*) INTO v_n FROM producto WHERE UPPER(nombre) = UPPER(p_nombre);
    IF v_n > 0 THEN
      v_saltados := v_saltados + 1;
      DBMS_OUTPUT.PUT_LINE('Ya existia: ' || p_nombre);
      RETURN;
    END IF;

    SELECT MIN(id_categoria) INTO v_cat FROM categoria WHERE UPPER(nombre) = UPPER(p_categoria);
    IF v_cat IS NULL THEN
      SELECT MIN(id_categoria) INTO v_cat FROM categoria WHERE UPPER(nombre) = 'OTROS LICORES';
    END IF;

    SELECT MIN(id_proveedor) INTO v_prov FROM proveedor WHERE nit = p_nit_prov;

    -- id de la secuencia (por si acaso, salta ids que ya esten ocupados)
    LOOP
      SELECT seq_producto.NEXTVAL INTO v_id FROM dual;
      SELECT COUNT(*) INTO v_n FROM producto WHERE id_producto = v_id;
      EXIT WHEN v_n = 0;
    END LOOP;

    INSERT INTO producto (id_producto, id_categoria, id_proveedor, nombre, descripcion,
                          es_alcoholico, grado_alcohol, precio_venta, stock_actual, stock_minimo)
    VALUES (v_id, v_cat, v_prov, p_nombre, p_descripcion,
            'S', p_grado, p_precio, p_stock, p_minimo);
    v_insertados := v_insertados + 1;
  END;

BEGIN
  -- ---------------- Cervezas (6) ----------------
  agregar('Cervezas', '890200300', 'Cerveza Poker Lata 330ml', 'Cerveza rubia tipo Lager, la de los amigos (venta regulada).', 4.0, 3500, 240, 48);
  agregar('Cervezas', '890200300', 'Cerveza Club Colombia Dorada Botella 330ml', 'Cerveza Premium Lager colombiana en botella de vidrio (venta regulada).', 4.7, 4200, 180, 36);
  agregar('Cervezas', '890200300', 'Cerveza Costeña Bacana Lata 330ml', 'Cerveza suave y refrescante de la costa (venta regulada).', 4.0, 3000, 200, 48);
  agregar('Cervezas', '890200300', 'Cerveza Corona Extra Botella 355ml', 'Cerveza mexicana tipo Pilsner, ideal con limón (venta regulada).', 4.5, 6500, 120, 24);
  agregar('Cervezas', '890200300', 'Cerveza Heineken Lata 330ml', 'Cerveza holandesa Premium Lager (venta regulada).', 5.0, 4800, 150, 24);
  agregar('Cervezas', '890200300', 'Cerveza Stella Artois Botella 330ml', 'Cerveza belga tipo Pilsner (venta regulada).', 5.0, 6000, 90, 24);

  -- ---------------- Rones (5) ----------------
  agregar('Rones', '890200300', 'Ron Medellín Añejo 3 Años 750ml', 'Ron añejo colombiano, suave y aromático (venta regulada).', 37.5, 52000, 45, 8);
  agregar('Rones', '890200300', 'Ron Medellín 8 Años 750ml', 'Ron extra añejo, añejado 8 años en barricas de roble (venta regulada).', 40.0, 98000, 20, 5);
  agregar('Rones', '890200300', 'Ron Viejo de Caldas 375ml', 'Media botella de ron añejo tradicional (venta regulada).', 35.0, 36000, 60, 10);
  agregar('Rones', '890200300', 'Ron Bacardí Carta Blanca 750ml', 'Ron blanco ideal para cócteles como mojito y daiquirí (venta regulada).', 37.5, 62000, 35, 6);
  agregar('Rones', '890200300', 'Ron Havana Club Añejo 7 Años 750ml', 'Ron cubano añejo de 7 años, para tomar solo o en las rocas (venta regulada).', 40.0, 115000, 18, 4);

  -- ---------------- Aguardientes (6) ----------------
  agregar('Aguardientes', '890200300', 'Aguardiente Antioqueño Tapa Azul 750ml', 'Aguardiente sin azúcar, el más pedido (venta regulada).', 24.0, 52000, 80, 15);
  agregar('Aguardientes', '890200300', 'Aguardiente Antioqueño Tapa Azul 375ml', 'Media de aguardiente sin azúcar (venta regulada).', 24.0, 29000, 100, 20);
  agregar('Aguardientes', '890200300', 'Aguardiente Antioqueño Tapa Roja 750ml', 'Aguardiente tradicional con azúcar (venta regulada).', 29.0, 54000, 50, 10);
  agregar('Aguardientes', '890200300', 'Aguardiente Néctar Club 750ml', 'Aguardiente de Cundinamarca, sabor anisado suave (venta regulada).', 24.0, 45000, 60, 10);
  agregar('Aguardientes', '890200300', 'Aguardiente Amarillo de Manzanares 750ml', 'Aguardiente de Caldas con toque de miel (venta regulada).', 29.0, 50000, 40, 8);
  agregar('Aguardientes', '890200300', 'Aguardiente Cristal sin Azúcar 750ml', 'Aguardiente caldense sin azúcar (venta regulada).', 24.0, 47000, 55, 10);

  -- ---------------- Whisky (5) ----------------
  agregar('Whisky', '890200300', 'Whisky Old Parr 12 Años 750ml', 'Whisky escocés blended de 12 años, en su clásica botella (venta regulada).', 40.0, 175000, 15, 4);
  agregar('Whisky', '890200300', 'Whisky Johnnie Walker Red Label 700ml', 'Whisky escocés blended, intenso y ahumado (venta regulada).', 40.0, 95000, 25, 5);
  agregar('Whisky', '890200300', 'Whisky Buchanan''s 12 Años 750ml', 'Whisky escocés de lujo de 12 años, suave y equilibrado (venta regulada).', 40.0, 185000, 12, 3);
  agregar('Whisky', '890200300', 'Whisky Chivas Regal 12 Años 700ml', 'Whisky escocés blended premium de 12 años (venta regulada).', 40.0, 170000, 12, 3);
  agregar('Whisky', '890200300', 'Whiskey Jack Daniel''s Old No. 7 700ml', 'Whiskey de Tennessee filtrado en carbón de maple (venta regulada).', 40.0, 135000, 18, 4);

  -- ---------------- Vinos (4) ----------------
  agregar('Vinos', '890200300', 'Vino Tinto Gato Negro Cabernet Sauvignon 750ml', 'Vino tinto chileno, frutal y fácil de tomar (venta regulada).', 13.0, 32000, 40, 8);
  agregar('Vinos', '890200300', 'Vino Tinto Casillero del Diablo Merlot 750ml', 'Vino tinto chileno de cuerpo medio (venta regulada).', 13.5, 55000, 30, 6);
  agregar('Vinos', '890200300', 'Vino Blanco Santa Rita 120 Sauvignon Blanc 750ml', 'Vino blanco chileno fresco, ideal con pescados (venta regulada).', 12.5, 34000, 30, 6);
  agregar('Vinos', '890200300', 'Vino Espumoso JP Chenet Brut 750ml', 'Espumoso francés para celebraciones (venta regulada).', 11.0, 58000, 24, 5);

  -- ---------------- Otros licores (4) ----------------
  agregar('Otros licores', '890200300', 'Tequila José Cuervo Especial Reposado 750ml', 'Tequila mexicano reposado (venta regulada).', 38.0, 105000, 20, 4);
  agregar('Otros licores', '890200300', 'Vodka Absolut Original 700ml', 'Vodka sueco puro, ideal para cócteles (venta regulada).', 40.0, 85000, 22, 5);
  agregar('Otros licores', '890200300', 'Ginebra Gordon''s London Dry 700ml', 'Ginebra inglesa seca, perfecta para gin tonic (venta regulada).', 37.5, 70000, 18, 4);
  agregar('Otros licores', '890200300', 'Crema de Whisky Baileys Original 700ml', 'Licor de crema irlandesa con whisky (venta regulada).', 17.0, 82000, 20, 4);

  COMMIT;
  DBMS_OUTPUT.PUT_LINE('Productos insertados: ' || v_insertados || ' | ya existian: ' || v_saltados);
END;
/

-- Verificacion: productos por categoria
SELECT c.nombre AS categoria, COUNT(p.id_producto) AS productos
  FROM categoria c LEFT JOIN producto p ON p.id_categoria = c.id_categoria
 GROUP BY c.nombre
 ORDER BY c.nombre;
