@echo off
cd /d "%~dp0"
echo Revisando la base de datos (solo lectura, no cambia nada)...
venv\Scripts\python revisar_base.py 2>nul
pause
