import secrets
from pathlib import Path

import oracledb
from flask import (Blueprint, abort, current_app, flash, redirect, render_template, request,
                   session, url_for)

from .. import db
from ..auth.decorators import login_requerido, rol_requerido

bp = Blueprint("productos", __name__)

CAMPOS = ("id_categoria", "id_proveedor", "nombre", "descripcion", "grado_alcohol",
          "precio_venta", "stock_minimo")


def _leer_formulario():
    datos = {c: (request.form.get(c) or "").strip() or None for c in CAMPOS}
    datos["es_alcoholico"] = "S" if request.form.get("es_alcoholico") == "S" else "N"
    errores = []
    if not datos["nombre"]:
        errores.append("El nombre es obligatorio.")
    if not datos["id_categoria"]:
        errores.append("Selecciona una categoría.")
    for campo in ("precio_venta", "stock_minimo", "grado_alcohol"):
        valor = datos[campo]
        if valor is None:
            continue
        try:
            numero = float(valor)
        except ValueError:
            errores.append(f"El campo {campo} debe ser numérico.")
            continue
        if numero < 0:
            errores.append(f"El campo {campo} no puede ser negativo.")
        datos[campo] = numero
    if datos["precio_venta"] is None:
        errores.append("El precio de venta es obligatorio.")
    if datos["stock_minimo"] is None:
        datos["stock_minimo"] = 5
    if datos["es_alcoholico"] == "N":
        datos["grado_alcohol"] = None
    return datos, errores


# Firmas de archivo (primeros bytes) de los formatos de imagen permitidos
_FIRMAS = {b"\xff\xd8\xff": ".jpg", b"\x89PNG": ".png", b"RIFF": ".webp"}


def _carpeta_fotos():
    carpeta = Path(current_app.static_folder) / "img" / "productos"
    carpeta.mkdir(parents=True, exist_ok=True)
    return carpeta


def _guardar_foto(errores):
    """Guarda la foto subida en static/img/productos y devuelve el nombre del archivo.

    Devuelve None si no se subió nada. Revisa el contenido real del archivo
    (no solo la extensión) para aceptar únicamente JPG, PNG o WEBP.
    """
    archivo = request.files.get("foto")
    if not archivo or not archivo.filename:
        return None
    cabecera = archivo.stream.read(12)
    archivo.stream.seek(0)
    ext = next((e for firma, e in _FIRMAS.items() if cabecera.startswith(firma)), None)
    if ext == ".webp" and cabecera[8:12] != b"WEBP":
        ext = None
    if not ext:
        errores.append("La foto debe ser una imagen JPG, PNG o WEBP.")
        return None
    nombre = f"prod-{secrets.token_hex(6)}{ext}"
    archivo.save(_carpeta_fotos() / nombre)
    return nombre


def _borrar_foto(nombre):
    """Borra una foto subida desde la app (solo las que empiezan por 'prod-')."""
    if nombre and nombre.startswith("prod-"):
        (_carpeta_fotos() / Path(nombre).name).unlink(missing_ok=True)


def _opciones():
    return {
        "categorias": db.query(
            "SELECT id_categoria, nombre FROM categoria WHERE activo = 'S' ORDER BY nombre"),
        "proveedores": db.query(
            "SELECT id_proveedor, nombre FROM proveedor WHERE activo = 'S' ORDER BY nombre"),
    }


@bp.route("/")
@login_requerido
def lista():
    buscar = request.args.get("q", "").strip()
    productos = db.query(
        "SELECT p.*, c.nombre AS categoria, pr.nombre AS proveedor FROM producto p "
        "JOIN categoria c ON c.id_categoria = p.id_categoria "
        "LEFT JOIN proveedor pr ON pr.id_proveedor = p.id_proveedor "
        "WHERE (:q IS NULL OR UPPER(p.nombre) LIKE '%' || UPPER(:q) || '%') "
        "ORDER BY p.activo DESC, p.nombre",
        {"q": buscar or None},
    )
    return render_template("productos/lista.html", productos=productos, buscar=buscar)


@bp.route("/nuevo", methods=["GET", "POST"])
@rol_requerido()
def nuevo():
    datos = {"es_alcoholico": "S"}
    if request.method == "POST":
        datos, errores = _leer_formulario()
        foto = None if errores else _guardar_foto(errores)
        if not errores:
            try:
                db.execute(
                    "INSERT INTO producto (id_categoria, id_proveedor, nombre, descripcion, "
                    "es_alcoholico, grado_alcohol, precio_venta, stock_minimo, imagen) VALUES "
                    "(:id_categoria, :id_proveedor, :nombre, :descripcion, :es_alcoholico, "
                    ":grado_alcohol, :precio_venta, :stock_minimo, :imagen)",
                    {**datos, "imagen": foto},
                )
                flash("Producto registrado.", "success")
                return redirect(url_for("productos.lista"))
            except oracledb.DatabaseError as exc:
                _borrar_foto(foto)
                errores.append(db.error_oracle(exc))
        for e in errores:
            flash(e, "danger")
    return render_template("productos/form.html", producto=datos, **_opciones())


@bp.route("/<int:id_producto>/editar", methods=["GET", "POST"])
@rol_requerido()
def editar(id_producto):
    producto = db.query("SELECT p.*, c.nombre AS categoria FROM producto p "
                        "JOIN categoria c ON c.id_categoria = p.id_categoria "
                        "WHERE p.id_producto = :id", {"id": id_producto}, one=True)
    if not producto:
        flash("Producto no encontrado.", "warning")
        return redirect(url_for("productos.lista"))
    if request.method == "POST":
        datos, errores = _leer_formulario()
        foto = None if errores else _guardar_foto(errores)
        anterior = producto.get("imagen")
        if foto:
            imagen = foto
        elif request.form.get("quitar_foto") == "S":
            imagen = None
        else:
            imagen = anterior
        if not errores:
            try:
                db.execute(
                    "UPDATE producto SET id_categoria = :id_categoria, id_proveedor = :id_proveedor, "
                    "nombre = :nombre, descripcion = :descripcion, es_alcoholico = :es_alcoholico, "
                    "grado_alcohol = :grado_alcohol, precio_venta = :precio_venta, "
                    "stock_minimo = :stock_minimo, imagen = :imagen WHERE id_producto = :id_producto",
                    {**datos, "imagen": imagen, "id_producto": id_producto},
                )
                if imagen != anterior:
                    _borrar_foto(anterior)
                flash("Producto actualizado.", "success")
                return redirect(url_for("productos.lista"))
            except oracledb.DatabaseError as exc:
                _borrar_foto(foto)
                errores.append(db.error_oracle(exc))
        for e in errores:
            flash(e, "danger")
        producto = {**producto, **datos}
    return render_template("productos/form.html", producto=producto, **_opciones())


@bp.route("/<int:id_producto>/estado", methods=["POST"])
@rol_requerido()
def cambiar_estado(id_producto):
    db.execute(
        "UPDATE producto SET activo = CASE activo WHEN 'S' THEN 'N' ELSE 'S' END "
        "WHERE id_producto = :id", {"id": id_producto},
    )
    flash("Estado del producto actualizado.", "info")
    return redirect(url_for("productos.lista"))


@bp.route("/categorias", methods=["GET", "POST"])
@login_requerido
def categorias():
    if request.method == "POST":
        if session.get("rol") != "ADMINISTRADOR":
            abort(403)
        nombre = request.form.get("nombre", "").strip()
        if not nombre:
            flash("El nombre es obligatorio.", "danger")
        else:
            try:
                db.execute("INSERT INTO categoria (nombre, descripcion) VALUES (:n, :d)",
                           {"n": nombre, "d": request.form.get("descripcion") or None})
                flash("Categoría creada.", "success")
            except oracledb.DatabaseError as exc:
                flash(db.error_oracle(exc), "danger")
        return redirect(url_for("productos.categorias"))
    filas = db.query(
        "SELECT c.*, (SELECT COUNT(*) FROM producto p WHERE p.id_categoria = c.id_categoria) "
        "AS num_productos FROM categoria c ORDER BY c.nombre"
    )
    return render_template("productos/categorias.html", categorias=filas)
