import oracledb
from flask import Blueprint, flash, redirect, render_template, request, session, url_for

from .. import db
from ..auth.decorators import rol_requerido

bp = Blueprint("compras", __name__)


def leer_items(form):
    """Agrupa las líneas del formulario en {id_producto: (cantidad, costo_unitario)}.

    detalle_compra tiene llave (id_compra, id_producto): un producto repetido se suma
    en una línea y conserva el último costo escrito.
    """
    items = {}
    for id_prod, cant, costo in zip(form.getlist("producto"), form.getlist("cantidad"),
                                    form.getlist("costo")):
        if not id_prod:
            continue
        try:
            cantidad = int(cant)
            costo_unitario = int(float(costo))
        except ValueError:
            raise ValueError("Cantidades y costos deben ser números.") from None
        if cantidad <= 0:
            raise ValueError("Las cantidades deben ser mayores que cero.")
        if costo_unitario < 0:
            raise ValueError("El costo no puede ser negativo.")
        anterior = items.get(int(id_prod), (0, 0))[0]
        items[int(id_prod)] = (anterior + cantidad, costo_unitario)
    if not items:
        raise ValueError("Agrega al menos un producto.")
    return items


@bp.route("/")
@rol_requerido()
def lista():
    compras = db.query(
        "SELECT * FROM (SELECT c.id_compra, c.fecha, c.total, pr.nombre AS proveedor, "
        "u.username AS usuario, "
        "(SELECT SUM(d.cantidad) FROM detalle_compra d WHERE d.id_compra = c.id_compra) AS unidades "
        "FROM compra c JOIN proveedor pr ON pr.id_proveedor = c.id_proveedor "
        "JOIN usuario u ON u.id_usuario = c.id_usuario "
        "ORDER BY c.fecha DESC, c.id_compra DESC) WHERE ROWNUM <= 100"
    )
    return render_template("compras/lista.html", compras=compras)


@bp.route("/nueva", methods=["GET", "POST"])
@rol_requerido()
def nueva():
    if request.method == "POST":
        try:
            id_compra = _registrar_compra(request.form)
            flash(f"Compra #{id_compra} registrada. El stock ya se actualizó.", "success")
            return redirect(url_for("compras.detalle", id_compra=id_compra))
        except ValueError as exc:
            flash(str(exc), "danger")
        except oracledb.DatabaseError as exc:
            flash(db.error_oracle(exc), "danger")

    proveedores = db.query(
        "SELECT id_proveedor, nombre, nit FROM proveedor WHERE activo = 'S' ORDER BY nombre")
    productos = db.query(
        "SELECT id_producto, nombre, id_proveedor, stock_actual FROM producto "
        "WHERE activo = 'S' ORDER BY nombre"
    )
    return render_template("compras/nueva.html", proveedores=proveedores, productos=productos)


def _registrar_compra(form):
    """Registra la compra y su detalle en UNA transacción.

    El trigger trg_detalle_compra_ai suma el stock y deja la ENTRADA en movimientos.
    """
    if not form.get("id_proveedor"):
        raise ValueError("Selecciona el proveedor.")
    items = leer_items(form)

    conn = db.get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT 1 FROM proveedor WHERE id_proveedor = :p AND activo = 'S'",
                        {"p": int(form["id_proveedor"])})
            if not cur.fetchone():
                raise ValueError("El proveedor no existe o está inactivo.")
            id_compra = db.insert_returning_id(
                cur,
                "INSERT INTO compra (id_proveedor, id_usuario) VALUES (:prov, :usr)",
                {"prov": int(form["id_proveedor"]), "usr": session["id_usuario"]},
                "id_compra",
            )
            for id_producto, (cantidad, costo) in items.items():
                cur.execute(
                    "INSERT INTO detalle_compra (id_compra, id_producto, cantidad, costo_unitario) "
                    "SELECT :c, id_producto, :cant, :costo FROM producto "
                    "WHERE id_producto = :p AND activo = 'S'",
                    {"c": id_compra, "cant": cantidad, "costo": costo, "p": id_producto},
                )
                if cur.rowcount == 0:
                    raise ValueError("Uno de los productos no existe o está inactivo.")
            cur.execute(
                "UPDATE compra SET total = (SELECT SUM(cantidad * costo_unitario) "
                "FROM detalle_compra WHERE id_compra = :c) WHERE id_compra = :c",
                {"c": id_compra},
            )
        conn.commit()
        return id_compra
    except Exception:
        conn.rollback()
        raise


@bp.route("/<int:id_compra>")
@rol_requerido()
def detalle(id_compra):
    compra = db.query(
        "SELECT c.*, pr.nombre AS proveedor, pr.nit, u.username AS usuario FROM compra c "
        "JOIN proveedor pr ON pr.id_proveedor = c.id_proveedor "
        "JOIN usuario u ON u.id_usuario = c.id_usuario WHERE c.id_compra = :id",
        {"id": id_compra}, one=True,
    )
    if not compra:
        flash("Compra no encontrada.", "warning")
        return redirect(url_for("compras.lista"))
    lineas = db.query(
        "SELECT d.*, d.cantidad * d.costo_unitario AS subtotal, p.nombre, p.precio_venta "
        "FROM detalle_compra d JOIN producto p ON p.id_producto = d.id_producto "
        "WHERE d.id_compra = :id ORDER BY p.nombre",
        {"id": id_compra},
    )
    return render_template("compras/detalle.html", compra=compra, lineas=lineas)
