from flask import Blueprint, render_template

from .. import db
from ..auth.decorators import login_requerido

bp = Blueprint("main", __name__)


@bp.route("/")
@login_requerido
def panel():
    resumen = db.query(
        "SELECT NVL(SUM(total), 0) AS total, COUNT(*) AS num "
        "FROM venta WHERE estado = 'COMPLETADA' AND fecha >= TRUNC(SYSDATE)",
        one=True,
    )
    bajo_stock = db.query(f"{db.SQL_BAJO_STOCK} ORDER BY p.stock_actual")
    domicilios = db.query(
        "SELECT COUNT(*) AS num FROM domicilio WHERE estado IN ('PENDIENTE','EN_CAMINO')",
        one=True,
    )
    ventas_semana = db.query(
        "SELECT TO_CHAR(TRUNC(fecha), 'DD/MM') AS etiqueta, SUM(total) AS total "
        "FROM venta WHERE estado = 'COMPLETADA' AND fecha >= TRUNC(SYSDATE) - 6 "
        "GROUP BY TRUNC(fecha) ORDER BY TRUNC(fecha)"
    )
    # Los 6 productos más vendidos de los últimos 30 días (ROWNUM: compatible con 10g/11g)
    destacados = db.query(
        "SELECT * FROM (SELECT p.id_producto, p.nombre, p.imagen, p.precio_venta, p.stock_actual, "
        "c.nombre AS categoria, NVL(s.unidades, 0) AS unidades "
        "FROM producto p JOIN categoria c ON c.id_categoria = p.id_categoria "
        "LEFT JOIN (SELECT d.id_producto, SUM(d.cantidad) AS unidades FROM detalle_venta d "
        "JOIN venta v ON v.id_venta = d.id_venta "
        "WHERE v.estado = 'COMPLETADA' AND v.fecha >= TRUNC(SYSDATE) - 30 "
        "GROUP BY d.id_producto) s ON s.id_producto = p.id_producto "
        "WHERE p.activo = 'S' ORDER BY NVL(s.unidades, 0) DESC, p.nombre) WHERE ROWNUM <= 6"
    )
    totales = db.query(
        "SELECT COUNT(*) AS productos, NVL(SUM(stock_actual), 0) AS unidades, "
        "NVL(SUM(stock_actual * precio_venta), 0) AS valor "
        "FROM producto WHERE activo = 'S'",
        one=True,
    )
    return render_template(
        "main/panel.html", resumen=resumen, bajo_stock=bajo_stock,
        domicilios=domicilios, ventas_semana=ventas_semana,
        destacados=destacados, totales=totales,
    )
