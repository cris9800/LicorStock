"""Crea los administradores admin1 y admin2 (contraseña 1234) si no existen."""
from werkzeug.security import generate_password_hash

from app import create_app, db

app = create_app()
with app.app_context():
    for nombre in ("admin1", "admin2"):
        if db.query("SELECT 1 FROM usuario WHERE username = :u", {"u": nombre}, one=True):
            print(f"{nombre}: ya existia")
            continue
        db.execute(
            "INSERT INTO usuario (username, password_hash, rol) VALUES (:u, :h, 'ADMINISTRADOR')",
            {"u": nombre, "h": generate_password_hash("1234")},
        )
        print(f"{nombre}: creado")
    for u in db.query("SELECT username, rol, activo FROM usuario ORDER BY id_usuario"):
        print(u)
