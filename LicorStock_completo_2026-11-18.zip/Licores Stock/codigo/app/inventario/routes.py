from flask import Blueprint, render_template, request

from .. import db
from ..auth.decorators import login_requerido

bp = Blueprint("inventario", __name__)


@bp.route("/alertas")
@login_requerido
def alertas():
    productos = db.query(f"{db.SQL_BAJO_STOCK} ORDER BY p.stock_actual, p.nombre")
    return render_template("inventario/alertas.html", productos=productos)


@bp.route("/movimientos")
@login_requerido
def movimientos():
    id_producto = request.args.get("producto", type=int)
    filas = db.query(
        "SELECT * FROM (SELECT m.*, p.nombre AS producto, u.username AS usuario "
        "FROM movimiento_inventario m JOIN producto p ON p.id_producto = m.id_producto "
        "LEFT JOIN usuario u ON u.id_usuario = m.id_usuario "
        "WHERE (:p IS NULL OR m.id_producto = :p) "
        "ORDER BY m.fecha DESC, m.id_movimiento DESC) WHERE ROWNUM <= 200",
        {"p": id_producto},
    )
    productos = db.query("SELECT id_producto, nombre FROM producto ORDER BY nombre")
    return render_template("inventario/movimientos.html", movimientos=filas,
                           productos=productos, id_producto=id_producto)
