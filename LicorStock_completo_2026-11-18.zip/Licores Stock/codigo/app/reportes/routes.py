import csv
import io
from datetime import date, datetime, timedelta

from flask import Blueprint, Response, render_template, request

from .. import db
from ..auth.decorators import rol_requerido

bp = Blueprint("reportes", __name__)


def leer_rango(args):
    """Rango [desde, hasta] de los parámetros; por defecto los últimos 30 días."""
    def fecha(texto, defecto):
        try:
            return datetime.strptime(texto, "%Y-%m-%d").date()
        except (TypeError, ValueError):
            return defecto
    hasta = fecha(args.get("hasta"), date.today())
    desde = fecha(args.get("desde"), hasta - timedelta(days=29))
    if desde > hasta:
        desde, hasta = hasta, desde
    return desde, hasta


def _params(desde, hasta):
    return {"desde": datetime.combine(desde, datetime.min.time()),
            "hasta": datetime.combine(hasta + timedelta(days=1), datetime.min.time())}


VENTAS = "v.estado = 'COMPLETADA' AND v.fecha >= :desde AND v.fecha < :hasta"


@bp.route("/")
@rol_requerido()
def resumen():
    desde, hasta = leer_rango(request.args)
    p = _params(desde, hasta)
    totales = db.query(
        f"SELECT COUNT(*) AS num, NVL(SUM(v.total), 0) AS total, NVL(AVG(v.total), 0) AS promedio "
        f"FROM venta v WHERE {VENTAS}", p, one=True)
    compras = db.query(
        "SELECT COUNT(*) AS num, NVL(SUM(total), 0) AS total FROM compra "
        "WHERE fecha >= :desde AND fecha < :hasta", p, one=True)
    por_dia = db.query(
        f"SELECT TO_CHAR(TRUNC(v.fecha), 'DD/MM') AS etiqueta, SUM(v.total) AS total "
        f"FROM venta v WHERE {VENTAS} GROUP BY TRUNC(v.fecha) ORDER BY TRUNC(v.fecha)", p)
    top_productos = db.query(
        f"SELECT * FROM (SELECT pr.nombre, SUM(d.cantidad) AS unidades, "
        f"SUM(d.cantidad * d.precio_unitario) AS total FROM detalle_venta d "
        f"JOIN venta v ON v.id_venta = d.id_venta JOIN producto pr ON pr.id_producto = d.id_producto "
        f"WHERE {VENTAS} GROUP BY pr.nombre ORDER BY unidades DESC, total DESC) WHERE ROWNUM <= 10", p)
    por_categoria = db.query(
        f"SELECT c.nombre, SUM(d.cantidad * d.precio_unitario) AS total FROM detalle_venta d "
        f"JOIN venta v ON v.id_venta = d.id_venta JOIN producto pr ON pr.id_producto = d.id_producto "
        f"JOIN categoria c ON c.id_categoria = pr.id_categoria "
        f"WHERE {VENTAS} GROUP BY c.nombre ORDER BY total DESC", p)
    por_vendedor = db.query(
        f"SELECT u.username AS vendedor, COUNT(*) AS num, SUM(v.total) AS total FROM venta v "
        f"JOIN usuario u ON u.id_usuario = v.id_usuario WHERE {VENTAS} "
        f"GROUP BY u.username ORDER BY total DESC", p)
    domicilios = db.query(
        "SELECT estado, COUNT(*) AS num FROM domicilio "
        "WHERE fecha_pedido >= :desde AND fecha_pedido < :hasta GROUP BY estado", p)
    return render_template(
        "reportes/resumen.html", desde=desde, hasta=hasta, totales=totales, compras=compras,
        por_dia=por_dia, top_productos=top_productos, por_categoria=por_categoria,
        por_vendedor=por_vendedor, domicilios={d["estado"]: d["num"] for d in domicilios})


@bp.route("/ventas.csv")
@rol_requerido()
def ventas_csv():
    """Detalle de ventas del rango en CSV (se abre en Excel)."""
    desde, hasta = leer_rango(request.args)
    filas = db.query(
        f"SELECT v.id_venta, v.fecha, v.tipo_venta, u.username AS vendedor, "
        f"TRIM(c.nombre || ' ' || c.apellido) AS cliente, pr.nombre AS producto, "
        f"d.cantidad, d.precio_unitario, d.cantidad * d.precio_unitario AS subtotal "
        f"FROM venta v JOIN detalle_venta d ON d.id_venta = v.id_venta "
        f"JOIN producto pr ON pr.id_producto = d.id_producto "
        f"JOIN usuario u ON u.id_usuario = v.id_usuario "
        f"LEFT JOIN cliente c ON c.id_cliente = v.id_cliente "
        f"WHERE {VENTAS} ORDER BY v.fecha, v.id_venta", _params(desde, hasta))
    salida = io.StringIO()
    escritor = csv.writer(salida, delimiter=";")
    escritor.writerow(["Venta", "Fecha", "Tipo", "Vendedor", "Cliente", "Producto",
                       "Cantidad", "Precio unitario", "Subtotal"])
    for f in filas:
        escritor.writerow([f["id_venta"], f["fecha"].strftime("%d/%m/%Y %H:%M"), f["tipo_venta"],
                           f["vendedor"], f["cliente"] or "Mostrador", f["producto"],
                           f["cantidad"], f["precio_unitario"], f["subtotal"]])
    nombre = f"ventas_{desde.isoformat()}_{hasta.isoformat()}.csv"
    # BOM para que Excel reconozca las tildes
    return Response("﻿" + salida.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename={nombre}"})
