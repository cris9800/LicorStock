-- =====================================================================
-- LicorStock - Agrega 40 bebidas sin alcohol (con foto)
-- Esquema: LICOLERIA (Oracle 10g XE). En SQL Developer: F5.
-- Las fotos van en codigo\app\static\img\productos\ (archivos sa-*.jpg).
-- Solo INSERTA en la categoria "Bebidas sin alcohol". No borra nada.
-- Si un producto con el mismo nombre ya existe, solo le pone la foto y lo activa.
-- =====================================================================
SET SERVEROUTPUT ON
SET DEFINE OFF

DECLARE
  v_ins NUMBER := 0; v_act NUMBER := 0; v_cat NUMBER; v_prov NUMBER;

  PROCEDURE a(p_nombre VARCHAR2, p_precio NUMBER, p_imagen VARCHAR2) IS
    v_id NUMBER; v_n NUMBER; v_stock NUMBER;
  BEGIN
    SELECT MIN(id_producto) INTO v_id FROM producto WHERE UPPER(nombre) = UPPER(p_nombre);
    IF v_id IS NOT NULL THEN
      UPDATE producto SET imagen = p_imagen, activo = 'S' WHERE id_producto = v_id;
      v_act := v_act + 1; RETURN;
    END IF;
    v_stock := CASE WHEN p_precio >= 20000 THEN 24 WHEN p_precio >= 7000 THEN 48 ELSE 96 END;
    LOOP
      SELECT seq_producto.NEXTVAL INTO v_id FROM dual;
      SELECT COUNT(*) INTO v_n FROM producto WHERE id_producto = v_id;
      EXIT WHEN v_n = 0;
    END LOOP;
    INSERT INTO producto (id_producto, id_categoria, id_proveedor, nombre, descripcion, es_alcoholico,
                          grado_alcohol, precio_venta, stock_actual, stock_minimo, imagen, activo)
    VALUES (v_id, v_cat, v_prov, p_nombre, 'Bebida sin alcohol para tomar sola o mezclar.', 'N',
            0, p_precio, v_stock, TRUNC(v_stock/5), p_imagen, 'S');
    v_ins := v_ins + 1;
  END;

BEGIN
  SELECT MIN(id_categoria) INTO v_cat FROM categoria WHERE UPPER(nombre) = 'BEBIDAS SIN ALCOHOL';
  IF v_cat IS NULL THEN
    SELECT seq_categoria.NEXTVAL INTO v_cat FROM dual;
    INSERT INTO categoria (id_categoria, nombre, descripcion)
    VALUES (v_cat, 'Bebidas sin alcohol', 'Gaseosas, aguas, tonicas, energizantes y jugos.');
  END IF;
  SELECT MIN(id_proveedor) INTO v_prov FROM proveedor WHERE nit = '860999000';

  a('MIL976 Mezclador Manzana Sparkling 4 Pack', 21900, 'sa-mil976-mezclador-manzana-sparkling-4-pack.jpg');
  a('Agua Tónica Mil 976 Ocean x4', 22990, 'sa-agua-tonica-mil-976-ocean-x4.jpg');
  a('Agua Tónica San Pellegrino x 330ml', 9900, 'sa-agua-tonica-san-pellegrino-x-330ml.jpg');
  a('Bubura Rose Limonade 260ml', 9900, 'sa-bubura-rose-limonade-260ml.jpg');
  a('Electrolit x 625ml', 8000, 'sa-electrolit-x-625ml.jpg');
  a('Evian Carbonatada x 330ml', 9900, 'sa-evian-carbonatada-x-330ml.jpg');
  a('Ginger Beer San Pellegrino x 200ml', 12400, 'sa-ginger-beer-san-pellegrino-x-200ml.jpg');
  a('Juniper Dry Tonic Water x 200ml', 7300, 'sa-juniper-dry-tonic-water-x-200ml.jpg');
  a('Kling Mixer Toronja x 207ml Fourpack', 25900, 'sa-kling-mixer-toronja-x-207ml-fourpack.jpg');
  a('Mil976 Gin Tonic 0.0 207ml 4pack', 24900, 'sa-mil976-gin-tonic-0-0-207ml-4pack.jpg');
  a('MIL976 Mezclador Ginger Beer Spicy 4Pack 207ml', 21900, 'sa-mil976-mezclador-ginger-beer-spicy-4pack-207ml.jpg');
  a('MIL976 Mezclador Toronja Sparkling 4Pack', 25000, 'sa-mil976-mezclador-toronja-sparkling-4pack.jpg');
  a('MIL976 Tamarindo Sparkling 4Pack', 25900, 'sa-mil976-tamarindo-sparkling-4pack.jpg');
  a('San Pellegrino Zero Blood Orange x 330ml Sugar Free', 9500, 'sa-san-pellegrino-zero-blood-orange-x-330ml-sugar-free.jpg');
  a('San Pellegrino Zero Lemonade x 330ml Sugar Free', 9500, 'sa-san-pellegrino-zero-lemonade-x-330ml-sugar-free.jpg');
  a('San Pellegrino Zero Pomegranate and Orange x 330ml', 9500, 'sa-san-pellegrino-zero-pomegranate-and-orange-x-330ml.jpg');
  a('Ginger Canada Dry Tónica x 300ml', 2250, 'sa-ginger-canada-dry-tonica-x-300ml.jpg');
  a('Agua Perrier x 330ml', 8900, 'sa-agua-perrier-x-330ml.jpg');
  a('Fever Tree Indian Fourpack x 200ml', 34990, 'sa-fever-tree-indian-fourpack-x-200ml.jpg');
  a('Tonic Water Kling Ginger Fourpack x 207ml', 20990, 'sa-tonic-water-kling-ginger-fourpack-x-207ml.jpg');
  a('San Pellegrino Agua Manantial Gasificada x 750ml', 13390, 'sa-san-pellegrino-agua-manantial-gasificada-x-750ml.jpg');
  a('Canada Dry Tónica x 300ml', 2990, 'sa-canada-dry-tonica-x-300ml.jpg');
  a('San Pellegrino Aranciata x 330ml', 9990, 'sa-san-pellegrino-aranciata-x-330ml.jpg');
  a('Kling Tonic Mixer Original Fourpack x 207ml', 22500, 'sa-kling-tonic-mixer-original-fourpack-x-207ml.jpg');
  a('Agua Cristal con Gas x 600ml', 2500, 'sa-agua-cristal-con-gas-x-600ml.jpg');
  a('Agua Cristal x 600ml', 2000, 'sa-agua-cristal-x-600ml.jpg');
  a('Red Bull x 250ml', 7900, 'sa-red-bull-x-250ml.jpg');
  a('Red Bull Libre de Azúcar x 250ml', 7900, 'sa-red-bull-libre-de-azucar-x-250ml.jpg');
  a('Canada Dry Ginger Ale x 300ml', 3200, 'sa-canada-dry-ginger-ale-x-300ml.jpg');
  a('Canada Dry x 1500ml', 7000, 'sa-canada-dry-x-1500ml.jpg');
  a('Hatsu Soda Frambuesa x 300ml', 3500, 'sa-hatsu-soda-frambuesa-x-300ml.jpg');
  a('Hatsu Soda Uva Blanca Romero x 300ml', 3500, 'sa-hatsu-soda-uva-blanca-romero-x-300ml.jpg');
  a('Gatorade x 500ml', 4600, 'sa-gatorade-x-500ml.jpg');
  a('Jugo de Naranja Hit 100% x 1 Litro', 8000, 'sa-jugo-de-naranja-hit-100-x-1-litro.jpg');
  a('Coca-Cola x 1500ml', 6800, 'sa-coca-cola-x-1500ml.jpg');
  a('Juniper Toronja x 200ml', 7990, 'sa-juniper-toronja-x-200ml.jpg');
  a('Red Bull Sandía x 250ml', 8500, 'sa-red-bull-sandia-x-250ml.jpg');
  a('Coca-Cola Mini x 269ml', 3990, 'sa-coca-cola-mini-x-269ml.jpg');
  a('San Pellegrino Melograno e Arancia x 330ml', 9500, 'sa-san-pellegrino-melograno-e-arancia-x-330ml.jpg');
  a('Schweppes Ginger Ale x 300ml', 2990, 'sa-schweppes-ginger-ale-x-300ml.jpg');

  COMMIT;
  DBMS_OUTPUT.PUT_LINE('Bebidas insertadas: ' || v_ins || ' | ya existian (foto actualizada): ' || v_act);
END;
/

SELECT c.nombre AS categoria, COUNT(p.id_producto) AS activos
  FROM categoria c LEFT JOIN producto p ON p.id_categoria = c.id_categoria AND p.activo = 'S'
 GROUP BY c.nombre ORDER BY c.nombre;
