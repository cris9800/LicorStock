-- =====================================================================
-- LicorStock - Agrega 29 productos a "Otros licores"
-- (siropes, bitters, bases de coctel, kits y complementos, con foto)
-- Esquema: LICOLERIA (Oracle 10g XE). En SQL Developer: F5.
-- Las fotos van en codigo\app\static\img\productos\ (archivos ol-*.jpg,
-- copia en fotos_otros_licores.zip).
-- Usa la categoria "Otros licores" y la deja activa (visible).
-- Precio = precio actual de la captura (si tenia descuento, el precio rebajado).
-- Solo INSERTA. No borra nada. Se puede correr varias veces:
-- si un producto con el mismo nombre ya existe, solo le pone la foto y lo activa.
-- =====================================================================
SET SERVEROUTPUT ON
SET DEFINE OFF

DECLARE
  v_ins NUMBER := 0; v_act NUMBER := 0; v_cat NUMBER; v_prov NUMBER;

  PROCEDURE a(p_nombre VARCHAR2, p_precio NUMBER, p_alc CHAR, p_grado NUMBER,
              p_desc VARCHAR2, p_imagen VARCHAR2) IS
    v_id NUMBER; v_n NUMBER; v_stock NUMBER;
  BEGIN
    SELECT MIN(id_producto) INTO v_id FROM producto WHERE UPPER(nombre) = UPPER(p_nombre);
    IF v_id IS NOT NULL THEN
      UPDATE producto SET imagen = p_imagen, activo = 'S' WHERE id_producto = v_id;
      v_act := v_act + 1; RETURN;
    END IF;
    v_stock := CASE WHEN p_precio >= 100000 THEN 6
                    WHEN p_precio >= 40000  THEN 18
                    WHEN p_precio >= 15000  THEN 30
                    ELSE 48 END;
    LOOP
      SELECT seq_producto.NEXTVAL INTO v_id FROM dual;
      SELECT COUNT(*) INTO v_n FROM producto WHERE id_producto = v_id;
      EXIT WHEN v_n = 0;
    END LOOP;
    INSERT INTO producto (id_producto, id_categoria, id_proveedor, nombre, descripcion, es_alcoholico,
                          grado_alcohol, precio_venta, stock_actual, stock_minimo, imagen, activo)
    VALUES (v_id, v_cat, v_prov, p_nombre, p_desc, p_alc,
            p_grado, p_precio, v_stock, GREATEST(1, TRUNC(v_stock/5)), p_imagen, 'S');
    v_ins := v_ins + 1;
  END;

BEGIN
  SELECT MIN(id_categoria) INTO v_cat FROM categoria WHERE UPPER(nombre) = 'OTROS LICORES';
  IF v_cat IS NULL THEN
    SELECT seq_categoria.NEXTVAL INTO v_cat FROM dual;
    INSERT INTO categoria (id_categoria, nombre, descripcion)
    VALUES (v_cat, 'Otros licores', 'Siropes, bitters, bases de coctel y complementos.');
  END IF;
  UPDATE categoria SET activo = 'S' WHERE id_categoria = v_cat AND NVL(activo, 'N') <> 'S';
  SELECT MIN(id_proveedor) INTO v_prov FROM proveedor WHERE nit = '860999000';

  -- Captura 1
  a('Mermelada x 40g Sabores Surtidos', 9990, 'N', 0, 'Mermelada artesanal para acompañar.', 'ol-mermelada-x-40g-sabores-surtidos.jpg');
  a('Kanaloa Toronja x 1000ml', 45900, 'N', 0, 'Sirope para coctelería.', 'ol-kanaloa-toronja-x-1000ml.jpg');
  a('Kanaloa Jengibre x 1000ml', 47900, 'N', 0, 'Sirope para coctelería.', 'ol-kanaloa-jengibre-x-1000ml.jpg');
  a('Angostura Cocoa (Esencias de gotas amargas) x 100ml', 58900, 'S', 48, 'Bitters para coctelería. Venta prohibida a menores de edad.', 'ol-angostura-cocoa-bitters-x-100ml.jpg');   -- antes 89.900
  a('Angostura Naranja (Esencias de gotas amargas) x 100ml', 59900, 'S', 28, 'Bitters para coctelería. Venta prohibida a menores de edad.', 'ol-angostura-naranja-bitters-x-100ml.jpg'); -- antes 89.900
  a('Ezy Masticable Vegano para la fiesta', 4990, 'N', 0, 'Masticable vegano para la fiesta.', 'ol-ezy-masticable-vegano.jpg');
  a('Kanaloa Araza x 1000ml', 56600, 'N', 0, 'Sirope para coctelería.', 'ol-kanaloa-araza-x-1000ml.jpg');
  a('Kanaloa Corozo x 1000ml', 54900, 'N', 0, 'Sirope para coctelería.', 'ol-kanaloa-corozo-x-1000ml.jpg');
  a('Kanaloa Crema Irlandesa x 1000ml', 45900, 'N', 0, 'Sirope para coctelería.', 'ol-kanaloa-crema-irlandesa-x-1000ml.jpg');
  a('Kanaloa Frutos Amarillos x 1000ml', 42900, 'N', 0, 'Sirope para coctelería.', 'ol-kanaloa-frutos-amarillos-x-1000ml.jpg');
  -- Captura 2
  a('Kanaloa Frutos Rojos x 1000ml', 40900, 'N', 0, 'Sirope para coctelería.', 'ol-kanaloa-frutos-rojos-x-1000ml.jpg');
  a('Kanaloa Lulo x 1000ml', 38600, 'N', 0, 'Sirope para coctelería.', 'ol-kanaloa-lulo-x-1000ml.jpg');
  a('Kanaloa Rosas x 1000ml', 48900, 'N', 0, 'Sirope para coctelería.', 'ol-kanaloa-rosas-x-1000ml.jpg');
  a('Kit Angostura x 3unds', 174900, 'S', 44.7, 'Kit de bitters para coctelería. Venta prohibida a menores de edad.', 'ol-kit-angostura-x-3.jpg'); -- antes 269.700
  a('Kit de Mermeladas Artesanales de Colombia x 3unds', 29990, 'N', 0, 'Mermeladas artesanales para acompañar.', 'ol-kit-mermeladas-artesanales-x-3.jpg');
  a('Monin Avellana x 750ml', 62990, 'N', 0, 'Sirope para coctelería.', 'ol-monin-avellana-x-750ml.jpg');
  a('Monin Blueberry x 750ml', 61900, 'N', 0, 'Sirope para coctelería.', 'ol-monin-blueberry-x-750ml.jpg');
  a('Monin Durazno x 750ml', 63990, 'N', 0, 'Sirope para coctelería.', 'ol-monin-durazno-x-750ml.jpg');
  a('Monin Flor de Jamaica x 1 Litro', 89900, 'N', 0, 'Sirope para coctelería.', 'ol-monin-flor-de-jamaica-x-1000ml.jpg');
  a('Monin Flor de Sauco x 750ml', 62990, 'N', 0, 'Sirope para coctelería.', 'ol-monin-flor-de-sauco-x-750ml.jpg');
  -- Captura 3
  a('Base Cóctel Daiquiri Fresa x 1000ml', 34900, 'N', 0, 'Base para preparar cócteles.', 'ol-base-coctel-daiquiri-fresa-x-1000ml.jpg');
  a('Base Cóctel Margarita x 1000ml', 37900, 'N', 0, 'Base para preparar cócteles.', 'ol-base-coctel-margarita-x-1000ml.jpg');
  a('Monin Syrup Vainilla x 750ml', 61800, 'N', 0, 'Sirope para coctelería.', 'ol-monin-vainilla-x-750ml.jpg');
  a('Crema de Coco Real x 500ml', 49900, 'N', 0, 'Crema para coctelería.', 'ol-crema-de-coco-real-x-500ml.jpg');
  a('Crema de Raspberry Real x 500ml', 50900, 'N', 0, 'Puré de frambuesa para coctelería.', 'ol-crema-de-raspberry-real-x-500ml.jpg');
  -- Captura 4
  a('Caja Premium', 64900, 'N', 0, 'Caja de regalo premium.', 'ol-caja-premium.jpg');
  a('Granadina x 1000ml', 23400, 'N', 0, 'Sirope de granadina para coctelería.', 'ol-granadina-x-1000ml.jpg');
  a('Kit Botánicos by Hendricks', 9990, 'N', 0, 'Botánicos para preparar gin tonic.', 'ol-kit-botanicos-hendricks.jpg');
  a('Alcohol Max OH x 500ml', 6500, 'N', 0, 'Alcohol antibacterial (no apto para consumo).', 'ol-alcohol-max-oh-x-500ml.jpg');

  COMMIT;
  DBMS_OUTPUT.PUT_LINE('Otros licores insertados: ' || v_ins || ' | ya existian (foto actualizada): ' || v_act);
END;
/

SELECT c.nombre AS categoria, c.activo, COUNT(p.id_producto) AS productos_activos
  FROM categoria c LEFT JOIN producto p ON p.id_categoria = c.id_categoria AND p.activo = 'S'
 GROUP BY c.nombre, c.activo ORDER BY c.nombre;
