# Licores Stock

Todo lo de LicorStock (sistema web de la licorera: Flask + Oracle) en un solo lugar.
Se actualiza cada vez que se agrega o cambia algo.

## Conectar con Oracle

Sigue **`codigo/GUIA_CONEXION_ORACLE.md`** y prueba con doble clic en **`codigo/PROBAR_CONEXION.cmd`**.

## Para ver cómo se ve

Abre **`ver-pantallas.html`** con doble clic: muestra todas las pantallas del sistema funcionando.
Las imágenes sueltas están en `capturas/`.

## Qué hay en cada carpeta

| Carpeta | Contenido |
|---|---|
| `codigo/` | La aplicación Flask completa (abrir esta carpeta en VS Code). Su `README.md` explica instalación y estructura. |
| `base-de-datos/` | Script de Oracle `LicorStock_Oracle_revisado.sql` (12 tablas, secuencias, triggers, vistas, datos). Es el mismo que está en `codigo/database/`. |
| `capturas/` | Imágenes de cada pantalla. |
| `entregas/` | `LicorStock.zip`, el proyecto empaquetado para entregar o compartir. |
| `ver-pantallas.html` | Galería con todas las pantallas. |

## Cómo arrancar la app en tu PC

1. En SQL Developer, conexión **Licores** (esquema **LICORES**): ejecuta `base-de-datos/LicorStock_Oracle_revisado.sql` con F5 (solo la primera vez).
2. En una terminal dentro de `codigo/`:
   ```
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   copy .env.example .env
   ```
3. Abre `.env` y pon `ORACLE_USER=LICORES`, tu contraseña y el DSN (en 10g/11g XE: `localhost:1521/XE`).
   El archivo `.env` no se incluye a propósito porque lleva credenciales.
4. Arranca con `flask --app run run --debug` y abre http://127.0.0.1:5000

## Estado (28/10/2026)

Todos los módulos de la propuesta están listos: base de datos, login y roles (ADMINISTRADOR, VENDEDOR,
REPARTIDOR), panel con gráfico, productos y categorías, ventas con pago y domicilio, anulación de ventas,
alertas de bajo stock y movimientos, clientes, proveedores, compras, domicilios para el repartidor,
caja diaria, reportes con descarga a Excel y gestión de usuarios.

No hace falta volver a correr el script SQL: la base de datos no cambió.

## Quién ve qué

| Rol | Pantallas |
|---|---|
| ADMINISTRADOR | Todo |
| VENDEDOR | Panel, ventas, clientes, domicilios, caja, consulta de inventario |
| REPARTIDOR | Panel, sus domicilios, consulta de inventario |

## Historial

- 28/10/2026: primera copia (fase 1).
- 28/10/2026: fase 2, pantallas de clientes, proveedores y compras.
- 28/10/2026: todo pasa a la carpeta "Licores Stock" y se agregan las capturas de pantalla.
- 28/10/2026: fase 3, domicilios para el repartidor, anular ventas, caja, reportes y usuarios.
- 29/10/2026: interfaz nueva (menú lateral, colores vino y ámbar, catálogo y punto de venta con fotos de productos),
  subida de fotos, guía de conexión con Oracle, `probar_conexion.py` y `datos_demo.sql`. La base de datos no cambió.
