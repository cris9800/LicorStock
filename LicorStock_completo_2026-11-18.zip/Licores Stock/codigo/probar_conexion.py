"""Prueba la conexión entre la app y Oracle, paso a paso, con mensajes en español.

Uso (dentro de la carpeta codigo, con el venv activado):
    python probar_conexion.py
o doble clic en PROBAR_CONEXION.cmd
"""
import re
import sys

from config import Config

TABLAS = ["USUARIO", "CATEGORIA", "PROVEEDOR", "PRODUCTO", "CLIENTE", "VENTA", "DETALLE_VENTA",
          "PAGO", "DOMICILIO", "COMPRA", "DETALLE_COMPRA", "MOVIMIENTO_INVENTARIO"]

# Errores frecuentes -> qué significan y cómo arreglarlos
AYUDAS = [
    (r"ORA-12541|DPY-6005|TNS:no listener|Connection refused|ConnectException",
     "Oracle no está escuchando en esa dirección/puerto.",
     "Revisa que el servicio de Oracle esté encendido (services.msc -> OracleServiceXE y "
     "OracleXETNSListener en 'Iniciado') y que el puerto de ORACLE_DSN sea 1521."),
    (r"ORA-12514|ORA-12505|DPY-6001|DPY-6003|service name|SID",
     "El nombre del servicio del DSN no existe.",
     "En 10g/11g XE usa ORACLE_DSN=localhost:1521/XE. En 21c: localhost:1521/XEPDB1. "
     "En 23ai Free: localhost:1521/FREEPDB1. Debe ser el mismo de tu conexión en SQL Developer."),
    (r"ORA-01017",
     "Usuario o contraseña incorrectos.",
     "Revisa ORACLE_USER y ORACLE_PASSWORD en .env (en 11g+ la contraseña distingue mayúsculas)."),
    (r"ORA-28000",
     "La cuenta está bloqueada.",
     "Como SYSTEM ejecuta: ALTER USER <tu_usuario> ACCOUNT UNLOCK;"),
    (r"ORA-28001",
     "La contraseña expiró.",
     "Como SYSTEM ejecuta: ALTER USER <tu_usuario> IDENTIFIED BY <nueva_clave>;"),
    (r"ORA-28040",
     "El controlador es muy nuevo para tu versión de Oracle.",
     "Con Oracle 10g usa un ojdbc más antiguo en ORACLE_JDBC_JAR: ojdbc6.jar versión 11.2.0.4 "
     "(Maven Central) o el ojdbc14.jar que trae Oracle 10g en "
     "C:\\oraclexe\\app\\oracle\\product\\10.2.0\\server\\jdbc\\lib."),
    (r"DPY-3010|DPY-3015|not supported by python-oracledb in thin mode",
     "python-oracledb en modo Thin solo funciona con Oracle 12c o superior.",
     "Tu Oracle es 10g u 11g: usa la conexión por JDBC (ORACLE_JDBC_JAR y JAVA_JVM_DLL en .env) "
     "o Instant Client (ORACLE_CLIENT_LIB). Mira GUIA_CONEXION_ORACLE.md, paso 4."),
    (r"DPI-1047",
     "No se encontró Oracle Instant Client.",
     "Revisa la ruta de ORACLE_CLIENT_LIB en .env (debe ser la carpeta que tiene oci.dll)."),
    (r"JVMNotFound|jvm\.dll|No JVM shared library|libjvm",
     "No se encontró Java.",
     "Instala un JDK (17 o superior) y pon en JAVA_JVM_DLL la ruta de jvm.dll, por ejemplo "
     "C:\\Program Files\\Java\\jdk-24\\bin\\server\\jvm.dll"),
    (r"oracle\.jdbc\.OracleDriver|ClassNotFound|NoClassDefFound",
     "No se encontró el controlador JDBC de Oracle.",
     "Revisa ORACLE_JDBC_JAR: debe apuntar a un archivo ojdbc*.jar que exista "
     "(SQL Developer lo trae en sqldeveloper\\jdbc\\lib)."),
    (r"No module named 'jpype'",
     "Falta la librería JPype (necesaria para la conexión por JDBC).",
     "Con el venv activado ejecuta: pip install -r requirements.txt"),
    (r"No module named 'oracledb'",
     "Falta la librería oracledb.",
     "Con el venv activado ejecuta: pip install -r requirements.txt"),
]


def explicar(error):
    texto = str(error)
    for patron, que, como in AYUDAS:
        if re.search(patron, texto, re.I):
            return f"   ¿Qué pasa?  {que}\n   Solución:    {como}"
    return "   Error no reconocido. Copia el mensaje de arriba y búscalo, o revisa GUIA_CONEXION_ORACLE.md."


def ok(msg):
    print(f"  [OK]  {msg}")


def fallo(msg, exc=None):
    print(f"  [X]   {msg}")
    if exc is not None:
        print(f"         {type(exc).__name__}: {str(exc).splitlines()[0][:300]}")
        print(explicar(exc))
    print()
    input("Presiona Enter para cerrar...") if sys.stdin.isatty() else None
    sys.exit(1)


def main():
    print()
    print("=" * 66)
    print("  LicorStock · Prueba de conexión con Oracle")
    print("=" * 66)

    # 1. Configuración
    modo = ("JDBC (Oracle 10g)" if Config.ORACLE_JDBC_JAR else
            "Thick con Instant Client (10g/11g)" if Config.ORACLE_CLIENT_LIB else
            "Thin (Oracle 12c o superior)")
    print(f"\n1) Datos del archivo .env")
    print(f"     Usuario : {Config.ORACLE_USER}")
    print(f"     Clave   : {'*' * len(Config.ORACLE_PASSWORD) if Config.ORACLE_PASSWORD else '(vacía)'}")
    print(f"     DSN     : {Config.ORACLE_DSN}")
    print(f"     Modo    : {modo}")
    if not Config.ORACLE_PASSWORD:
        fallo("ORACLE_PASSWORD está vacío. ¿Copiaste .env.example como .env y lo llenaste?")
    if Config.ORACLE_JDBC_JAR:
        from pathlib import Path
        if not Path(Config.ORACLE_JDBC_JAR).is_file():
            fallo(f"No existe el archivo ORACLE_JDBC_JAR: {Config.ORACLE_JDBC_JAR}")
        if Config.JAVA_JVM_DLL and not Path(Config.JAVA_JVM_DLL).is_file():
            fallo(f"No existe el archivo JAVA_JVM_DLL: {Config.JAVA_JVM_DLL}")
    ok("Configuración leída")

    # 2. Conexión
    print("\n2) Conectando con Oracle...")
    try:
        from app import create_app, db
        app = create_app()
        with app.app_context():
            db.query("SELECT 1 AS uno FROM dual")
    except Exception as exc:  # noqa: BLE001
        fallo("No se pudo conectar.", exc)
    ok("Conexión abierta")

    with app.app_context():
        # 3. Versión y usuario
        print("\n3) Servidor")
        try:
            fila = db.query("SELECT USER AS usuario, SYSDATE AS ahora FROM dual", one=True)
            ok(f"Conectado como {fila['usuario']} · hora del servidor {fila['ahora']:%d/%m/%Y %H:%M}")
            ver = db.query("SELECT product, version FROM product_component_version "
                           "WHERE UPPER(product) LIKE 'ORACLE%'", one=True)
            if ver:
                ok(f"{ver['product'].strip()} {ver['version']}")
        except Exception as exc:  # noqa: BLE001
            fallo("La conexión abrió pero no responde a consultas.", exc)

        # 4. Tablas
        print("\n4) Tablas de LicorStock en este usuario")
        hay = {r["table_name"] for r in db.query("SELECT table_name FROM user_tables")}
        faltan = [t for t in TABLAS if t not in hay]
        if faltan:
            print(f"  [X]   Faltan {len(faltan)} tabla(s): {', '.join(faltan)}")
            print("        Ejecuta database/LicorStock_Oracle_revisado.sql con F5 en SQL Developer,")
            print(f"        conectado como {Config.ORACLE_USER} (el mismo usuario del .env).")
            fallo("La base de datos no tiene las tablas.")
        for t in TABLAS:
            n = db.query(f"SELECT COUNT(*) AS n FROM {t}", one=True)["n"]
            print(f"        {t.lower():<24}{n:>6} fila(s)")
        ok("Las 12 tablas existen")

        # 5. Triggers de la versión revisada
        print("\n5) Reglas del negocio (triggers)")
        trg = {r["trigger_name"]: r["status"] for r in db.query("SELECT trigger_name, status FROM user_triggers")}
        necesarios = ["TRG_DETALLE_VENTA_AI", "TRG_DETALLE_COMPRA_AI", "TRG_VENTA_ANULADA_AU", "TRG_DOMICILIO_BU"]
        malos = [t for t in necesarios if trg.get(t) != "ENABLED"]
        if malos:
            print(f"  [!]   Faltan o están desactivados: {', '.join(malos)}")
            print("        Parece que ejecutaste el script viejo. Ejecuta LicorStock_Oracle_revisado.sql")
            print("        (OJO: borra y recrea las tablas, perderás los datos que hayas agregado).")
        else:
            ok("Triggers de la versión revisada activos")

        metodos = db.query("SELECT search_condition FROM user_constraints "
                           "WHERE constraint_name = 'CK_PAGO_METODO'", one=True)
        if metodos and "NEQUI" not in str(metodos["search_condition"]):
            print("  [!]   La tabla PAGO no acepta NEQUI ni DAVIPLATA (script viejo). "
                  "Ejecuta LicorStock_Oracle_revisado.sql.")

        sin_foto = db.query("SELECT COUNT(*) AS n FROM producto WHERE imagen IS NULL", one=True)["n"]
        if sin_foto:
            print(f"  [i]   {sin_foto} producto(s) sin foto: se muestra la imagen de su categoría. "
                  "Súbela en Productos > Editar.")

    print("\n" + "=" * 66)
    print("  TODO LISTO. Arranca la app con INICIAR.cmd y abre http://127.0.0.1:5000")
    print("=" * 66 + "\n")
    if sys.stdin.isatty():
        input("Presiona Enter para cerrar...")


if __name__ == "__main__":
    main()
