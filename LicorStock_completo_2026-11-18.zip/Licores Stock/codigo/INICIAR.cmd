@echo off
cd /d "%~dp0"
echo Iniciando LicorStock... cuando aparezca "Running on http://127.0.0.1:5000" abre esa direccion en el navegador.
echo Para apagarla cierra esta ventana.
start "" http://127.0.0.1:5000
venv\Scripts\flask --app run run --debug
pause
