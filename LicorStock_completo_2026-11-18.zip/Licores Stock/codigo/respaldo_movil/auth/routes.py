from flask import (Blueprint, flash, redirect, render_template, request, session,
                   url_for)
from werkzeug.security import check_password_hash

from .. import db

bp = Blueprint("auth", __name__)

# Pestañas de rol que se muestran en el login
ROLES_LOGIN = ("ADMINISTRADOR", "VENDEDOR")


@bp.route("/login", methods=["GET", "POST"])
def login():
    rol_elegido = "ADMINISTRADOR"
    if request.method == "POST":
        usuario = request.form.get("usuario", "").strip()
        password = request.form.get("password", "")
        rol_elegido = request.form.get("rol", "ADMINISTRADOR")
        if rol_elegido not in ROLES_LOGIN:
            rol_elegido = "ADMINISTRADOR"
        fila = db.query(
            "SELECT id_usuario, username, password_hash, rol FROM usuario "
            "WHERE username = :usuario AND activo = 'S'",
            {"usuario": usuario}, one=True,
        )
        if fila and check_password_hash(fila["password_hash"], password):
            # La pestaña elegida debe coincidir con el rol guardado en la base de datos.
            # (El REPARTIDOR no tiene pestaña propia: puede entrar desde cualquiera.)
            if fila["rol"] in ROLES_LOGIN and fila["rol"] != rol_elegido:
                flash(f"Este usuario no es {rol_elegido.capitalize()}. "
                      f"Elige la pestaña {fila['rol'].capitalize()}.", "danger")
                return render_template("auth/login.html", rol_elegido=rol_elegido)
            session.clear()
            session["id_usuario"] = fila["id_usuario"]
            session["nombre"] = fila["username"]
            session["rol"] = fila["rol"]
            return redirect(url_for("main.panel"))
        flash("Usuario o contraseña incorrectos.", "danger")
    return render_template("auth/login.html", rol_elegido=rol_elegido)


@bp.route("/cliente/entrar", methods=["POST"])
def entrar_cliente():
    """Acceso de clientes al catálogo: solo confirma que es mayor de edad."""
    if request.form.get("mayor_edad") != "S":
        flash("Debes ser mayor de edad para ver el catálogo.", "danger")
        return redirect(url_for("auth.login"))
    session.clear()
    session["cliente"] = True
    return redirect(url_for("tienda.catalogo"))


@bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("auth.login"))
