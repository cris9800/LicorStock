-- =====================================================================
-- LicorStock - REEMPLAZA el catalogo por los 90 productos de las capturas
-- Esquema: LICOLERIA (Oracle 10g XE). En SQL Developer: F5.
-- 1) Inserta 90 productos (whisky 30, aguardientes 20, vinos 20, cervezas 20).
--    Si un nombre ya existe, lo deja (y lo reactiva).
-- 2) Los productos que NO estan en la lista: si nunca se usaron en
--    ventas/compras/movimientos se BORRAN; si tienen historial se
--    DESACTIVAN (activo='N') para no romper ventas ya registradas.
-- No toca categorias, clientes, ventas ni otras tablas.
-- =====================================================================
SET SERVEROUTPUT ON
SET DEFINE OFF

DECLARE
  TYPE t_ids IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;
  v_keep t_ids;
  v_ins NUMBER := 0; v_salt NUMBER := 0; v_borr NUMBER := 0; v_desac NUMBER := 0; v_uso NUMBER;

  PROCEDURE a(p_tipo VARCHAR2, p_nombre VARCHAR2, p_precio NUMBER, p_grado NUMBER) IS
    v_catn VARCHAR2(50); v_desc VARCHAR2(100); v_cat NUMBER; v_prov NUMBER;
    v_id NUMBER; v_n NUMBER; v_stock NUMBER;
  BEGIN
    v_catn := CASE p_tipo WHEN 'W' THEN 'Whisky' WHEN 'A' THEN 'Aguardientes' WHEN 'V' THEN 'Vinos' ELSE 'Cervezas' END;
    v_desc := CASE p_tipo WHEN 'W' THEN 'Whisky' WHEN 'A' THEN 'Aguardiente' WHEN 'V' THEN 'Vino' ELSE 'Cerveza' END
              || ' - venta regulada a mayores de 18.';
    v_stock := CASE WHEN p_precio >= 1000000 THEN 3 WHEN p_precio >= 300000 THEN 6
                    WHEN p_precio >= 100000 THEN 12 WHEN p_precio >= 40000 THEN 30 ELSE 60 END;
    SELECT MIN(id_producto) INTO v_id FROM producto WHERE UPPER(nombre) = UPPER(p_nombre);
    IF v_id IS NOT NULL THEN
      UPDATE producto SET activo = 'S' WHERE id_producto = v_id;
      v_keep(v_id) := 1; v_salt := v_salt + 1; RETURN;
    END IF;
    SELECT MIN(id_categoria) INTO v_cat FROM categoria WHERE UPPER(nombre) = UPPER(v_catn);
    SELECT MIN(id_proveedor) INTO v_prov FROM proveedor WHERE nit = '890200300';
    LOOP
      SELECT seq_producto.NEXTVAL INTO v_id FROM dual;
      SELECT COUNT(*) INTO v_n FROM producto WHERE id_producto = v_id;
      EXIT WHEN v_n = 0;
    END LOOP;
    INSERT INTO producto (id_producto, id_categoria, id_proveedor, nombre, descripcion, es_alcoholico,
                          grado_alcohol, precio_venta, stock_actual, stock_minimo, activo)
    VALUES (v_id, v_cat, v_prov, p_nombre, v_desc, 'S', p_grado, p_precio, v_stock, GREATEST(1, TRUNC(v_stock/5)), 'S');
    v_keep(v_id) := 1; v_ins := v_ins + 1;
  END;

BEGIN
  a('W', 'Buchanan''s Master x 750ml', 199990, 40);
  a('W', 'The Glenlivet Founders Reserve x 700ml', 169990, 40);
  a('W', 'Macallan 12 Años Sherry Oak Cask 700ml', 429990, 40);
  a('W', 'Chivas Extra 13 Años 700ml + GiftPack', 169990, 40);
  a('W', 'The Glenlivet 12 700ml + GiftPack', 229900, 40);
  a('W', 'Chivas 12 Años 700ml + GiftPack', 149990, 40);
  a('W', 'Aberlour Double Cask 12 x 700ml', 287900, 40);
  a('W', 'Buchanan''s Deluxe 12 Años x 750ml + GiftPack', 172990, 40);
  a('W', 'Buchanan''s Pineapple x 750ml', 119700, 35);
  a('W', 'Buchanan''s Deluxe 12 Años 750ml + Gratis Six Pack Club', 172990, 40);
  a('W', 'Chivas 18 Años 700ml + GiftPack', 405000, 40);
  a('W', 'Chivas Regal Crystalgold 700ml', 239900, 40);
  a('W', 'Crema de Whisky Coloma x 750ml', 58990, 17);
  a('W', 'Dewar''s 15 Años x 750ml', 195990, 40);
  a('W', 'Dewar''s 32 Años 500ml', 1999988, 43);
  a('W', 'Glenmorangie A Tale of the Forest x 700ml', 489900, 46);
  a('W', 'Glenmorangie Signet x 700ml', 2015900, 46);
  a('W', 'Glenmorangie Vintage 1998 x 700ml', 6578990, 43);
  a('W', 'Jack Daniel''s x McLaren F1 Edición Limitada', 149900, 40);
  a('W', 'Johnnie Walker Blue Label x 750ml', 1189990, 40);
  a('W', 'King of Queens x 1000ml', 69990, 40);
  a('W', 'Monkey Shoulder 700ml + GiftPack', 169900, 40);
  a('W', 'Nomad Outland x 700ml + Gratis Copa Glencairn', 274990, 41.3);
  a('W', 'Old Rip Van Winkle 10 Years Old x 750ml', 6499900, 53.5);
  a('W', 'Pappy Van Winkle 15 Year Old x 750ml', 16499900, 53.5);
  a('W', 'Pappy Van Winkle''s 20 Year Family Reserve x 750ml', 19999900, 45.2);
  a('W', 'SLYRS Single Malt Rum Cask Finish 700ml + Gratis Copa', 429990, 46);
  a('W', 'The Tottori 700ml', 406900, 43);
  a('W', 'Van Winkle Special Reserve 12 Years Lot B x 750ml', 8499990, 45.2);
  a('W', 'Black Axe Gladstone Blended Malt x 700ml', 199990, 41);
  a('A', 'Antioqueño Verde 750ml', 54900, 24);
  a('A', 'Cumbé 750ml', 120900, 29);
  a('A', 'Naciente Sin Azúcar x 750ml + Copa de la Marca', 69900, 24);
  a('A', 'Néctar Reposado x 700ml', 72990, 29);
  a('A', 'Mil Demonios x 700ml', 100990, 29);
  a('A', 'Néctar Dorado x 750ml', 61990, 29);
  a('A', 'Aguardiente Antioqueño Azul x 1050ml', 79990, 24);
  a('A', 'Aguardiente Néctar Club Sin Azúcar x 375ml', 25900, 24);
  a('A', 'Aguardiente Néctar Club x 1000ml', 58900, 24);
  a('A', 'Néctar Premium x 750ml', 88900, 29);
  a('A', 'Desquite Artesanal x 750ml', 79990, 29);
  a('A', 'Desquite Tradición x 750ml', 84990, 29);
  a('A', 'Antioqueño Real x 750ml', 94990, 24);
  a('A', 'Antioqueño Azul Sin Azúcar x 375ml', 32990, 24);
  a('A', 'Aguardiente Amarillo de Manzanares Sin Azúcar x 750ml', 56990, 29);
  a('A', 'Mil Demonios x 375ml', 59990, 29);
  a('A', 'Antioqueño Azul x 750ml', 62990, 24);
  a('A', 'Aguardiente Rosado x 750ml', 89900, 24);
  a('A', 'Antioqueño Real Sin Azúcar x 1050ml', 49900, 24);
  a('A', 'Antioqueño Real Sin Azúcar x 750ml', 92990, 24);
  a('V', 'Diablo Purple Malbec x 750ml', 106500, 14);
  a('V', 'Vino Tinto Merlot Conquesta x 750ml', 24990, 13);
  a('V', 'Vino Blanco Chardonnay Conquesta x 750ml', 24990, 13);
  a('V', 'Vino Tinto Cabernet Sauvignon Conquesta x 750ml', 24990, 13);
  a('V', 'Marqués de Casa Concha Heritage 2021', 359990, 14);
  a('V', 'Riunite Lambrusco x 750ml', 32990, 8);
  a('V', 'Terrunyo Carmenere x 750ml', 309900, 14);
  a('V', 'Casillero del Diablo Chardonnay x 750ml', 77990, 13.5);
  a('V', 'Nebla Garnacha Tinto x 750ml', 54900, 14);
  a('V', 'B&G Pinot Noir Reserve x 750ml', 72990, 12.5);
  a('V', 'Casas del Bosque Reserva Sauvignon Blanc 750ml', 78900, 13);
  a('V', 'Casillero del Diablo Rosé x 750ml', 69990, 12.5);
  a('V', 'Cata Blanco x 1000ml', 25990, 10);
  a('V', 'Cata Tinto x 1000ml', 25990, 10);
  a('V', 'Combo Especial Sparkling', 62990, 12);
  a('V', 'Concha y Toro Reservado Rosé x 750ml', 29900, 11.5);
  a('V', 'Condesa de Leganza Rosé 750ml', 84900, 13);
  a('V', 'Condesa de Leganza Tempranillo 750ml', 84900, 13.5);
  a('V', 'Decoy Cabernet Sauvignon 750ml', 268990, 14);
  a('V', 'Diablo Dark Red Blend x 750ml', 106500, 14);
  a('C', 'Pack Delirium', 139900, 8.5);
  a('C', 'Maredsous x 330ml', 21500, 10);
  a('C', 'GiftPack La Chouffe x 330ml', 89900, 8);
  a('C', 'Bitburger Barril 5 Lts', 132990, 4.8);
  a('C', 'Pack Cervezas Belgas', 72900, 6.5);
  a('C', 'Colección Frutal', 73990, 4.5);
  a('C', 'Pack del Mundo', 82900, 5);
  a('C', 'Combo Rocker Beer', 40900, 5);
  a('C', 'Pack Alemán x 500ml + Gratis 4 Portavasos', 57900, 5.3);
  a('C', 'Erdinger Pikantus x 500ml', 17900, 7.3);
  a('C', 'Flensburger Weizen x 500ml', 19900, 5.1);
  a('C', 'GiftPack Liefmans Fruitesse x 250ml', 68900, 3.8);
  a('C', 'Flensburger Pilsener x 500ml', 19900, 4.8);
  a('C', 'Bitburger x 330ml', 9990, 4.8);
  a('C', 'Bakalar Dry Hopped 500ml', 14600, 5);
  a('C', 'Bakalar Honey 500ml', 14600, 5);
  a('C', 'BBC Rosé FourPack x 330ml', 21600, 4.2);
  a('C', 'Bitburger x 568ml', 10900, 4.8);
  a('C', 'Brugse Zot Blonde 330ml', 18900, 6);
  a('C', 'Cerveza Asahi Caja x 24 Unidades', 160798, 5);

  -- Quitar los productos anteriores
  FOR r IN (SELECT id_producto FROM producto) LOOP
    IF NOT v_keep.EXISTS(r.id_producto) THEN
      SELECT (SELECT COUNT(*) FROM detalle_venta WHERE id_producto = r.id_producto)
           + (SELECT COUNT(*) FROM detalle_compra WHERE id_producto = r.id_producto)
           + (SELECT COUNT(*) FROM movimiento_inventario WHERE id_producto = r.id_producto)
        INTO v_uso FROM dual;
      IF v_uso = 0 THEN
        DELETE FROM producto WHERE id_producto = r.id_producto; v_borr := v_borr + 1;
      ELSE
        UPDATE producto SET activo = 'N' WHERE id_producto = r.id_producto; v_desac := v_desac + 1;
      END IF;
    END IF;
  END LOOP;
  COMMIT;
  DBMS_OUTPUT.PUT_LINE('Insertados: ' || v_ins || ' | ya existian: ' || v_salt ||
                       ' | borrados: ' || v_borr || ' | desactivados (con historial): ' || v_desac);
END;
/

SELECT c.nombre AS categoria, COUNT(p.id_producto) AS activos
  FROM categoria c LEFT JOIN producto p ON p.id_categoria = c.id_categoria AND p.activo = 'S'
 GROUP BY c.nombre ORDER BY c.nombre;
