import oracledb
from flask import Blueprint, flash, redirect, render_template, request, session, url_for
from werkzeug.security import generate_password_hash

from .. import db
from ..auth.decorators import rol_requerido

bp = Blueprint("usuarios", __name__)

ROLES = ("ADMINISTRADOR", "VENDEDOR", "REPARTIDOR")
MIN_PASSWORD = 6


def _validar_password(password, confirmacion, errores):
    if len(password) < MIN_PASSWORD:
        errores.append(f"La contraseña debe tener al menos {MIN_PASSWORD} caracteres.")
    elif password != confirmacion:
        errores.append("Las contraseñas no coinciden.")


@bp.route("/")
@rol_requerido()
def lista():
    usuarios = db.query(
        "SELECT u.id_usuario, u.username, u.rol, u.activo, u.fecha_creacion, "
        "(SELECT COUNT(*) FROM venta v WHERE v.id_usuario = u.id_usuario) AS num_ventas, "
        "(SELECT COUNT(*) FROM domicilio d WHERE d.id_repartidor = u.id_usuario) AS num_domicilios "
        "FROM usuario u ORDER BY u.activo DESC, u.rol, u.username")
    return render_template("usuarios/lista.html", usuarios=usuarios)


@bp.route("/nuevo", methods=["GET", "POST"])
@rol_requerido()
def nuevo():
    datos = {"rol": "VENDEDOR"}
    if request.method == "POST":
        datos = {"username": request.form.get("username", "").strip(),
                 "rol": request.form.get("rol")}
        errores = []
        if not datos["username"]:
            errores.append("El nombre de usuario es obligatorio.")
        if datos["rol"] not in ROLES:
            errores.append("Selecciona un rol válido.")
        _validar_password(request.form.get("password", ""), request.form.get("confirmar", ""), errores)
        if not errores:
            try:
                db.execute(
                    "INSERT INTO usuario (username, password_hash, rol) VALUES (:u, :h, :r)",
                    {"u": datos["username"], "h": generate_password_hash(request.form["password"]),
                     "r": datos["rol"]})
                flash(f"Usuario {datos['username']} creado.", "success")
                return redirect(url_for("usuarios.lista"))
            except oracledb.DatabaseError as exc:
                errores.append(db.error_oracle(exc))
        for e in errores:
            flash(e, "danger")
    return render_template("usuarios/form.html", usuario=datos, roles=ROLES)


@bp.route("/<int:id_usuario>/editar", methods=["GET", "POST"])
@rol_requerido()
def editar(id_usuario):
    usuario = db.query("SELECT id_usuario, username, rol, activo FROM usuario "
                       "WHERE id_usuario = :id", {"id": id_usuario}, one=True)
    if not usuario:
        flash("Usuario no encontrado.", "warning")
        return redirect(url_for("usuarios.lista"))
    if request.method == "POST":
        rol = request.form.get("rol")
        errores = []
        if rol not in ROLES:
            errores.append("Selecciona un rol válido.")
        if id_usuario == session["id_usuario"] and rol != "ADMINISTRADOR":
            errores.append("No puedes quitarte a ti mismo el rol de administrador.")
        password = request.form.get("password", "")
        if password:
            _validar_password(password, request.form.get("confirmar", ""), errores)
        if not errores:
            db.execute("UPDATE usuario SET rol = :r WHERE id_usuario = :id",
                       {"r": rol, "id": id_usuario}, commit=not password)
            if password:
                db.execute("UPDATE usuario SET password_hash = :h WHERE id_usuario = :id",
                           {"h": generate_password_hash(password), "id": id_usuario})
            flash("Usuario actualizado." + (" Contraseña cambiada." if password else ""), "success")
            return redirect(url_for("usuarios.lista"))
        for e in errores:
            flash(e, "danger")
        usuario = {**usuario, "rol": rol}
    return render_template("usuarios/form.html", usuario=usuario, roles=ROLES)


@bp.route("/<int:id_usuario>/estado", methods=["POST"])
@rol_requerido()
def cambiar_estado(id_usuario):
    if id_usuario == session["id_usuario"]:
        flash("No puedes desactivar tu propio usuario.", "warning")
        return redirect(url_for("usuarios.lista"))
    db.execute("UPDATE usuario SET activo = CASE activo WHEN 'S' THEN 'N' ELSE 'S' END "
               "WHERE id_usuario = :id", {"id": id_usuario})
    flash("Estado del usuario actualizado.", "info")
    return redirect(url_for("usuarios.lista"))
