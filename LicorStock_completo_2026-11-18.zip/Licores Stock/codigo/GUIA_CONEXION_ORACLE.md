# Cómo conectar LicorStock con Oracle

Esta guía explica, paso a paso, cómo se une la aplicación Flask con tu base de datos Oracle
y qué hacer si algo falla. Si solo quieres que funcione, sigue los pasos 1 a 6.
Si quieres entender cómo funciona por dentro (para sustentar el proyecto), lee también el paso 7.

---

## 0. La idea general

```
 Navegador  ──►  Flask (run.py)  ──►  app/db.py  ──►  controlador  ──►  Oracle
 (lo que ves)    (rutas y HTML)      (consultas)     (el "cable")      (tus tablas)
```

La aplicación nunca habla con Oracle "directamente": usa un **controlador** (driver).
Cuál controlador sirve depende de la **versión** de tu Oracle:

| Tu Oracle | Controlador | Qué hay que poner en `.env` |
|---|---|---|
| 12c, 18c, 19c, 21c, 23ai | python-oracledb modo **Thin** (no instala nada más) | solo usuario, clave y DSN |
| 11g | python-oracledb modo **Thick** + Oracle Instant Client | `ORACLE_CLIENT_LIB` |
| **10g** (tu caso) | **JDBC**: el mismo controlador que usa SQL Developer, a través de Java (JPype) | `ORACLE_JDBC_JAR` y `JAVA_JVM_DLL` |

Todo eso ya está programado en `app/db.py` y `app/jdbc_oracle.py`; tú solo eliges con el `.env`.

---

## 1. Averigua tu versión de Oracle

En SQL Developer, en cualquier conexión, ejecuta:

```sql
SELECT * FROM v$version;
```

Si sale `Oracle Database 10g Express Edition`, eres del caso **10g**.

---

## 2. Crea el usuario de la aplicación (una sola vez)

La app trabaja con un usuario propio (tu `.env` usa `LICORES`). Conéctate en SQL Developer
como **SYSTEM** y ejecuta:

```sql
-- Oracle 10g / 11g XE
CREATE USER licores IDENTIFIED BY 1234
  DEFAULT TABLESPACE users QUOTA UNLIMITED ON users;

GRANT CREATE SESSION, CREATE TABLE, CREATE SEQUENCE,
      CREATE TRIGGER, CREATE VIEW, CREATE PROCEDURE TO licores;
```

> En Oracle 21c o 23ai, antes de crear el usuario cambia al contenedor de la aplicación:
> `ALTER SESSION SET CONTAINER = XEPDB1;` (21c) o `FREEPDB1` (23ai).

Si el usuario ya existe y solo olvidaste la clave: `ALTER USER licores IDENTIFIED BY 1234;`

> **Recomendación:** `1234` sirve para la clase, pero si vas a mostrar el proyecto en otro
> computador, usa una clave más larga.

---

## 3. Crea las tablas con el script correcto

1. En SQL Developer crea una conexión nueva: usuario `LICORES`, clave `1234`,
   host `localhost`, puerto `1521`, SID `XE` (o "Nombre del servicio" `XE`). Pulsa **Probar** → debe decir *Correcto*.
2. Con esa conexión abierta, abre **`database/LicorStock_Oracle_revisado.sql`** y ejecútalo con **F5**
   (Ejecutar script, no F9).
3. (Opcional) Ejecuta también **`database/datos_demo.sql`** con F5: agrega 11 productos de licorera
   con su foto y ventas de ejemplo de la última semana, para que el panel y los reportes se vean llenos.

### ⚠️ Usa el archivo *revisado*, no `LicorStock_Oracle (1).sql`

El archivo `LicorStock_Oracle (1).sql` es la versión **anterior**. La aplicación necesita la revisada porque:

| | Script viejo | Script revisado (el que usa la app) |
|---|---|---|
| Métodos de pago | EFECTIVO, TARJETA, TRANSFERENCIA | + **NEQUI** y **DAVIPLATA** |
| Vender sin stock | Falla con un error genérico (ORA-02290) | Mensaje claro: *"Stock insuficiente para…"* |
| Vender alcohol sin verificar edad | Se permite | Se bloquea (RF19) |
| Anular una venta | El stock **no** vuelve | `trg_venta_anulada_au` devuelve las unidades |
| Entregar un domicilio | La fecha de entrega queda vacía | `trg_domicilio_bu` la guarda sola |

Si usas el viejo, la app abre pero fallan las ventas con Nequi/Daviplata, las anulaciones y los domicilios.
El script de prueba (paso 5) te avisa si tienes el viejo.

> El script revisado **borra y vuelve a crear** las tablas: si ya registraste datos reales, haz una
> copia antes (clic derecho en la tabla → Exportar).

---

## 4. Configura el archivo `.env`

El archivo `.env` (en la carpeta `codigo/`) guarda los datos de conexión. Nunca lo subas a GitHub
ni lo compartas: tiene tu contraseña.

### Oracle 10g (tu caso, por JDBC)

```ini
SECRET_KEY=una-frase-larga-y-secreta
ORACLE_USER=LICORES
ORACLE_PASSWORD=1234
ORACLE_DSN=localhost:1521/XE
EDAD_MINIMA=18
ORACLE_JDBC_JAR=C:\sqldeveloper\jdbc\lib\ojdbc11.jar
JAVA_JVM_DLL=C:\Program Files\Java\jdk-24\bin\server\jvm.dll
```

- `ORACLE_JDBC_JAR`: busca el archivo `ojdbc*.jar` dentro de la carpeta de SQL Developer
  (`sqldeveloper\jdbc\lib\`). Copia la ruta exacta (clic derecho → *Copiar como ruta*, sin comillas).
- `JAVA_JVM_DLL`: está dentro del JDK instalado, en `bin\server\jvm.dll`. Si no tienes JDK,
  instala uno (17 o superior).
- Si al conectar sale **ORA-28040**, tu 10g no acepta ese controlador tan nuevo. Usa uno más antiguo:
  `ojdbc6.jar` (versión 11.2.0.4, se descarga gratis de Maven Central buscando *ojdbc6 11.2.0.4*) o el
  `ojdbc14.jar` que trae el propio 10g en `C:\oraclexe\app\oracle\product\10.2.0\server\jdbc\lib\`.

### Oracle 11g (Instant Client)

```ini
ORACLE_USER=LICORES
ORACLE_PASSWORD=1234
ORACLE_DSN=localhost:1521/XE
ORACLE_CLIENT_LIB=C:\oracle\instantclient_11_2
```
(Borra o comenta con `#` las líneas `ORACLE_JDBC_JAR` y `JAVA_JVM_DLL`.)

### Oracle 21c / 23ai (lo más sencillo)

```ini
ORACLE_USER=LICORES
ORACLE_PASSWORD=1234
ORACLE_DSN=localhost:1521/XEPDB1
```
(En 23ai Free el servicio es `FREEPDB1`. No hace falta Java ni Instant Client.)

---

## 5. Instala lo de Python y prueba la conexión

En una terminal dentro de `codigo/` (solo la primera vez):

```bat
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

Luego haz **doble clic en `PROBAR_CONEXION.cmd`** (o `python probar_conexion.py`). Revisa, en orden:

1. que el `.env` tenga datos y que existan los archivos de Java/JDBC,
2. que Oracle responda,
3. con qué usuario y versión quedaste conectado,
4. que estén las 12 tablas (y cuántas filas tiene cada una),
5. que estén los triggers de la versión revisada.

Si algo falla, te dice **qué pasa y cómo arreglarlo** en español.

---

## 6. Arranca la aplicación

Doble clic en **`INICIAR.cmd`** (o `flask --app run run --debug`) y abre http://127.0.0.1:5000

Los usuarios migrados (karen, Ciro, juan…) entran con sus contraseñas de siempre.
Para crear otro administrador: `flask --app run crear-admin`.

---

## 7. Cómo funciona por dentro (para la sustentación)

### 7.1 La configuración — `config.py`
Lee el `.env` con `python-dotenv` y deja los valores en `Config`. Así la contraseña no queda escrita en el código.

### 7.2 El *pool* de conexiones — `app/db.py → init_pool()`
Abrir una conexión con Oracle es lento, así que al arrancar se crea un **pool** (un grupo de conexiones
listas para usar). Según el `.env` se elige el controlador:

```python
if app.config.get("ORACLE_JDBC_JAR"):        # Oracle 10g
    _pool = jdbc_oracle.create_pool(...)
    return
if app.config.get("ORACLE_CLIENT_LIB"):      # Oracle 11g
    oracledb.init_oracle_client(lib_dir=...)
_pool = oracledb.create_pool(user=..., password=..., dsn=..., min=1, max=5)
```

En cada petición del navegador, `get_conn()` toma una conexión del pool y `close_conn()` la devuelve al final.

### 7.3 Consultas parametrizadas (seguridad)
Todas las consultas usan **variables de enlace** `:nombre`, nunca texto pegado:

```python
db.query("SELECT * FROM producto WHERE id_producto = :id", {"id": id_producto}, one=True)
```

Así es imposible la **inyección SQL** (alguien escribiendo `' OR 1=1 --` en un formulario).

### 7.4 Ids automáticos en Oracle 10g
10g no tiene columnas autoincrementales. Por eso cada tabla tiene una **secuencia** (`seq_producto`) y un
**trigger** (`trg_producto_bi`) que pone el id si no se envía. Cuando la app necesita saber el id recién creado
usa `RETURNING id_venta INTO :new_id` (ver `insert_returning_id`).

### 7.5 Transacciones (RNF02)
Una venta toca 4 tablas: `venta`, `detalle_venta`, `pago` y `domicilio`. En `ventas/routes.py → _registrar_venta()`
todo va en **una sola transacción**: si cualquier paso falla (por ejemplo, no hay stock), se hace `rollback()`
y no queda nada a medias. Solo si todo sale bien se hace `commit()`.

### 7.6 Reglas en la base de datos
Los triggers hacen el trabajo pesado: `trg_detalle_venta_ai` valida stock y edad y descuenta inventario;
`trg_detalle_compra_ai` suma stock; ambos dejan registro en `movimiento_inventario`. Si un trigger lanza
`RAISE_APPLICATION_ERROR(-20001, 'Stock insuficiente…')`, `db.error_oracle()` muestra ese mensaje en pantalla.

### 7.7 ¿Por qué JDBC para 10g?
`python-oracledb` (el controlador oficial de Python) solo soporta 12c en adelante en modo Thin, y el
Instant Client que funciona con 10g ya no se descarga. `app/jdbc_oracle.py` usa **JPype** para arrancar
Java y usar `ojdbc*.jar` (el de SQL Developer), y "imita" la misma interfaz que `python-oracledb`
(pool, cursor, `:binds`, `RETURNING … INTO`). Por eso el resto del código no cambia según la versión.

---

## 8. Fotos de los productos

- Las fotos están en `app/static/img/productos/`. La columna `PRODUCTO.IMAGEN` guarda solo el **nombre del archivo**
  (ej. `ron.jpg`) o una **URL** completa (`https://…`).
- Para cambiar una foto: **Productos → Editar → Subir o arrastrar una foto** (JPG, PNG o WEBP, máx. 5 MB).
  La app la guarda con un nombre único y actualiza la columna sola.
- Si un producto no tiene foto, se muestra la imagen de su **categoría** (`app/static/img/categorias/`).
- Las imágenes incluidas son ilustraciones de estudio genéricas (sin marcas). Para una tienda real,
  lo ideal es subir la foto real de cada producto (del proveedor o tomada con el celular, fondo claro y cuadrada).

---

## 9. Errores frecuentes

| Mensaje | Qué significa | Solución |
|---|---|---|
| `ORA-12541` / `DPY-6005` / *Connection refused* | Oracle no está encendido o el puerto es otro | `services.msc` → inicia **OracleServiceXE** y **OracleXETNSListener** |
| `ORA-12514` / `ORA-12505` | El servicio del DSN no existe | 10g/11g: `/XE` · 21c: `/XEPDB1` · 23ai: `/FREEPDB1` |
| `ORA-01017` | Usuario o clave incorrectos | Revisa `.env`; prueba la misma clave en SQL Developer |
| `ORA-28000` | Cuenta bloqueada | Como SYSTEM: `ALTER USER licores ACCOUNT UNLOCK;` |
| `ORA-28040` | Controlador JDBC muy nuevo para 10g | Usa `ojdbc6.jar` (11.2.0.4) u `ojdbc14.jar` en `ORACLE_JDBC_JAR` |
| `ORA-00942: table or view does not exist` | Las tablas están en otro usuario | Ejecuta el script conectado como el usuario del `.env` |
| `ORA-01031: insufficient privileges` | Al usuario le faltan permisos | Repite los `GRANT` del paso 2 |
| `DPY-3010` | Modo Thin con Oracle 10g/11g | Usa JDBC (10g) o Instant Client (11g), paso 4 |
| `JVMNotFoundException` | No encuentra Java | Revisa `JAVA_JVM_DLL` |
| `No module named 'jpype'` | Faltan librerías | `pip install -r requirements.txt` con el venv activado |
| `check constraint (CK_PAGO_METODO) violated` | Script viejo sin Nequi/Daviplata | Ejecuta `LicorStock_Oracle_revisado.sql` |
