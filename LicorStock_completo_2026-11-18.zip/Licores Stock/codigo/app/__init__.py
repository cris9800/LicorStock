import secrets
import unicodedata
from pathlib import Path

import click
from flask import Flask, abort, flash, redirect, request, session, url_for
from werkzeug.security import generate_password_hash

from config import Config
from . import db


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    if not app.config.get("TESTING"):
        db.init_pool(app)
    app.teardown_appcontext(db.close_conn)

    _registrar_csrf(app)
    _registrar_blueprints(app)
    _registrar_comandos(app)
    _registrar_filtros(app)
    return app


def _registrar_blueprints(app):
    from .auth.routes import bp as auth_bp
    from .main.routes import bp as main_bp
    from .productos.routes import bp as productos_bp
    from .ventas.routes import bp as ventas_bp
    from .inventario.routes import bp as inventario_bp
    from .clientes.routes import bp as clientes_bp
    from .proveedores.routes import bp as proveedores_bp
    from .compras.routes import bp as compras_bp
    from .domicilios.routes import bp as domicilios_bp
    from .caja.routes import bp as caja_bp
    from .reportes.routes import bp as reportes_bp
    from .usuarios.routes import bp as usuarios_bp
    from .tienda.routes import bp as tienda_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(productos_bp, url_prefix="/productos")
    app.register_blueprint(ventas_bp, url_prefix="/ventas")
    app.register_blueprint(inventario_bp, url_prefix="/inventario")
    app.register_blueprint(clientes_bp, url_prefix="/clientes")
    app.register_blueprint(proveedores_bp, url_prefix="/proveedores")
    app.register_blueprint(compras_bp, url_prefix="/compras")
    app.register_blueprint(domicilios_bp, url_prefix="/domicilios")
    app.register_blueprint(caja_bp, url_prefix="/caja")
    app.register_blueprint(reportes_bp, url_prefix="/reportes")
    app.register_blueprint(usuarios_bp, url_prefix="/usuarios")
    app.register_blueprint(tienda_bp, url_prefix="/tienda")


def _registrar_csrf(app):
    """Protección CSRF sencilla: un token por sesión en cada formulario POST."""

    def csrf_token():
        if "_csrf" not in session:
            session["_csrf"] = secrets.token_hex(16)
        return session["_csrf"]

    app.jinja_env.globals["csrf_token"] = csrf_token

    @app.before_request
    def validar_csrf():
        if request.method == "POST" and not app.config.get("TESTING"):
            esperado = session.get("_csrf")
            if not esperado or request.form.get("_csrf") != esperado:
                abort(400, "Token CSRF inválido")


def slug(texto):
    """'Bebidas sin alcohol' -> 'bebidas-sin-alcohol' (sin tildes)."""
    texto = unicodedata.normalize("NFKD", texto or "").encode("ascii", "ignore").decode()
    return "-".join(texto.lower().split())


def _registrar_filtros(app):
    @app.template_filter("pesos")
    def pesos(valor):
        return "$ {:,.0f}".format(valor or 0).replace(",", ".")

    carpeta_img = Path(app.static_folder) / "img"

    @app.template_global()
    def imagen_producto(p):
        """URL de la foto del producto.

        1. Si la columna IMAGEN tiene una URL (http...), se usa tal cual.
        2. Si tiene un nombre de archivo y existe en static/img/productos, se usa ese archivo.
        3. Si no, se muestra la imagen de su categoría o una genérica.
        """
        imagen = (p.get("imagen") if hasattr(p, "get") else None) or ""
        if imagen.startswith(("http://", "https://")):
            return imagen
        if imagen and (carpeta_img / "productos" / imagen).is_file():
            return url_for("static", filename=f"img/productos/{imagen}")
        cat = slug(p.get("categoria") if hasattr(p, "get") else "")
        if cat and (carpeta_img / "categorias" / f"{cat}.png").is_file():
            return url_for("static", filename=f"img/categorias/{cat}.png")
        return url_for("static", filename="img/categorias/generico.png")

    @app.template_global()
    def iniciales(nombre):
        return (nombre or "?")[:1].upper()

    @app.errorhandler(413)
    def archivo_muy_grande(_e):
        flash("La imagen es muy pesada (máximo 5 MB).", "danger")
        return redirect(request.referrer or url_for("productos.lista"))


def _registrar_comandos(app):
    @app.cli.command("crear-admin")
    @click.option("--usuario", prompt=True)
    @click.password_option()
    def crear_admin(usuario, password):
        """Crea un usuario con rol ADMINISTRADOR."""
        db.execute(
            "INSERT INTO usuario (username, password_hash, rol) "
            "VALUES (:usuario, :hash, 'ADMINISTRADOR')",
            {"usuario": usuario, "hash": generate_password_hash(password)},
        )
        click.echo(f"Administrador '{usuario}' creado.")
