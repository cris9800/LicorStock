-- =====================================================================
-- LicorStock - Base de datos Oracle (compatible con 10g XE, 11g y 21c)
-- Version revisada: ver los comentarios marcados con [REVISION]
-- Migrada desde TiendaBD.sql (MySQL, base "tienda2")
-- Ejecutar en SQL Developer con F5 (Ejecutar script), conectada como TIENDA_VIRTUAL.
-- Requiere los privilegios: CREATE TABLE, CREATE SEQUENCE, CREATE TRIGGER, CREATE VIEW
--
-- El script se puede ejecutar varias veces: la seccion 0 borra lo que ya
-- exista (sin fallar si no existe) y vuelve a crear todo desde cero.
-- =====================================================================
SET DEFINE OFF;

-- ---------------------------------------------------------------------
-- 0. LIMPIEZA (borra objetos previos si existen)
-- ---------------------------------------------------------------------
BEGIN
  FOR v IN (SELECT 'v_productos_bajo_stock' n FROM dual UNION ALL
            SELECT 'v_caja_diaria' FROM dual) LOOP
    BEGIN EXECUTE IMMEDIATE 'DROP VIEW ' || v.n; EXCEPTION WHEN OTHERS THEN NULL; END;
  END LOOP;

  FOR t IN (SELECT 'movimiento_inventario' n FROM dual UNION ALL
            SELECT 'detalle_compra' FROM dual UNION ALL
            SELECT 'compra' FROM dual UNION ALL
            SELECT 'domicilio' FROM dual UNION ALL
            SELECT 'pago' FROM dual UNION ALL
            SELECT 'detalle_venta' FROM dual UNION ALL
            SELECT 'venta' FROM dual UNION ALL
            SELECT 'cliente' FROM dual UNION ALL
            SELECT 'producto' FROM dual UNION ALL
            SELECT 'proveedor' FROM dual UNION ALL
            SELECT 'categoria' FROM dual UNION ALL
            SELECT 'usuario' FROM dual) LOOP
    BEGIN EXECUTE IMMEDIATE 'DROP TABLE ' || t.n || ' CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
  END LOOP;

  FOR s IN (SELECT 'seq_usuario' n FROM dual UNION ALL
            SELECT 'seq_categoria' FROM dual UNION ALL
            SELECT 'seq_proveedor' FROM dual UNION ALL
            SELECT 'seq_producto' FROM dual UNION ALL
            SELECT 'seq_cliente' FROM dual UNION ALL
            SELECT 'seq_venta' FROM dual UNION ALL
            SELECT 'seq_pago' FROM dual UNION ALL
            SELECT 'seq_domicilio' FROM dual UNION ALL
            SELECT 'seq_compra' FROM dual UNION ALL
            SELECT 'seq_movimiento' FROM dual) LOOP
    BEGIN EXECUTE IMMEDIATE 'DROP SEQUENCE ' || s.n; EXCEPTION WHEN OTHERS THEN NULL; END;
  END LOOP;
END;
/

-- ---------------------------------------------------------------------
-- 1. TABLAS
-- ---------------------------------------------------------------------
CREATE TABLE usuario (
  id_usuario      NUMBER(10)    CONSTRAINT pk_usuario PRIMARY KEY,
  username        VARCHAR2(50)  NOT NULL CONSTRAINT uq_usuario_username UNIQUE,
  password_hash   VARCHAR2(255) NOT NULL,
  rol             VARCHAR2(20)  DEFAULT 'VENDEDOR' NOT NULL
                  CONSTRAINT ck_usuario_rol CHECK (rol IN ('ADMINISTRADOR','VENDEDOR','REPARTIDOR')),
  activo          CHAR(1)       DEFAULT 'S' NOT NULL CONSTRAINT ck_usuario_activo CHECK (activo IN ('S','N')),
  fecha_creacion  DATE          DEFAULT SYSDATE NOT NULL
);

CREATE TABLE categoria (
  id_categoria  NUMBER(10)    CONSTRAINT pk_categoria PRIMARY KEY,
  nombre        VARCHAR2(50)  NOT NULL CONSTRAINT uq_categoria_nombre UNIQUE,
  descripcion   VARCHAR2(500),
  activo        CHAR(1)       DEFAULT 'S' NOT NULL CONSTRAINT ck_categoria_activo CHECK (activo IN ('S','N'))
);

CREATE TABLE proveedor (
  id_proveedor  NUMBER(10)    CONSTRAINT pk_proveedor PRIMARY KEY,
  nit           VARCHAR2(20)  NOT NULL CONSTRAINT uq_proveedor_nit UNIQUE,
  nombre        VARCHAR2(100) NOT NULL,
  telefono      VARCHAR2(20),
  direccion     VARCHAR2(150),
  activo        CHAR(1)       DEFAULT 'S' NOT NULL CONSTRAINT ck_proveedor_activo CHECK (activo IN ('S','N'))
);

CREATE TABLE producto (
  id_producto    NUMBER(10)    CONSTRAINT pk_producto PRIMARY KEY,
  id_categoria   NUMBER(10)    NOT NULL CONSTRAINT fk_producto_categoria REFERENCES categoria (id_categoria),
  id_proveedor   NUMBER(10)    CONSTRAINT fk_producto_proveedor REFERENCES proveedor (id_proveedor),
  nombre         VARCHAR2(100) NOT NULL,
  descripcion    VARCHAR2(500),
  es_alcoholico  CHAR(1)       DEFAULT 'S' NOT NULL CONSTRAINT ck_producto_alcoholico CHECK (es_alcoholico IN ('S','N')),
  grado_alcohol  NUMBER(4,1)   CONSTRAINT ck_producto_grado CHECK (grado_alcohol BETWEEN 0 AND 100),
  precio_venta   NUMBER(10)    NOT NULL CONSTRAINT ck_producto_precio CHECK (precio_venta >= 0),
  stock_actual   NUMBER(8)     DEFAULT 0 NOT NULL CONSTRAINT ck_producto_stock CHECK (stock_actual >= 0),
  stock_minimo   NUMBER(8)     DEFAULT 5 NOT NULL CONSTRAINT ck_producto_stockmin CHECK (stock_minimo >= 0),
  imagen         VARCHAR2(255),
  activo         CHAR(1)       DEFAULT 'S' NOT NULL CONSTRAINT ck_producto_activo CHECK (activo IN ('S','N'))
);

CREATE TABLE cliente (
  id_cliente        NUMBER(10)    CONSTRAINT pk_cliente PRIMARY KEY,
  tipo_documento    VARCHAR2(5)   NOT NULL CONSTRAINT ck_cliente_tipodoc CHECK (tipo_documento IN ('CC','CE','PA','NIT')),
  numero_documento  VARCHAR2(20)  NOT NULL,
  nombre            VARCHAR2(80)  NOT NULL,
  apellido          VARCHAR2(80),
  email             VARCHAR2(100),
  telefono          VARCHAR2(20),
  direccion         VARCHAR2(150),
  fecha_nacimiento  DATE,
  activo            CHAR(1)       DEFAULT 'S' NOT NULL CONSTRAINT ck_cliente_activo CHECK (activo IN ('S','N')),
  CONSTRAINT uq_cliente_documento UNIQUE (tipo_documento, numero_documento)
);

CREATE TABLE venta (
  id_venta         NUMBER(10)   CONSTRAINT pk_venta PRIMARY KEY,
  id_cliente       NUMBER(10)   CONSTRAINT fk_venta_cliente REFERENCES cliente (id_cliente),
  id_usuario       NUMBER(10)   NOT NULL CONSTRAINT fk_venta_usuario REFERENCES usuario (id_usuario),
  fecha            DATE         DEFAULT SYSDATE NOT NULL,
  total            NUMBER(12)   DEFAULT 0 NOT NULL CONSTRAINT ck_venta_total CHECK (total >= 0),
  tipo_venta       VARCHAR2(10) DEFAULT 'MOSTRADOR' NOT NULL
                   CONSTRAINT ck_venta_tipo CHECK (tipo_venta IN ('MOSTRADOR','DOMICILIO')),
  estado           VARCHAR2(12) DEFAULT 'COMPLETADA' NOT NULL
                   CONSTRAINT ck_venta_estado CHECK (estado IN ('COMPLETADA','ANULADA')),
  edad_verificada  CHAR(1)      DEFAULT 'N' NOT NULL CONSTRAINT ck_venta_edad CHECK (edad_verificada IN ('S','N'))
);

CREATE TABLE detalle_venta (
  id_venta         NUMBER(10) NOT NULL CONSTRAINT fk_detventa_venta REFERENCES venta (id_venta),
  id_producto      NUMBER(10) NOT NULL CONSTRAINT fk_detventa_producto REFERENCES producto (id_producto),
  cantidad         NUMBER(6)  NOT NULL CONSTRAINT ck_detventa_cantidad CHECK (cantidad > 0),
  precio_unitario  NUMBER(10) NOT NULL CONSTRAINT ck_detventa_precio CHECK (precio_unitario >= 0),
  CONSTRAINT pk_detalle_venta PRIMARY KEY (id_venta, id_producto)
);

CREATE TABLE pago (
  id_pago   NUMBER(10)   CONSTRAINT pk_pago PRIMARY KEY,
  id_venta  NUMBER(10)   NOT NULL CONSTRAINT fk_pago_venta REFERENCES venta (id_venta),
  fecha     DATE         DEFAULT SYSDATE NOT NULL,
  metodo    VARCHAR2(20) NOT NULL CONSTRAINT ck_pago_metodo CHECK (metodo IN ('EFECTIVO','TARJETA','TRANSFERENCIA','NEQUI','DAVIPLATA')),
  valor     NUMBER(12)   NOT NULL CONSTRAINT ck_pago_valor CHECK (valor >= 0),
  estado    VARCHAR2(12) DEFAULT 'PAGADO' NOT NULL
            CONSTRAINT ck_pago_estado CHECK (estado IN ('PENDIENTE','PAGADO','RECHAZADO'))
);

CREATE TABLE domicilio (
  id_domicilio       NUMBER(10)    CONSTRAINT pk_domicilio PRIMARY KEY,
  id_venta           NUMBER(10)    NOT NULL CONSTRAINT uq_domicilio_venta UNIQUE
                     CONSTRAINT fk_domicilio_venta REFERENCES venta (id_venta),
  id_repartidor      NUMBER(10)    CONSTRAINT fk_domicilio_repartidor REFERENCES usuario (id_usuario),
  direccion_entrega  VARCHAR2(200) NOT NULL,
  telefono_contacto  VARCHAR2(20),
  estado             VARCHAR2(12)  DEFAULT 'PENDIENTE' NOT NULL
                     CONSTRAINT ck_domicilio_estado CHECK (estado IN ('PENDIENTE','EN_CAMINO','ENTREGADO','CANCELADO')),
  fecha_pedido       DATE          DEFAULT SYSDATE NOT NULL,
  fecha_entrega      DATE,
  observaciones      VARCHAR2(300)
);

CREATE TABLE compra (
  id_compra     NUMBER(10)  CONSTRAINT pk_compra PRIMARY KEY,
  id_proveedor  NUMBER(10)  NOT NULL CONSTRAINT fk_compra_proveedor REFERENCES proveedor (id_proveedor),
  id_usuario    NUMBER(10)  NOT NULL CONSTRAINT fk_compra_usuario REFERENCES usuario (id_usuario),
  fecha         DATE        DEFAULT SYSDATE NOT NULL,
  total         NUMBER(12)  DEFAULT 0 NOT NULL CONSTRAINT ck_compra_total CHECK (total >= 0)
);

CREATE TABLE detalle_compra (
  id_compra       NUMBER(10) NOT NULL CONSTRAINT fk_detcompra_compra REFERENCES compra (id_compra),
  id_producto     NUMBER(10) NOT NULL CONSTRAINT fk_detcompra_producto REFERENCES producto (id_producto),
  cantidad        NUMBER(6)  NOT NULL CONSTRAINT ck_detcompra_cantidad CHECK (cantidad > 0),
  costo_unitario  NUMBER(10) NOT NULL CONSTRAINT ck_detcompra_costo CHECK (costo_unitario >= 0),
  CONSTRAINT pk_detalle_compra PRIMARY KEY (id_compra, id_producto)
);

-- Entrada/Salida: cantidad siempre positiva. Ajuste: cantidad con signo (+ suma, - resta).
CREATE TABLE movimiento_inventario (
  id_movimiento  NUMBER(10)    CONSTRAINT pk_movimiento PRIMARY KEY,
  id_producto    NUMBER(10)    NOT NULL CONSTRAINT fk_mov_producto REFERENCES producto (id_producto),
  tipo           VARCHAR2(10)  NOT NULL CONSTRAINT ck_mov_tipo CHECK (tipo IN ('ENTRADA','SALIDA','AJUSTE')),
  cantidad       NUMBER(8)     NOT NULL,
  fecha          DATE          DEFAULT SYSDATE NOT NULL,
  motivo         VARCHAR2(100),
  id_usuario     NUMBER(10)    CONSTRAINT fk_mov_usuario REFERENCES usuario (id_usuario),
  id_venta       NUMBER(10)    CONSTRAINT fk_mov_venta REFERENCES venta (id_venta),
  id_compra      NUMBER(10)    CONSTRAINT fk_mov_compra REFERENCES compra (id_compra),
  CONSTRAINT ck_mov_cantidad CHECK ((tipo IN ('ENTRADA','SALIDA') AND cantidad > 0)
                                 OR (tipo = 'AJUSTE' AND cantidad <> 0))
);

-- ---------------------------------------------------------------------
-- 2. SECUENCIAS (Oracle 10g no tiene columnas autoincrementales)
--    Las que tienen datos migrados arrancan despues del ultimo id usado.
-- ---------------------------------------------------------------------
CREATE SEQUENCE seq_usuario START WITH 8 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_categoria START WITH 9 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_proveedor START WITH 11 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_producto START WITH 100 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_cliente START WITH 11 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_venta START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_pago START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_domicilio START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_compra START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_movimiento START WITH 1 INCREMENT BY 1 NOCACHE;

-- ---------------------------------------------------------------------
-- 3. TRIGGERS
-- 3.1 Asignan el id con la secuencia si no se envia uno
-- ---------------------------------------------------------------------
CREATE OR REPLACE TRIGGER trg_usuario_bi
BEFORE INSERT ON usuario FOR EACH ROW
BEGIN
  IF :NEW.id_usuario IS NULL THEN
    SELECT seq_usuario.NEXTVAL INTO :NEW.id_usuario FROM dual;
  END IF;
END;
/

CREATE OR REPLACE TRIGGER trg_categoria_bi
BEFORE INSERT ON categoria FOR EACH ROW
BEGIN
  IF :NEW.id_categoria IS NULL THEN
    SELECT seq_categoria.NEXTVAL INTO :NEW.id_categoria FROM dual;
  END IF;
END;
/

CREATE OR REPLACE TRIGGER trg_proveedor_bi
BEFORE INSERT ON proveedor FOR EACH ROW
BEGIN
  IF :NEW.id_proveedor IS NULL THEN
    SELECT seq_proveedor.NEXTVAL INTO :NEW.id_proveedor FROM dual;
  END IF;
END;
/

CREATE OR REPLACE TRIGGER trg_producto_bi
BEFORE INSERT ON producto FOR EACH ROW
BEGIN
  IF :NEW.id_producto IS NULL THEN
    SELECT seq_producto.NEXTVAL INTO :NEW.id_producto FROM dual;
  END IF;
END;
/

CREATE OR REPLACE TRIGGER trg_cliente_bi
BEFORE INSERT ON cliente FOR EACH ROW
BEGIN
  IF :NEW.id_cliente IS NULL THEN
    SELECT seq_cliente.NEXTVAL INTO :NEW.id_cliente FROM dual;
  END IF;
END;
/

CREATE OR REPLACE TRIGGER trg_venta_bi
BEFORE INSERT ON venta FOR EACH ROW
BEGIN
  IF :NEW.id_venta IS NULL THEN
    SELECT seq_venta.NEXTVAL INTO :NEW.id_venta FROM dual;
  END IF;
END;
/

CREATE OR REPLACE TRIGGER trg_pago_bi
BEFORE INSERT ON pago FOR EACH ROW
BEGIN
  IF :NEW.id_pago IS NULL THEN
    SELECT seq_pago.NEXTVAL INTO :NEW.id_pago FROM dual;
  END IF;
END;
/

CREATE OR REPLACE TRIGGER trg_domicilio_bi
BEFORE INSERT ON domicilio FOR EACH ROW
BEGIN
  IF :NEW.id_domicilio IS NULL THEN
    SELECT seq_domicilio.NEXTVAL INTO :NEW.id_domicilio FROM dual;
  END IF;
END;
/

CREATE OR REPLACE TRIGGER trg_compra_bi
BEFORE INSERT ON compra FOR EACH ROW
BEGIN
  IF :NEW.id_compra IS NULL THEN
    SELECT seq_compra.NEXTVAL INTO :NEW.id_compra FROM dual;
  END IF;
END;
/

CREATE OR REPLACE TRIGGER trg_movimiento_inventario_bi
BEFORE INSERT ON movimiento_inventario FOR EACH ROW
BEGIN
  IF :NEW.id_movimiento IS NULL THEN
    SELECT seq_movimiento.NEXTVAL INTO :NEW.id_movimiento FROM dual;
  END IF;
END;
/

-- 3.2 Al registrar el detalle de una venta: descuenta stock y deja el movimiento.
--     [REVISION] Ahora es BEFORE INSERT y valida dos reglas de RF19 con un
--     mensaje claro (ORA-20001 / ORA-20002) que Flask puede mostrar tal cual:
--       - no vender mas unidades de las que hay en stock
--       - no vender productos alcoholicos si la venta no tiene edad_verificada = 'S'
CREATE OR REPLACE TRIGGER trg_detalle_venta_ai
BEFORE INSERT ON detalle_venta FOR EACH ROW
DECLARE
  v_stock       producto.stock_actual%TYPE;
  v_nombre      producto.nombre%TYPE;
  v_alcoholico  producto.es_alcoholico%TYPE;
  v_edad        venta.edad_verificada%TYPE;
  v_usuario     venta.id_usuario%TYPE;
BEGIN
  SELECT stock_actual, nombre, es_alcoholico
    INTO v_stock, v_nombre, v_alcoholico
    FROM producto
   WHERE id_producto = :NEW.id_producto
     FOR UPDATE;

  SELECT edad_verificada, id_usuario INTO v_edad, v_usuario
    FROM venta
   WHERE id_venta = :NEW.id_venta;

  IF v_alcoholico = 'S' AND v_edad <> 'S' THEN
    RAISE_APPLICATION_ERROR(-20002,
      'No se puede vender ' || v_nombre || ': falta verificar la mayoria de edad del cliente');
  END IF;

  IF :NEW.cantidad > v_stock THEN
    RAISE_APPLICATION_ERROR(-20001,
      'Stock insuficiente para ' || v_nombre ||
      ' (disponible: ' || v_stock || ', solicitado: ' || :NEW.cantidad || ')');
  END IF;

  UPDATE producto
     SET stock_actual = stock_actual - :NEW.cantidad
   WHERE id_producto = :NEW.id_producto;

  INSERT INTO movimiento_inventario (id_producto, tipo, cantidad, motivo, id_usuario, id_venta)
  VALUES (:NEW.id_producto, 'SALIDA', :NEW.cantidad, 'Venta', v_usuario, :NEW.id_venta);
END;
/

-- 3.3 Al registrar el detalle de una compra: suma stock y deja el movimiento.
CREATE OR REPLACE TRIGGER trg_detalle_compra_ai
AFTER INSERT ON detalle_compra FOR EACH ROW
BEGIN
  UPDATE producto
     SET stock_actual = stock_actual + :NEW.cantidad
   WHERE id_producto = :NEW.id_producto;

  INSERT INTO movimiento_inventario (id_producto, tipo, cantidad, motivo, id_usuario, id_compra)
  SELECT :NEW.id_producto, 'ENTRADA', :NEW.cantidad, 'Compra a proveedor', c.id_usuario, :NEW.id_compra
    FROM compra c
   WHERE c.id_compra = :NEW.id_compra;
END;
/

-- 3.4 [REVISION] Al anular una venta, devuelve las unidades al inventario.
CREATE OR REPLACE TRIGGER trg_venta_anulada_au
AFTER UPDATE OF estado ON venta FOR EACH ROW
WHEN (NEW.estado = 'ANULADA' AND OLD.estado = 'COMPLETADA')
BEGIN
  FOR d IN (SELECT id_producto, cantidad FROM detalle_venta WHERE id_venta = :NEW.id_venta) LOOP
    UPDATE producto
       SET stock_actual = stock_actual + d.cantidad
     WHERE id_producto = d.id_producto;

    INSERT INTO movimiento_inventario (id_producto, tipo, cantidad, motivo, id_usuario, id_venta)
    VALUES (d.id_producto, 'ENTRADA', d.cantidad, 'Anulacion de venta', :NEW.id_usuario, :NEW.id_venta);
  END LOOP;
END;
/

-- 3.5 [REVISION] Guarda la fecha de entrega cuando el domicilio pasa a ENTREGADO.
CREATE OR REPLACE TRIGGER trg_domicilio_bu
BEFORE UPDATE OF estado ON domicilio FOR EACH ROW
BEGIN
  IF :NEW.estado = 'ENTREGADO' AND :OLD.estado <> 'ENTREGADO' THEN
    :NEW.fecha_entrega := SYSDATE;
  END IF;
END;
/

-- ---------------------------------------------------------------------
-- 3.6 [REVISION] Indices en las llaves foraneas mas consultadas.
--     Oracle no los crea solo y sin ellos los JOIN y reportes se vuelven lentos.
-- ---------------------------------------------------------------------
CREATE INDEX ix_producto_categoria ON producto (id_categoria);
CREATE INDEX ix_venta_fecha        ON venta (fecha);
CREATE INDEX ix_venta_cliente      ON venta (id_cliente);
CREATE INDEX ix_pago_venta         ON pago (id_venta);
CREATE INDEX ix_domicilio_estado   ON domicilio (estado);
CREATE INDEX ix_mov_producto_fecha ON movimiento_inventario (id_producto, fecha);

-- ---------------------------------------------------------------------
-- 4. VISTAS
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW v_productos_bajo_stock AS
SELECT p.id_producto, p.nombre, c.nombre AS categoria, p.stock_actual, p.stock_minimo
  FROM producto p
  JOIN categoria c ON c.id_categoria = p.id_categoria
 WHERE p.activo = 'S'
   AND p.stock_actual <= p.stock_minimo;

CREATE OR REPLACE VIEW v_caja_diaria AS
SELECT TRUNC(fecha) AS dia, metodo, COUNT(*) AS num_pagos, SUM(valor) AS total_ingresos
  FROM pago
 WHERE estado = 'PAGADO'
 GROUP BY TRUNC(fecha), metodo;

-- ---------------------------------------------------------------------
-- 5. DATOS MIGRADOS DE TiendaBD
-- ---------------------------------------------------------------------
-- 5.1 Usuarios (los hashes scrypt de Flask se copian tal cual; 'usuario' pasa a VENDEDOR)
INSERT INTO usuario (id_usuario, username, password_hash, rol) VALUES (1, 'karen', 'scrypt:32768:8:1$bQ8QeTq0EjmN4y60$18bee9140be077fd0a347251d2396c6b2b751bbcffe8d84f75fe1b951ff8ea390a562efb7fbaf9151e8c1ded7c70262023d6a4fc74e6629a09210914acae3dc0', 'ADMINISTRADOR');
INSERT INTO usuario (id_usuario, username, password_hash, rol) VALUES (2, 'juan', 'scrypt:32768:8:1$FJV68rF22iGY1zHy$9be89b582784765c52e88423fc36ee01e03a181b1760784f23029f55a9ec87d3821ba08d6c4aa78fe3e1d61ef1e282afa285e2d4ce45b7dbb223a67cae92a657', 'VENDEDOR');
INSERT INTO usuario (id_usuario, username, password_hash, rol) VALUES (4, 'Ciro', 'scrypt:32768:8:1$uuGLh4tRQNsW3Kh1$a4b2233e110452809309444d65695ab154383f441f570848e9b2229ab771c7ec44254c27c3d20b5e4ebc5a9ade44a20ad1b73d06da8a18cc14d0395b46052ee7', 'ADMINISTRADOR');
INSERT INTO usuario (id_usuario, username, password_hash, rol) VALUES (5, 'Carlos', 'scrypt:32768:8:1$RY3rOftIOMHho75T$5ff934e5260050ba1587489d23b5d242070d702d9735cd3f87d6881b089345706e66f771ef5e3590d6449a878f3deb51b9a82ba77389c28c10dcf2059b0b0c4d', 'VENDEDOR');
INSERT INTO usuario (id_usuario, username, password_hash, rol) VALUES (6, 'Mario', 'scrypt:32768:8:1$wwMjKVxaoNgczI50$1b7eba9826a692b5e1aaed1e83fd95664f2ac6c94683d9cbe1bb2cfa0c1096c56b9c353b0c1247eddbf11d5fa9eab6efbaacd0c7f54a8dacacacec6252f1c97b', 'VENDEDOR');
INSERT INTO usuario (id_usuario, username, password_hash, rol) VALUES (7, 'Pedro', 'scrypt:32768:8:1$WTkMC8PQVUtoMaKu$da57c0f791a5763fc580f4e21039667ca6631a72173386c4e13dc8cfe03d6c08ac149d64af50a6aae72fd75f49d40f5774f230a88364a6535ff4da2ee8061f28', 'VENDEDOR');

-- 5.2 Categorias de la licorera (las 4 primeras con productos migrados; el resto quedan listas)
INSERT INTO categoria (id_categoria, nombre, descripcion) VALUES (1, 'Cervezas', 'Cervezas nacionales e importadas, en lata y botella.');
INSERT INTO categoria (id_categoria, nombre, descripcion) VALUES (2, 'Rones', 'Rones y rones añejos.');
INSERT INTO categoria (id_categoria, nombre, descripcion) VALUES (3, 'Aguardientes', 'Aguardientes tradicionales.');
INSERT INTO categoria (id_categoria, nombre, descripcion) VALUES (4, 'Whisky', 'Whisky escocés, americano y otros.');
INSERT INTO categoria (id_categoria, nombre, descripcion) VALUES (5, 'Vinos', 'Vinos tintos, blancos, rosados y espumosos.');
INSERT INTO categoria (id_categoria, nombre, descripcion) VALUES (6, 'Otros licores', 'Vodka, tequila, ginebra, cremas y demás licores.');
INSERT INTO categoria (id_categoria, nombre, descripcion) VALUES (7, 'Bebidas sin alcohol', 'Gaseosas, jugos y agua para acompañar o mezclar.');
INSERT INTO categoria (id_categoria, nombre, descripcion) VALUES (8, 'Snacks y picadas', 'Maní, embutidos y otros productos para picar.');

-- 5.3 Proveedores (solo los que surten los productos migrados; conservan su id original)
INSERT INTO proveedor (id_proveedor, nit, nombre, telefono, direccion) VALUES (3, '830001000', 'Insumos de Panadería y Dulces', '602222111', 'Avenida 6N # 15-70, Cali');
INSERT INTO proveedor (id_proveedor, nit, nombre, telefono, direccion) VALUES (5, '860999000', 'Distribuidora de Bebidas Refrescantes', '605512456', 'Vía 40 # 75-80, Barranquilla');
INSERT INTO proveedor (id_proveedor, nit, nombre, telefono, direccion) VALUES (6, '890200300', 'Aguardientes y Licores de Colombia', '606678902', 'Zona Industrial Kilómetro 5, Manizales');
INSERT INTO proveedor (id_proveedor, nit, nombre, telefono, direccion) VALUES (10, '840700800', 'Carnes Frías y Embutidos SAS', '315456890', 'Carrera 30 # 45-90, Cali');

-- 5.4 Productos (de la tienda solo pasan bebidas y picadas; conservan su id original)
INSERT INTO producto (id_producto, id_categoria, id_proveedor, nombre, descripcion, es_alcoholico, precio_venta, stock_actual, imagen) VALUES (19, 7, 5, 'Jugo Hit de Naranja 1 Litro', 'Bebida de jugo de naranja pasteurizado, envase tetrapack.', 'N', 4800, 310, 'jugo.jpeg');
INSERT INTO producto (id_producto, id_categoria, id_proveedor, nombre, descripcion, es_alcoholico, precio_venta, stock_actual, imagen) VALUES (20, 7, 5, 'Gaseosa Coca Cola 2.5 Litros', 'Bebida carbonatada refrescante, familiar.', 'N', 7800, 160, 'gaseosa.png');
INSERT INTO producto (id_producto, id_categoria, id_proveedor, nombre, descripcion, es_alcoholico, precio_venta, stock_actual, imagen) VALUES (26, 8, 3, 'Maní Tostado Salado 100g', 'Maní tostado y salado, ideal para picar.', 'N', 3800, 270, 'mani.jpg');
INSERT INTO producto (id_producto, id_categoria, id_proveedor, nombre, descripcion, es_alcoholico, precio_venta, stock_actual, imagen) VALUES (32, 7, 5, 'Agua Embotellada sin gas 600ml', 'Botella de agua potable purificada, personal.', 'N', 1500, 600, 'Agua-Cristal-sin-gas-600-ML-1.jpg');
INSERT INTO producto (id_producto, id_categoria, id_proveedor, nombre, descripcion, es_alcoholico, precio_venta, stock_actual, imagen) VALUES (33, 1, 6, 'Cerveza Águila Lata (unidad)', 'Cerveza tipo Lager, refrescante (venta regulada).', 'S', 3500, 300, 'cerveza.jpeg');
INSERT INTO producto (id_producto, id_categoria, id_proveedor, nombre, descripcion, es_alcoholico, precio_venta, stock_actual, imagen) VALUES (34, 2, 6, 'Ron Viejo de Caldas 750ml', 'Ron añejo tradicional de Colombia (venta regulada).', 'S', 68000, 40, 'ron.jpg');
INSERT INTO producto (id_producto, id_categoria, id_proveedor, nombre, descripcion, es_alcoholico, precio_venta, stock_actual, imagen) VALUES (48, 8, 10, 'Salchichón Cervecero 250g', 'Embutido curado, ideal para picadas y sándwiches.', 'N', 6000, 180, 'salchichon.png');

-- 5.5 Clientes (id nuevo; el documento pasa a tipo_documento + numero_documento)
--     NOTA: el archivo original llegaba cortado en el cliente 5. Del 5 (apellido,
--     email, telefono) al 10 son datos de ejemplo: reemplazalos por los de TiendaBD si los tienes.
INSERT INTO cliente (id_cliente, tipo_documento, numero_documento, nombre, apellido, email, telefono) VALUES (1, 'PA', '2034567', 'Pedro José', 'Silva Nunes', 'pedro.silva@mail.com', '305222901');
INSERT INTO cliente (id_cliente, tipo_documento, numero_documento, nombre, apellido, email, telefono) VALUES (2, 'CC', '41234567', 'Marta Liliana', 'Quiroga Niño', 'marta.quiroga@mail.com', '318332109');
INSERT INTO cliente (id_cliente, tipo_documento, numero_documento, nombre, apellido, email, telefono) VALUES (3, 'CC', '52030405', 'Laura Sofía', 'Ramírez Castro', 'laura.ramirez@mail.com', '300779012');
INSERT INTO cliente (id_cliente, tipo_documento, numero_documento, nombre, apellido, email, telefono) VALUES (4, 'CC', '60987654', 'Adriana Paola', 'Bermúdez Soto', 'adriana.b@mail.com', '312114567');
INSERT INTO cliente (id_cliente, tipo_documento, numero_documento, nombre, apellido, email, telefono) VALUES (5, 'CC', '98010203', 'Jorge Enrique', 'Peña Rojas', 'jorge.pena@mail.com', '310445678');
INSERT INTO cliente (id_cliente, tipo_documento, numero_documento, nombre, apellido, email, telefono) VALUES (6, 'CC', '1090456789', 'Andrés Felipe', 'Gómez Ortiz', 'andres.gomez@mail.com', '316223344');
INSERT INTO cliente (id_cliente, tipo_documento, numero_documento, nombre, apellido, email, telefono) VALUES (7, 'CC', '37456123', 'Diana Carolina', 'Vargas Mora', 'diana.vargas@mail.com', '311556677');
INSERT INTO cliente (id_cliente, tipo_documento, numero_documento, nombre, apellido, email, telefono) VALUES (8, 'CE', '845123', 'Luis Alberto', 'Mendoza Pérez', 'luis.mendoza@mail.com', '304889900');
INSERT INTO cliente (id_cliente, tipo_documento, numero_documento, nombre, apellido, email, telefono) VALUES (9, 'CC', '88234567', 'Camilo Andrés', 'Torres Duarte', 'camilo.torres@mail.com', '317112233');
INSERT INTO cliente (id_cliente, tipo_documento, numero_documento, nombre, apellido, email, telefono) VALUES (10, 'NIT', '900123456', 'Eventos La Frontera SAS', NULL, 'contacto@lafrontera.com', '6075712345');

COMMIT;

-- ---------------------------------------------------------------------
-- 6. VERIFICACION
-- ---------------------------------------------------------------------
SELECT 'usuario' AS tabla, COUNT(*) AS filas FROM usuario UNION ALL
SELECT 'categoria', COUNT(*) FROM categoria UNION ALL
SELECT 'proveedor', COUNT(*) FROM proveedor UNION ALL
SELECT 'producto',  COUNT(*) FROM producto UNION ALL
SELECT 'cliente',   COUNT(*) FROM cliente;
