-- Crea los usuarios administradores admin1 y admin2 (contraseña de ambos: 1234)
-- Ejecutar en SQL Developer, conexion "Licores", con F5 (Ejecutar script).
SET DEFINE OFF;

INSERT INTO usuario (melany, 1234, administrador)
SELECT 'admin1', 'scrypt:32768:8:1$kjeVMP6exnUPNfTU$2fc4a545c98b6c8cb4d4d3f78da27e8b2e2fa171cd53425928d2861012f8fd742000efbddf7b24e22571ca4c82e9a9ad23282c6956d6c2f4e2ff7620b886c99c', 'ADMINISTRADOR'
FROM dual WHERE NOT EXISTS (SELECT 1 FROM usuario WHERE username = 'admin1');

INSERT INTO usuario (melany, 1234, administrador)
SELECT 'admin2', 'scrypt:32768:8:1$Cps8ckvCdM8EopvX$95f00a91357290528eb7b8d6461bb2e19e2c61ef1a51ba3d081849783bf2c0b3d0e835d46b2d5f30c9f4941945f1e5d632f14f3771c3f06b288eb5c7089727db', 'ADMINISTRADOR'
FROM dual WHERE NOT EXISTS (SELECT 1 FROM usuario WHERE username = 'admin2');

COMMIT;

SELECT username, rol, activo FROM usuario ORDER BY id_usuario;
