-- =====================================================================
-- LicorStock - Agrega 30 rones (con foto)
-- Esquema: LICOLERIA (Oracle 10g XE). En SQL Developer: F5.
-- Las fotos van en codigo\app\static\img\productos\ (archivos ron-*.jpg,
-- copia en fotos_rones.zip).
-- Usa la categoria "Rones" (o "Ron"); si no existe, crea "Rones".
-- Precio = precio actual de la captura (si tenia descuento, el precio rebajado).
-- Solo INSERTA. No borra nada. Se puede correr varias veces:
-- si un producto con el mismo nombre ya existe, solo le pone la foto y lo activa.
-- =====================================================================
SET SERVEROUTPUT ON
SET DEFINE OFF

DECLARE
  v_ins NUMBER := 0; v_act NUMBER := 0; v_cat NUMBER; v_prov NUMBER;

  PROCEDURE a(p_nombre VARCHAR2, p_precio NUMBER, p_grado NUMBER, p_imagen VARCHAR2) IS
    v_id NUMBER; v_n NUMBER; v_stock NUMBER;
  BEGIN
    SELECT MIN(id_producto) INTO v_id FROM producto WHERE UPPER(nombre) = UPPER(p_nombre);
    IF v_id IS NOT NULL THEN
      UPDATE producto SET imagen = p_imagen, activo = 'S' WHERE id_producto = v_id;
      v_act := v_act + 1; RETURN;
    END IF;
    v_stock := CASE WHEN p_precio >= 1000000 THEN 1
                    WHEN p_precio >= 300000  THEN 6
                    WHEN p_precio >= 150000  THEN 12
                    WHEN p_precio >= 80000   THEN 18
                    ELSE 30 END;
    LOOP
      SELECT seq_producto.NEXTVAL INTO v_id FROM dual;
      SELECT COUNT(*) INTO v_n FROM producto WHERE id_producto = v_id;
      EXIT WHEN v_n = 0;
    END LOOP;
    INSERT INTO producto (id_producto, id_categoria, id_proveedor, nombre, descripcion, es_alcoholico,
                          grado_alcohol, precio_venta, stock_actual, stock_minimo, imagen, activo)
    VALUES (v_id, v_cat, v_prov, p_nombre, 'Ron. Venta prohibida a menores de edad.', 'S',
            p_grado, p_precio, v_stock, GREATEST(1, TRUNC(v_stock/5)), p_imagen, 'S');
    v_ins := v_ins + 1;
  END;

BEGIN
  SELECT MIN(id_categoria) INTO v_cat FROM categoria
   WHERE UPPER(nombre) IN ('RONES', 'RON');
  IF v_cat IS NULL THEN
    SELECT seq_categoria.NEXTVAL INTO v_cat FROM dual;
    INSERT INTO categoria (id_categoria, nombre, descripcion)
    VALUES (v_cat, 'Rones', 'Rones blancos, anejos y premium.');
  END IF;
  SELECT MIN(id_proveedor) INTO v_prov FROM proveedor WHERE nit = '890200300';

  -- Captura 1
  a('Botran 18 años Solera x 750ml', 207990, 40, 'ron-botran-18-anos-solera-x-750ml.jpg');
  a('Botran 15 años Reserva x 750ml', 159900, 40, 'ron-botran-15-anos-reserva-x-750ml.jpg');
  a('La Hechicera x 700ml', 199990, 40, 'ron-la-hechicera-x-700ml.jpg');                        -- antes 229.990
  a('Viejo de Caldas Roble Blanco x 750ml', 46990, 35, 'ron-viejo-de-caldas-roble-blanco-x-750ml.jpg');
  a('Blanco Monte Manglar x 700ml + Vaso de la Marca', 159900, 40, 'ron-blanco-monte-manglar-x-700ml-vaso.jpg');
  a('Cienaga del Viento Añejo + Tote Bag', 148900, 40, 'ron-cienaga-del-viento-anejo-tote-bag.jpg');
  a('Naciente Blanco x 750ml + Copa de la Marca', 94470, 40, 'ron-naciente-blanco-x-750ml-copa.jpg');
  a('Ron Añejo Angostura Premium 1824 750ml', 350900, 40, 'ron-angostura-1824-x-750ml.jpg');
  a('Ron Añejo Angostura Premium 1919 750ml', 241900, 40, 'ron-angostura-1919-x-750ml.jpg');
  a('Ron Añejo Botran Oro 5 x 750ml', 99990, 40, 'ron-botran-oro-5-x-750ml.jpg');
  -- Captura 2
  a('Dictador Generations en LALIQUE', 99900000, 40, 'ron-dictador-generations-lalique.jpg'); -- precio tal cual la captura
  a('Ron La Hechicera Banano x 700ml + Serie experimental N.2', 308990, 40, 'ron-la-hechicera-banano-x-700ml-serie-experimental.jpg'); -- antes 334.990
  a('Ron Zacapa 23 Solera x 700ml', 303990, 40, 'ron-zacapa-23-solera-x-700ml.jpg');
  a('Abuelo Añejo Reserva Especial x 750ml', 74990, 40, 'ron-abuelo-anejo-reserva-especial-x-750ml.jpg');
  a('Parce 12 años x 750ml', 319990, 40, 'ron-parce-12-anos-x-750ml.jpg');
  a('Parce 8 años x 750ml + Gratis Gorra', 239990, 40, 'ron-parce-8-anos-x-750ml-gorra.jpg');
  a('Parce Brothers x 750ml + Gratis Camiseta', 137990, 40, 'ron-parce-brothers-x-750ml-camiseta.jpg');
  a('Ron Flor de Caña 12 años x 750ml', 149990, 40, 'ron-flor-de-cana-12-anos-x-750ml.jpg');
  a('Havana Club 3 años x 700ml', 69900, 40, 'ron-havana-club-3-anos-x-700ml.jpg');
  a('Havana Selección de Maestros x 750ml', 255900, 45, 'ron-havana-seleccion-de-maestros-x-750ml.jpg');
  -- Captura 3
  a('Ron Defensor Style 12 años x 700ml', 264900, 40, 'ron-defensor-style-12-anos-x-700ml.jpg');
  a('Ron Havana Añejo Especial x 700ml', 80900, 40, 'ron-havana-anejo-especial-x-700ml.jpg');
  a('Ron Havana Club 7 años x 700ml', 114900, 40, 'ron-havana-club-7-anos-x-700ml.jpg');
  a('Ron Flor de Caña 18 años x 750ml Gratis 2 Copas Premium', 272990, 40, 'ron-flor-de-cana-18-anos-x-750ml-copas.jpg');
  a('Ron Flor de Caña 25 años x 750ml', 899990, 40, 'ron-flor-de-cana-25-anos-x-750ml.jpg');
  a('Ron Flor de Caña Gran Reserva 7 años x 750ml', 98600, 40, 'ron-flor-de-cana-gran-reserva-7-anos-x-750ml.jpg');
  a('Ron Viejo de Caldas Tetrapack x 1000ml', 64900, 35, 'ron-viejo-de-caldas-tetrapack-x-1000ml.jpg');
  a('Ron Viejo de Caldas x 1000ml + Coca Cola 1.5 L', 72990, 35, 'ron-viejo-de-caldas-x-1000ml-coca-cola.jpg'); -- antes 76.990
  a('Viejo De Caldas 15 Años x 750ml', 172900, 35, 'ron-viejo-de-caldas-15-anos-x-750ml.jpg');
  a('Viejo de Caldas 8 años Carta de Oro x 750ml', 109990, 35, 'ron-viejo-de-caldas-8-anos-carta-de-oro-x-750ml.jpg');

  COMMIT;
  DBMS_OUTPUT.PUT_LINE('Rones insertados: ' || v_ins || ' | ya existian (foto actualizada): ' || v_act);
END;
/

SELECT c.nombre AS categoria, COUNT(p.id_producto) AS activos
  FROM categoria c LEFT JOIN producto p ON p.id_categoria = c.id_categoria AND p.activo = 'S'
 GROUP BY c.nombre ORDER BY c.nombre;
