import os

from dotenv import load_dotenv

load_dotenv()


class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-inseguro")
    ORACLE_USER = os.getenv("ORACLE_USER", "tienda_virtual")
    ORACLE_PASSWORD = os.getenv("ORACLE_PASSWORD", "")
    ORACLE_DSN = os.getenv("ORACLE_DSN", "localhost:1521/XEPDB1")
    # Solo para Oracle 10g/11g: ruta del Instant Client (activa el modo Thick)
    ORACLE_CLIENT_LIB = os.getenv("ORACLE_CLIENT_LIB") or None
    # Alternativa para Oracle 10g sin Instant Client: controlador JDBC + Java (JPype)
    ORACLE_JDBC_JAR = os.getenv("ORACLE_JDBC_JAR") or None
    JAVA_JVM_DLL = os.getenv("JAVA_JVM_DLL") or None
    EDAD_MINIMA = int(os.getenv("EDAD_MINIMA", "18"))
    MAX_CONTENT_LENGTH = 5 * 1024 * 1024  # fotos de producto de máximo 5 MB
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
