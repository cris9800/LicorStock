from datetime import date, datetime, timedelta

from flask import Blueprint, render_template, request

from .. import db
from ..auth.decorators import rol_requerido

bp = Blueprint("caja", __name__)


def leer_dia(texto):
    try:
        return datetime.strptime(texto, "%Y-%m-%d").date()
    except (TypeError, ValueError):
        return date.today()


@bp.route("/")
@rol_requerido("VENDEDOR")
def diaria():
    """Cierre de caja: lo cobrado en el día (pagos PAGADO), por método y por vendedor.

    Un pago contra entrega cuenta el día en que el repartidor lo cobra.
    """
    dia = leer_dia(request.args.get("dia"))
    rango = {"desde": datetime.combine(dia, datetime.min.time()),
             "hasta": datetime.combine(dia + timedelta(days=1), datetime.min.time())}
    filtro = "p.estado = 'PAGADO' AND p.fecha >= :desde AND p.fecha < :hasta"
    por_metodo = db.query(
        f"SELECT p.metodo, COUNT(*) AS num, SUM(p.valor) AS total FROM pago p "
        f"WHERE {filtro} GROUP BY p.metodo ORDER BY total DESC", rango)
    por_vendedor = db.query(
        f"SELECT u.username AS vendedor, COUNT(*) AS num, SUM(p.valor) AS total FROM pago p "
        f"JOIN venta v ON v.id_venta = p.id_venta JOIN usuario u ON u.id_usuario = v.id_usuario "
        f"WHERE {filtro} GROUP BY u.username ORDER BY total DESC", rango)
    pagos = db.query(
        f"SELECT p.*, v.tipo_venta, u.username AS vendedor, "
        f"TRIM(c.nombre || ' ' || c.apellido) AS cliente FROM pago p "
        f"JOIN venta v ON v.id_venta = p.id_venta JOIN usuario u ON u.id_usuario = v.id_usuario "
        f"LEFT JOIN cliente c ON c.id_cliente = v.id_cliente "
        f"WHERE {filtro} ORDER BY p.fecha DESC", rango)
    pendientes = db.query(
        "SELECT COUNT(*) AS num, NVL(SUM(valor), 0) AS total FROM pago WHERE estado = 'PENDIENTE'",
        one=True)
    anuladas = db.query(
        "SELECT COUNT(*) AS num, NVL(SUM(total), 0) AS total FROM venta "
        "WHERE estado = 'ANULADA' AND fecha >= :desde AND fecha < :hasta", rango, one=True)
    total = sum(m["total"] for m in por_metodo)
    efectivo = sum(m["total"] for m in por_metodo if m["metodo"] == "EFECTIVO")
    return render_template("caja/diaria.html", dia=dia, hoy=date.today(), timedelta=timedelta,
                           por_metodo=por_metodo, por_vendedor=por_vendedor, pagos=pagos,
                           pendientes=pendientes, anuladas=anuladas, total=total,
                           efectivo=efectivo)
