@echo off
cd /d "%~dp0"
title LicorStock - celulares
"venv\Scripts\python.exe" run_movil.py
pause
