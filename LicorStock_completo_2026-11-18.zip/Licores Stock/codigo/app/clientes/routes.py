from datetime import datetime

import oracledb
from flask import Blueprint, flash, redirect, render_template, request, url_for

from .. import db
from ..auth.decorators import rol_requerido

bp = Blueprint("clientes", __name__)

TIPOS_DOCUMENTO = ("CC", "CE", "PA", "NIT")
CAMPOS = ("tipo_documento", "numero_documento", "nombre", "apellido", "email",
          "telefono", "direccion")


def _leer_formulario():
    datos = {c: (request.form.get(c) or "").strip() or None for c in CAMPOS}
    errores = []
    if datos["tipo_documento"] not in TIPOS_DOCUMENTO:
        errores.append("Selecciona un tipo de documento válido.")
    if not datos["numero_documento"]:
        errores.append("El número de documento es obligatorio.")
    if not datos["nombre"]:
        errores.append("El nombre es obligatorio.")
    if datos["email"] and "@" not in datos["email"]:
        errores.append("El correo no es válido.")
    nacimiento = request.form.get("fecha_nacimiento") or None
    datos["fecha_nacimiento"] = None
    if nacimiento:
        try:
            datos["fecha_nacimiento"] = datetime.strptime(nacimiento, "%Y-%m-%d")
        except ValueError:
            errores.append("La fecha de nacimiento no es válida.")
        else:
            if datos["fecha_nacimiento"] > datetime.now():
                errores.append("La fecha de nacimiento no puede ser futura.")
    return datos, errores


@bp.route("/")
@rol_requerido("VENDEDOR")
def lista():
    buscar = request.args.get("q", "").strip()
    clientes = db.query(
        "SELECT c.*, (SELECT COUNT(*) FROM venta v WHERE v.id_cliente = c.id_cliente) "
        "AS num_compras FROM cliente c "
        "WHERE (:q IS NULL OR UPPER(c.nombre || ' ' || c.apellido) LIKE '%' || UPPER(:q) || '%' "
        "OR c.numero_documento LIKE '%' || :q || '%') "
        "ORDER BY c.activo DESC, c.nombre, c.apellido",
        {"q": buscar or None},
    )
    return render_template("clientes/lista.html", clientes=clientes, buscar=buscar)


@bp.route("/nuevo", methods=["GET", "POST"])
@rol_requerido("VENDEDOR")
def nuevo():
    datos = {"tipo_documento": "CC"}
    if request.method == "POST":
        datos, errores = _leer_formulario()
        if not errores:
            try:
                db.execute(
                    "INSERT INTO cliente (tipo_documento, numero_documento, nombre, apellido, "
                    "email, telefono, direccion, fecha_nacimiento) VALUES (:tipo_documento, "
                    ":numero_documento, :nombre, :apellido, :email, :telefono, :direccion, "
                    ":fecha_nacimiento)",
                    datos,
                )
                flash("Cliente registrado.", "success")
                return redirect(url_for("clientes.lista"))
            except oracledb.DatabaseError as exc:
                errores.append(db.error_oracle(exc))
        for e in errores:
            flash(e, "danger")
    return render_template("clientes/form.html", cliente=datos, tipos=TIPOS_DOCUMENTO)


@bp.route("/<int:id_cliente>/editar", methods=["GET", "POST"])
@rol_requerido("VENDEDOR")
def editar(id_cliente):
    cliente = db.query("SELECT * FROM cliente WHERE id_cliente = :id",
                       {"id": id_cliente}, one=True)
    if not cliente:
        flash("Cliente no encontrado.", "warning")
        return redirect(url_for("clientes.lista"))
    if request.method == "POST":
        datos, errores = _leer_formulario()
        if not errores:
            try:
                db.execute(
                    "UPDATE cliente SET tipo_documento = :tipo_documento, "
                    "numero_documento = :numero_documento, nombre = :nombre, "
                    "apellido = :apellido, email = :email, telefono = :telefono, "
                    "direccion = :direccion, fecha_nacimiento = :fecha_nacimiento "
                    "WHERE id_cliente = :id_cliente",
                    {**datos, "id_cliente": id_cliente},
                )
                flash("Cliente actualizado.", "success")
                return redirect(url_for("clientes.lista"))
            except oracledb.DatabaseError as exc:
                errores.append(db.error_oracle(exc))
        for e in errores:
            flash(e, "danger")
        cliente = {**cliente, **datos}
    return render_template("clientes/form.html", cliente=cliente, tipos=TIPOS_DOCUMENTO)


@bp.route("/<int:id_cliente>/estado", methods=["POST"])
@rol_requerido()
def cambiar_estado(id_cliente):
    db.execute(
        "UPDATE cliente SET activo = CASE activo WHEN 'S' THEN 'N' ELSE 'S' END "
        "WHERE id_cliente = :id", {"id": id_cliente},
    )
    flash("Estado del cliente actualizado.", "info")
    return redirect(url_for("clientes.lista"))
