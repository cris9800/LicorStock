"""Conexión a Oracle 10g por JDBC (el mismo controlador que usa SQL Developer).

python-oracledb ya no se conecta a Oracle 10g: el modo Thin pide 12c o superior
y el modo Thick pide Instant Client 11.2, que Oracle dejó de publicar. Este
módulo imita la parte de python-oracledb que usa la aplicación (pool, cursor,
binds con nombre, RETURNING ... INTO y DatabaseError) usando JPype + ojdbc.

Se activa poniendo ORACLE_JDBC_JAR (y opcionalmente JAVA_JVM_DLL) en .env.
"""
import datetime
import decimal
import re
import threading

import jpype
import oracledb

NUMBER = oracledb.NUMBER

_BIND = re.compile(r"'(?:[^']|'')*'|\"[^\"]*\"|--[^\n]*|/\*.*?\*/|:(\w+)", re.S)


class _Error:
    def __init__(self, code, message):
        self.code = code
        self.message = message
        self.full_code = f"ORA-{code:05d}"

    def __str__(self):
        return self.message


class DatabaseError(oracledb.DatabaseError):
    pass


def _wrap(exc):
    code = int(exc.getErrorCode()) if hasattr(exc, "getErrorCode") else 0
    message = str(exc.getMessage()) if hasattr(exc, "getMessage") else str(exc)
    return DatabaseError(_Error(code, message))


def start_jvm(jar, jvm_dll=None):
    if not jpype.isJVMStarted():
        jpype.startJVM(jvm_dll or jpype.getDefaultJVMPath(), classpath=[jar],
                       convertStrings=True)
    jpype.JClass("oracle.jdbc.OracleDriver")


class Var:
    """Equivalente a cursor.var(): recibe el valor de RETURNING ... INTO."""

    def __init__(self, typ):
        self.typ = typ
        self.value = None

    def getvalue(self):
        return [self.value]


def _parse(sql, params):
    """Convierte :nombre en ? y devuelve la lista ordenada de valores."""
    names = []

    def repl(m):
        if m.group(1) is None:
            return m.group(0)
        names.append(m.group(1))
        return "?"

    new_sql = _BIND.sub(repl, sql)
    if isinstance(params, dict):
        lower = {k.lower(): v for k, v in params.items()}
        values = [lower[n.lower()] for n in names]
    else:
        values = list(params or [])
    return new_sql, values


def _to_python(value):
    if value is None or isinstance(value, (str, int, float)):
        return value
    cls = str(value.getClass().getName())
    if cls == "java.math.BigDecimal":
        if value.scale() <= 0 or value.stripTrailingZeros().scale() <= 0:
            return int(str(value.toBigInteger()))
        return float(str(value))
    if cls in ("java.lang.Integer", "java.lang.Long", "java.lang.Short"):
        return int(value)
    if cls in ("java.lang.Double", "java.lang.Float"):
        return float(value)
    if cls in ("java.sql.Timestamp", "oracle.sql.TIMESTAMP", "oracle.sql.DATE", "java.sql.Date"):
        if cls.startswith("oracle.sql"):
            value = value.timestampValue()
        ts = value if cls != "java.sql.Date" else jpype.JClass("java.sql.Timestamp")(value.getTime())
        ldt = ts.toLocalDateTime()
        return datetime.datetime(ldt.getYear(), ldt.getMonthValue(), ldt.getDayOfMonth(),
                                 ldt.getHour(), ldt.getMinute(), ldt.getSecond(),
                                 ldt.getNano() // 1000)
    if cls == "oracle.sql.CLOB" or cls.endswith("OracleClob"):
        return str(value.getSubString(1, int(value.length())))
    return str(value) if cls == "java.lang.String" else value


def _bind(stmt, i, value):
    Types = jpype.JClass("java.sql.Types")
    if value is None:
        stmt.setNull(i, Types.VARCHAR)
    elif isinstance(value, bool):
        stmt.setInt(i, int(value))
    elif isinstance(value, int):
        stmt.setBigDecimal(i, jpype.JClass("java.math.BigDecimal")(str(value)))
    elif isinstance(value, (float, decimal.Decimal)):
        stmt.setBigDecimal(i, jpype.JClass("java.math.BigDecimal")(str(value)))
    elif isinstance(value, datetime.datetime):
        stmt.setTimestamp(i, jpype.JClass("java.sql.Timestamp").valueOf(
            value.strftime("%Y-%m-%d %H:%M:%S")))
    elif isinstance(value, datetime.date):
        stmt.setTimestamp(i, jpype.JClass("java.sql.Timestamp").valueOf(
            value.strftime("%Y-%m-%d 00:00:00")))
    else:
        stmt.setString(i, str(value))


class Cursor:
    def __init__(self, conn):
        self._conn = conn
        self._rows = []
        self._pos = 0
        self.description = None
        self.rowcount = 0
        self.rowfactory = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def close(self):
        self._rows = []

    def var(self, typ):
        return Var(typ)

    def execute(self, sql, params=None):
        sql, values = _parse(sql, params)
        self._rows, self._pos, self.description = [], 0, None
        try:
            if any(isinstance(v, Var) for v in values):
                self._execute_plsql(sql, values)
            else:
                self._execute_plain(sql, values)
        except jpype.JException as exc:
            raise _wrap(exc) from None

    def _execute_plain(self, sql, values):
        stmt = self._conn.prepareStatement(sql)
        try:
            for i, v in enumerate(values, 1):
                _bind(stmt, i, v)
            if stmt.execute():
                rs = stmt.getResultSet()
                meta = rs.getMetaData()
                n = meta.getColumnCount()
                self.description = [(str(meta.getColumnLabel(i)).upper(), None, None,
                                      None, None, None, None) for i in range(1, n + 1)]
                while rs.next():
                    self._rows.append(tuple(_to_python(rs.getObject(i)) for i in range(1, n + 1)))
                rs.close()
                self.rowcount = len(self._rows)
            else:
                self.rowcount = int(stmt.getUpdateCount())
        finally:
            stmt.close()

    def _execute_plsql(self, sql, values):
        """DML con RETURNING ... INTO: se ejecuta en un bloque PL/SQL."""
        Types = jpype.JClass("java.sql.Types")
        stmt = self._conn.prepareCall(f"BEGIN {sql}; ? := SQL%ROWCOUNT; END;")
        try:
            for i, v in enumerate(values, 1):
                if isinstance(v, Var):
                    stmt.registerOutParameter(i, Types.NUMERIC if v.typ is NUMBER else Types.VARCHAR)
                else:
                    _bind(stmt, i, v)
            count_idx = len(values) + 1
            stmt.registerOutParameter(count_idx, Types.NUMERIC)
            stmt.execute()
            for i, v in enumerate(values, 1):
                if isinstance(v, Var):
                    v.value = _to_python(stmt.getObject(i))
            self.rowcount = int(stmt.getInt(count_idx))
        finally:
            stmt.close()

    def _make(self, row):
        return self.rowfactory(*row) if self.rowfactory else row

    def fetchone(self):
        if self._pos >= len(self._rows):
            return None
        row = self._rows[self._pos]
        self._pos += 1
        return self._make(row)

    def fetchall(self):
        rows = [self._make(r) for r in self._rows[self._pos:]]
        self._pos = len(self._rows)
        return rows

    def __iter__(self):
        while (row := self.fetchone()) is not None:
            yield row


class Connection:
    def __init__(self, jconn):
        self._jconn = jconn

    def cursor(self):
        return Cursor(self._jconn)

    def commit(self):
        try:
            self._jconn.commit()
        except jpype.JException as exc:
            raise _wrap(exc) from None

    def rollback(self):
        try:
            self._jconn.rollback()
        except jpype.JException as exc:
            raise _wrap(exc) from None


class Pool:
    def __init__(self, user, password, url, min=1, max=5):
        self._args = (url, user, password)
        self._idle = []
        self._lock = threading.Lock()
        for _ in range(min):
            self._idle.append(self._new())

    def _new(self):
        DriverManager = jpype.JClass("java.sql.DriverManager")
        try:
            jconn = DriverManager.getConnection(*self._args)
        except jpype.JException as exc:
            raise _wrap(exc) from None
        jconn.setAutoCommit(False)
        return Connection(jconn)

    def acquire(self):
        with self._lock:
            conn = self._idle.pop() if self._idle else None
        if conn is not None and not conn._jconn.isValid(2):
            conn = None
        return conn or self._new()

    def release(self, conn):
        try:
            conn.rollback()
        except DatabaseError:
            return
        with self._lock:
            self._idle.append(conn)


def create_pool(user, password, dsn, jar, jvm_dll=None, min=1, max=5):
    """dsn: host:puerto/servicio o host:puerto:SID (como en SQL Developer)."""
    start_jvm(jar, jvm_dll)
    url = dsn if dsn.startswith("jdbc:") else (
        f"jdbc:oracle:thin:@//{dsn}" if "/" in dsn else f"jdbc:oracle:thin:@{dsn}")
    return Pool(user, password, url, min=min, max=max)
