import secrets
from datetime import date
from functools import wraps

import oracledb
from flask import (Blueprint, current_app, flash, jsonify, redirect, render_template,
                   request, session, url_for)
from werkzeug.security import generate_password_hash

from .. import db
from ..ventas.routes import calcular_edad

bp = Blueprint("tienda", __name__)

# Métodos que el cliente puede elegir en la tienda. Todos se cobran al entregar
# (contra entrega): el pago queda PENDIENTE y pasa a PAGADO cuando el repartidor
# marca el domicilio como ENTREGADO (ver domicilios.avanzar).
# NEQUI y DAVIPLATA no se incluyen porque la restricción ck_pago_metodo de la base
# instalada (script antiguo) solo acepta estos tres.
METODOS_TIENDA = ("EFECTIVO", "TRANSFERENCIA", "TARJETA")
TIPOS_DOCUMENTO = ("CC", "CE", "PA")
# Usuario del sistema al que quedan asociadas las ventas hechas desde la tienda
# (venta.id_usuario es obligatorio). Se crea inactivo: nadie puede iniciar sesión con él.
USUARIO_TIENDA = "tienda_web"
MAX_UNIDADES = 99


def cliente_requerido(vista):
    """Solo clientes que confirmaron su mayoría de edad en el login."""
    @wraps(vista)
    def envoltura(*args, **kwargs):
        if not session.get("cliente"):
            flash("Confirma que eres mayor de edad para ver el catálogo.", "warning")
            return redirect(url_for("auth.login"))
        return vista(*args, **kwargs)
    return envoltura


# --------------------------------------------------------------------- Carrito
def _carrito():
    """{id_producto (str): cantidad} guardado en la sesión del cliente."""
    return session.setdefault("carrito", {})


def _guardar_carrito(carrito):
    session["carrito"] = {k: v for k, v in carrito.items() if v > 0}
    session.modified = True


@bp.app_template_global()
def unidades_carrito():
    return sum(session.get("carrito", {}).values())


def _lineas_carrito():
    """Productos del carrito con precio y stock actuales de la base de datos."""
    carrito = _carrito()
    if not carrito:
        return [], 0
    ids = [int(i) for i in carrito]
    marcas = ", ".join(f":p{n}" for n in range(len(ids)))
    productos = db.query(
        "SELECT p.id_producto, p.nombre, p.precio_venta, p.stock_actual, p.es_alcoholico, "
        "p.imagen, c.nombre AS categoria FROM producto p "
        "JOIN categoria c ON c.id_categoria = p.id_categoria "
        f"WHERE p.activo = 'S' AND p.id_producto IN ({marcas})",
        {f"p{n}": i for n, i in enumerate(ids)},
    )
    lineas, total = [], 0
    for p in sorted(productos, key=lambda x: x["nombre"]):
        p["cantidad"] = carrito[str(p["id_producto"])]
        p["subtotal"] = p["cantidad"] * p["precio_venta"]
        p["sin_stock"] = p["cantidad"] > p["stock_actual"]
        total += p["subtotal"]
        lineas.append(p)
    # Productos que se desactivaron o borraron mientras estaban en el carrito
    vigentes = {str(p["id_producto"]) for p in productos}
    if vigentes != set(carrito):
        _guardar_carrito({k: v for k, v in carrito.items() if k in vigentes})
    return lineas, total


@bp.route("/")
@cliente_requerido
def catalogo():
    buscar = request.args.get("q", "").strip()
    productos = db.query(
        "SELECT p.id_producto, p.nombre, p.descripcion, p.precio_venta, p.stock_actual, "
        "p.es_alcoholico, p.grado_alcohol, p.imagen, c.nombre AS categoria "
        "FROM producto p JOIN categoria c ON c.id_categoria = p.id_categoria "
        "WHERE p.activo = 'S' AND (:q IS NULL OR UPPER(p.nombre) LIKE '%' || UPPER(:q) || '%') "
        "ORDER BY c.nombre, p.nombre",
        {"q": buscar or None},
    )
    return render_template("tienda/catalogo.html", productos=productos, buscar=buscar,
                           carrito=_carrito())


@bp.route("/carrito/agregar", methods=["POST"])
@cliente_requerido
def agregar():
    """Suma unidades de un producto. Responde JSON si se llama desde el catálogo con fetch."""
    es_ajax = request.headers.get("X-Requested-With") == "fetch"
    id_producto = request.form.get("id_producto", type=int)
    cantidad = max(1, request.form.get("cantidad", 1, type=int) or 1)
    p = id_producto and db.query(
        "SELECT id_producto, nombre, stock_actual FROM producto "
        "WHERE id_producto = :id AND activo = 'S'", {"id": id_producto}, one=True)
    carrito = _carrito()
    if not p:
        ok, mensaje = False, "Ese producto ya no está disponible."
    else:
        actual = carrito.get(str(id_producto), 0)
        nueva = min(actual + cantidad, p["stock_actual"], MAX_UNIDADES)
        if nueva <= actual:
            ok, mensaje = False, f"No hay más unidades disponibles de {p['nombre']}."
        else:
            carrito[str(id_producto)] = nueva
            _guardar_carrito(carrito)
            ok, mensaje = True, f"{p['nombre']} agregado al carrito."
    if es_ajax:
        return jsonify(ok=ok, mensaje=mensaje, unidades=unidades_carrito(),
                       en_carrito=_carrito().get(str(id_producto), 0))
    flash(mensaje, "success" if ok else "warning")
    return redirect(request.referrer or url_for("tienda.catalogo"))


@bp.route("/carrito", methods=["GET", "POST"])
@cliente_requerido
def carrito():
    if request.method == "POST":
        carrito = _carrito()
        quitar = request.form.get("quitar")
        if quitar:
            carrito.pop(quitar, None)
        elif request.form.get("vaciar"):
            carrito = {}
        else:
            for clave in list(carrito):
                valor = request.form.get(f"cant_{clave}", type=int)
                if valor is not None:
                    carrito[clave] = max(0, min(valor, MAX_UNIDADES))
        _guardar_carrito(carrito)
        if request.form.get("seguir") == "checkout":
            return redirect(url_for("tienda.checkout"))
        return redirect(url_for("tienda.carrito"))
    lineas, total = _lineas_carrito()
    return render_template("tienda/carrito.html", lineas=lineas, total=total)


# -------------------------------------------------------------------- Checkout
@bp.route("/checkout", methods=["GET", "POST"])
@cliente_requerido
def checkout():
    lineas, total = _lineas_carrito()
    if not lineas:
        flash("Tu carrito está vacío.", "warning")
        return redirect(url_for("tienda.catalogo"))
    datos = request.form if request.method == "POST" else session.get("datos_cliente", {})
    if request.method == "POST":
        try:
            id_venta = _registrar_pedido(request.form)
            session["mis_pedidos"] = session.get("mis_pedidos", []) + [id_venta]
            session["datos_cliente"] = {k: request.form.get(k, "") for k in (
                "tipo_documento", "numero_documento", "nombre", "apellido", "telefono",
                "email", "direccion", "fecha_nacimiento")}
            _guardar_carrito({})
            return redirect(url_for("tienda.pedido", id_venta=id_venta))
        except ValueError as exc:
            flash(str(exc), "danger")
        except oracledb.DatabaseError as exc:
            flash(db.error_oracle(exc), "danger")
        lineas, total = _lineas_carrito()
    hoy = date.today()
    edad = current_app.config["EDAD_MINIMA"]
    try:
        limite = hoy.replace(year=hoy.year - edad)
    except ValueError:  # 29 de febrero
        limite = hoy.replace(year=hoy.year - edad, day=28)
    return render_template("tienda/checkout.html", lineas=lineas, total=total, datos=datos,
                           metodos=METODOS_TIENDA, tipos=TIPOS_DOCUMENTO,
                           hoy_menos_18=limite.isoformat())


def _texto(form, campo, maximo, obligatorio=False, etiqueta=None):
    valor = (form.get(campo) or "").strip()
    if obligatorio and not valor:
        raise ValueError(f"Falta {etiqueta or campo}.")
    return valor[:maximo] or None


def _leer_datos(form):
    tipo = form.get("tipo_documento")
    if tipo not in TIPOS_DOCUMENTO:
        raise ValueError("Selecciona un tipo de documento válido.")
    d = {
        "tipo": tipo,
        "numero": _texto(form, "numero_documento", 20, True, "el número de documento"),
        "nombre": _texto(form, "nombre", 80, True, "tu nombre"),
        "apellido": _texto(form, "apellido", 80),
        "telefono": _texto(form, "telefono", 20, True, "un teléfono de contacto"),
        "email": _texto(form, "email", 100),
        "direccion": _texto(form, "direccion", 150, True, "la dirección de entrega"),
        "observaciones": _texto(form, "observaciones", 250),
    }
    if not d["numero"].replace("-", "").isalnum():
        raise ValueError("El número de documento solo puede tener letras y números.")
    try:
        d["nacimiento"] = date.fromisoformat(form.get("fecha_nacimiento", ""))
    except ValueError:
        raise ValueError("Escribe tu fecha de nacimiento.") from None
    if d["nacimiento"] > date.today() or d["nacimiento"].year < 1900:
        raise ValueError("La fecha de nacimiento no es válida.")
    metodo = form.get("metodo_pago")
    if metodo not in METODOS_TIENDA:
        raise ValueError("Selecciona un método de pago.")
    d["metodo"] = metodo
    return d


def _usuario_tienda(cur):
    cur.execute("SELECT id_usuario FROM usuario WHERE username = :u", {"u": USUARIO_TIENDA})
    fila = cur.fetchone()
    if fila:
        return fila[0]
    return db.insert_returning_id(
        cur,
        "INSERT INTO usuario (username, password_hash, rol, activo) "
        "VALUES (:u, :h, 'VENDEDOR', 'N')",
        {"u": USUARIO_TIENDA, "h": generate_password_hash(secrets.token_urlsafe(32))},
        "id_usuario",
    )


def _guardar_cliente(cur, d):
    """Busca al cliente por documento; si no existe lo crea. Devuelve (id, fecha_nacimiento)."""
    cur.execute(
        "SELECT id_cliente, fecha_nacimiento FROM cliente "
        "WHERE tipo_documento = :t AND numero_documento = :n",
        {"t": d["tipo"], "n": d["numero"]})
    fila = cur.fetchone()
    if fila:
        id_cliente, nacimiento = fila
        # Se actualizan los datos de contacto; el nombre y la fecha ya registrados se respetan.
        cur.execute(
            "UPDATE cliente SET telefono = :tel, direccion = :dir, "
            "email = NVL(:email, email), fecha_nacimiento = NVL(fecha_nacimiento, :nac), "
            "activo = 'S' WHERE id_cliente = :id",
            {"tel": d["telefono"], "dir": d["direccion"], "email": d["email"],
             "nac": d["nacimiento"], "id": id_cliente})
        return id_cliente, (nacimiento.date() if nacimiento else d["nacimiento"])
    id_cliente = db.insert_returning_id(
        cur,
        "INSERT INTO cliente (tipo_documento, numero_documento, nombre, apellido, email, "
        "telefono, direccion, fecha_nacimiento) VALUES (:t, :n, :nom, :ape, :email, :tel, :dir, :nac)",
        {"t": d["tipo"], "n": d["numero"], "nom": d["nombre"], "ape": d["apellido"],
         "email": d["email"], "tel": d["telefono"], "dir": d["direccion"], "nac": d["nacimiento"]},
        "id_cliente",
    )
    return id_cliente, d["nacimiento"]


def _registrar_pedido(form):
    """Venta a domicilio desde la tienda: cliente, venta, detalle, pago y domicilio en UNA transacción."""
    d = _leer_datos(form)
    edad_minima = current_app.config["EDAD_MINIMA"]
    if calcular_edad(d["nacimiento"]) < edad_minima:
        raise ValueError(f"Debes tener al menos {edad_minima} años para comprar.")
    items = {int(k): v for k, v in _carrito().items() if v > 0}
    if not items:
        raise ValueError("Tu carrito está vacío.")

    conn = db.get_conn()
    try:
        with conn.cursor() as cur:
            # Bloquea los productos y valida el stock antes de vender (evita ventas simultáneas
            # de la última unidad y da un mensaje claro en lugar del error de la restricción).
            for id_producto, cantidad in items.items():
                cur.execute("SELECT nombre, stock_actual FROM producto "
                            "WHERE id_producto = :p AND activo = 'S' FOR UPDATE",
                            {"p": id_producto})
                fila = cur.fetchone()
                if not fila:
                    raise ValueError("Uno de los productos del carrito ya no está disponible.")
                if cantidad > fila[1]:
                    raise ValueError(f"Solo quedan {fila[1]} unidad(es) de {fila[0]}. "
                                     "Ajusta la cantidad en el carrito.")

            id_cliente, nacimiento = _guardar_cliente(cur, d)
            if calcular_edad(nacimiento) < edad_minima:
                raise ValueError(f"Debes tener al menos {edad_minima} años para comprar.")
            id_usuario = _usuario_tienda(cur)

            id_venta = db.insert_returning_id(
                cur,
                "INSERT INTO venta (id_cliente, id_usuario, tipo_venta, edad_verificada) "
                "VALUES (:cli, :usr, 'DOMICILIO', 'S')",
                {"cli": id_cliente, "usr": id_usuario},
                "id_venta",
            )
            # Precio siempre desde la base de datos. El trigger trg_detalle_venta_ai
            # descuenta el stock y registra el movimiento de inventario.
            for id_producto, cantidad in items.items():
                cur.execute(
                    "INSERT INTO detalle_venta (id_venta, id_producto, cantidad, precio_unitario) "
                    "SELECT :v, id_producto, :c, precio_venta FROM producto WHERE id_producto = :p",
                    {"v": id_venta, "c": cantidad, "p": id_producto},
                )
            total = cur.var(oracledb.NUMBER)
            cur.execute(
                "UPDATE venta SET total = (SELECT SUM(cantidad * precio_unitario) "
                "FROM detalle_venta WHERE id_venta = :v) "
                "WHERE id_venta = :v RETURNING total INTO :total",
                {"v": id_venta, "total": total},
            )
            cur.execute(
                "INSERT INTO pago (id_venta, metodo, valor, estado) "
                "VALUES (:v, :m, :valor, 'PENDIENTE')",
                {"v": id_venta, "m": d["metodo"], "valor": total.getvalue()[0]},
            )
            obs = "Pedido web" + (f": {d['observaciones']}" if d["observaciones"] else "")
            cur.execute(
                "INSERT INTO domicilio (id_venta, direccion_entrega, telefono_contacto, observaciones) "
                "VALUES (:v, :dir, :tel, :obs)",
                {"v": id_venta, "dir": d["direccion"], "tel": d["telefono"], "obs": obs[:300]},
            )
        conn.commit()
        return id_venta
    except Exception:
        conn.rollback()
        raise


@bp.route("/pedido/<int:id_venta>")
@cliente_requerido
def pedido(id_venta):
    # El cliente solo ve los pedidos que hizo en esta sesión
    if id_venta not in session.get("mis_pedidos", []):
        flash("No encontramos ese pedido.", "warning")
        return redirect(url_for("tienda.catalogo"))
    venta = db.query(
        "SELECT v.id_venta, v.fecha, v.total, v.estado, "
        "TRIM(c.nombre || ' ' || c.apellido) AS cliente, d.direccion_entrega, "
        "d.telefono_contacto, d.estado AS estado_domicilio, "
        "(SELECT MIN(metodo) FROM pago p WHERE p.id_venta = v.id_venta) AS metodo "
        "FROM venta v LEFT JOIN cliente c ON c.id_cliente = v.id_cliente "
        "LEFT JOIN domicilio d ON d.id_venta = v.id_venta WHERE v.id_venta = :id",
        {"id": id_venta}, one=True)
    lineas = db.query(
        "SELECT d.cantidad, d.precio_unitario, d.cantidad * d.precio_unitario AS subtotal, "
        "p.nombre, p.imagen, c.nombre AS categoria FROM detalle_venta d "
        "JOIN producto p ON p.id_producto = d.id_producto "
        "JOIN categoria c ON c.id_categoria = p.id_categoria "
        "WHERE d.id_venta = :id ORDER BY p.nombre", {"id": id_venta})
    return render_template("tienda/pedido.html", venta=venta, lineas=lineas)


@bp.route("/salir")
def salir():
    session.clear()
    return redirect(url_for("auth.login"))
