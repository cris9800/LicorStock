from functools import wraps

from flask import flash, redirect, session, url_for, abort


def login_requerido(vista):
    @wraps(vista)
    def envoltura(*args, **kwargs):
        if "id_usuario" not in session:
            flash("Inicia sesión para continuar.", "warning")
            return redirect(url_for("auth.login"))
        return vista(*args, **kwargs)
    return envoltura


def rol_requerido(*roles):
    """Restringe la vista a los roles indicados (ADMINISTRADOR siempre tiene acceso). RF03."""
    def decorador(vista):
        @wraps(vista)
        @login_requerido
        def envoltura(*args, **kwargs):
            rol = session.get("rol")
            if rol != "ADMINISTRADOR" and rol not in roles:
                abort(403)
            return vista(*args, **kwargs)
        return envoltura
    return decorador
