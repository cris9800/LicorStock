@echo off
cd /d "%~dp0"
echo Crear un usuario ADMINISTRADOR nuevo para LicorStock.
echo (La contrasena no se ve mientras la escribes, es normal.)
venv\Scripts\flask --app run crear-admin
pause
